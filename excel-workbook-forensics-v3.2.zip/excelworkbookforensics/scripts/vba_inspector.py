#!/usr/bin/env python3
"""
vba_inspector.py (v2.1.0) — Best-effort MS-OVBA OLE2 & VBA Inspector (not independently qualified).
Parses OLE2 directory tree, decompresses `VBA/dir` TLV records (`PROJECTCODEPAGE`,
`MODULEOFFSET`, `MODULETYPE`), slices module streams at exact `MODULEOFFSET`,
and cross-checks worksheet `codeName` bindings to detect orphaned ghost modules.
"""

import argparse
import json
import os
import posixpath
import re
from collections import Counter
import struct
import zipfile
from typing import Any, Dict, List, Optional, Set, Tuple
import xml.etree.ElementTree as ET

NS_MAIN = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
NS_REL = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"

CODEPAGE_MAP: Dict[int, str] = {
    437: "cp437", 850: "cp850", 874: "cp874", 932: "cp932", 936: "gbk",
    949: "cp949", 950: "big5", 1250: "cp1250", 1251: "cp1251", 1252: "cp1252",
    1253: "cp1253", 1254: "cp1254", 1255: "cp1255", 1256: "cp1256",
    1257: "cp1257", 1258: "cp1258", 10000: "mac_roman", 65001: "utf-8",
}


def resolve_opc_target(source_part: str, target_uri: str) -> str:
    target_clean = target_uri.strip().replace("\\", "/")
    if target_clean.startswith("/"):
        return posixpath.normpath(target_clean.lstrip("/"))
    return posixpath.normpath(posixpath.join(posixpath.dirname(source_part), target_clean))


def decompress_ovba(data: bytes) -> Tuple[bytes, str, List[str]]:
    """MS-OVBA §2.4.1.3.1 CompressedContainer decompressor with explicit warning capture."""
    warnings: List[str] = []
    if not data:
        return b"", "EMPTY_INPUT", ["Input stream slice is empty."]
    if data[0] != 0x01:
        return b"", "INVALID_SIGNATURE_BYTE", [f"Expected 0x01 at offset 0, found 0x{data[0]:02X}."]

    out = bytearray()
    pos = 1
    n = len(data)
    chunk_idx = 0

    while pos < n:
        if pos + 2 > n:
            if data[pos] != 0x00:
                warnings.append(f"Chunk {chunk_idx}: Truncated 1-byte header at pos={pos}.")
            break
        header = struct.unpack_from("<H", data, pos)[0]
        if header == 0x0000 and all(b == 0 for b in data[pos:]):
            break
        chunk_size = (header & 0x0FFF) + 3
        chunk_sig = (header >> 12) & 0x07
        is_compressed = (header >> 15) & 0x01
        if chunk_sig != 0b011:
            warnings.append(f"Chunk {chunk_idx} at pos={pos}: Invalid signature 0b{chunk_sig:03b}.")
            break

        expected_end = pos + chunk_size
        if expected_end > n and is_compressed:
            warnings.append(f"Chunk {chunk_idx}: Declared size={chunk_size} exceeds stream end by {expected_end - n}B.")
        chunk_end = min(expected_end, n)
        pos += 2
        chunk_out_start = len(out)

        if not is_compressed:
            raw_end = min(pos + 4096, n)
            if raw_end - pos < 4096:
                warnings.append(f"Chunk {chunk_idx}: Uncompressed chunk truncated ({raw_end - pos} < 4096B).")
            out.extend(data[pos:raw_end])
            pos = raw_end
            chunk_idx += 1
            continue

        while pos < chunk_end:
            flags = data[pos]
            pos += 1
            for bit in range(8):
                if pos >= chunk_end:
                    break
                if ((flags >> bit) & 1) == 0:
                    out.append(data[pos])
                    pos += 1
                else:
                    if pos + 2 > chunk_end:
                        warnings.append(f"Chunk {chunk_idx}: Truncated CopyToken at pos={pos}.")
                        pos = chunk_end
                        break
                    token = struct.unpack_from("<H", data, pos)[0]
                    pos += 2
                    diff = len(out) - chunk_out_start
                    bit_count = max(4, (diff - 1).bit_length()) if diff > 0 else 4
                    len_mask = 0xFFFF >> bit_count
                    off_mask = (~len_mask) & 0xFFFF
                    length = (token & len_mask) + 3
                    offset = ((token & off_mask) >> (16 - bit_count)) + 1
                    src = len(out) - offset
                    if src < 0:
                        warnings.append(f"Chunk {chunk_idx}: CopyToken offset={offset} out of bounds.")
                    for _ in range(length):
                        out.append(out[src] if 0 <= src < len(out) else 0)
                        src += 1
        chunk_idx += 1

    return bytes(out), ("OK" if not warnings else "DEGRADED_WITH_WARNINGS"), warnings


def parse_vba_dir_stream(dir_raw_bytes: bytes) -> Dict[str, Any]:
    """Decompresses `VBA/dir` and parses TLV records per MS-OVBA §2.3.4.2."""
    dec, status, warnings = decompress_ovba(dir_raw_bytes)
    info: Dict[str, Any] = {
        "dir_decompression_status": status,
        "dir_warnings": list(warnings),
        "codepage": 1252,
        "python_codec": "cp1252",
        "project_name": "",
        "modules": {},
    }
    if not dec:
        return info

    pos, n = 0, len(dec)
    curr: Optional[Dict[str, Any]] = None

    while pos + 6 <= n:
        rec_id = struct.unpack_from("<H", dec, pos)[0]
        rec_size = struct.unpack_from("<I", dec, pos + 2)[0]
        pos += 6
        if rec_id == 0x0009:  # PROJECTVERSION has 4B Major + 2B Minor
            pos += 6
            continue
        if pos + rec_size > n:
            info["dir_warnings"].append(f"TLV 0x{rec_id:04X} size={rec_size} exceeds stream.")
            break
        payload = dec[pos : pos + rec_size]
        pos += rec_size
        codec = info["python_codec"]

        if rec_id == 0x0003 and rec_size == 2:
            cp = struct.unpack_from("<H", payload, 0)[0]
            info["codepage"] = cp
            info["python_codec"] = CODEPAGE_MAP.get(cp, "cp1252")
        elif rec_id == 0x0004:
            info["project_name"] = payload.decode(codec, errors="replace")
        elif rec_id == 0x0019:
            mname = payload.decode(codec, errors="replace")
            curr = {
                "module_name": mname, "module_name_unicode": mname,
                "stream_name": mname, "stream_name_unicode": mname,
                "text_offset": None, "module_type": "unknown",
            }
        elif rec_id == 0x0047 and curr is not None:
            curr["module_name_unicode"] = payload.decode("utf-16le", errors="replace")
        elif rec_id == 0x001A and curr is not None:
            curr["stream_name"] = payload.decode(codec, errors="replace")
            if pos + 6 <= n:
                nid, nsz = struct.unpack_from("<HI", dec, pos)
                if nid == 0x0032 and pos + 6 + nsz <= n:
                    curr["stream_name_unicode"] = dec[pos + 6 : pos + 6 + nsz].decode("utf-16le", errors="replace")
                    pos += 6 + nsz
        elif rec_id == 0x0031 and rec_size == 4 and curr is not None:
            curr["text_offset"] = struct.unpack_from("<I", payload, 0)[0]
        elif rec_id == 0x0021 and curr is not None:
            curr["module_type"] = "procedural"
        elif rec_id == 0x0022 and curr is not None:
            curr["module_type"] = "document_or_class"
        elif rec_id == 0x002B and curr is not None:
            key = curr["stream_name_unicode"] or curr["stream_name"]
            info["modules"][key] = curr
            curr = None

    if curr is not None:
        info["modules"][curr["stream_name_unicode"] or curr["stream_name"]] = curr
    return info


def extract_active_codenames_from_workbook(zf: zipfile.ZipFile) -> Dict[str, Any]:
    res = {"workbook_codename": "ThisWorkbook", "sheet_codenames": set()}
    names = set(zf.namelist())
    if "xl/workbook.xml" not in names or "xl/_rels/workbook.xml.rels" not in names:
        return res
    wb_root = ET.fromstring(zf.read("xl/workbook.xml"))
    wb_pr = wb_root.find(f"{{{NS_MAIN}}}workbookPr")
    if wb_pr is not None and wb_pr.attrib.get("codeName"):
        res["workbook_codename"] = wb_pr.attrib["codeName"]
    rels_root = ET.fromstring(zf.read("xl/_rels/workbook.xml.rels"))
    rel_map = {r.attrib["Id"]: r.attrib["Target"] for r in rels_root if "Id" in r.attrib and "Target" in r.attrib}
    for idx, sh in enumerate(wb_root.findall(f".//{{{NS_MAIN}}}sheet"), start=1):
        sname = sh.attrib.get("name", f"Sheet{idx}")
        sid = sh.attrib.get("sheetId", str(idx))
        rid = sh.attrib.get(f"{{{NS_REL}}}id", "")
        cname = None
        if rid in rel_map:
            t = resolve_opc_target("xl/workbook.xml", rel_map[rid])
            if t in names:
                with zf.open(t, "r") as wf:
                    for _ev, el in ET.iterparse(wf, events=("start",)):
                        if el.tag == f"{{{NS_MAIN}}}sheetPr":
                            cname = el.attrib.get("codeName")
                            break
                        if el.tag == f"{{{NS_MAIN}}}sheetData":
                            break
        res["sheet_codenames"].add(cname or f"Sheet{sid}")
        res["sheet_codenames"].add(sname)
    return res



# ---------------------------------------------------------------------------
# v2.4: static code-risk scan. Reports WHAT the code can do, with module and
# VBE-style line numbers. Secret values are never emitted: credential literals
# are replaced by "<redacted:N chars>". This is a triage aid, not a malware
# verdict; severities describe capability, not intent.
# ---------------------------------------------------------------------------
CRED_NAME_RE = re.compile(r"(?i)(pass(word|wd)?|pwd|(?:^|_)pw(?:_|\d|$)|psw|secret|token|api_?key|apikey|credential|private_?key)")
ACCOUNT_NAME_RE = re.compile(r"(?i)(user(name|_?id)?|uid|login|acct|account)")
ASSIGN_LITERAL_RE = re.compile(
    r'(?i)^\s*(?:(?:Public|Private|Global)\s+)?(?:Const\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*(?:As\s+String\s*)?=\s*"((?:""|[^"])*)"'
)
INLINE_PWD_RE = re.compile(r'(?i)\b(password|pwd)\s*=\s*([^;"&]+)')
CONNSTR_RE = re.compile(r"(?i)\b(provider|driver|data source|server|initial catalog|database|dsn|user id|uid|password|pwd)\s*=")
PROGID_RE = re.compile(r'(?i)\b(CreateObject|GetObject)\s*\(\s*"([^"]+)"')
DECLARE_RE = re.compile(r'(?i)\bDeclare\s+(?:PtrSafe\s+)?(?:Function|Sub)\s+(\w+)\s+Lib\s+"([^"]+)"(?:\s+Alias\s+"([^"]+)")?')
URL_RE = re.compile(r'(?i)\b(https?|ftp)://([^/"\s:]+)')
PROC_RE = re.compile(r"(?i)^\s*(?:(?:Public|Private|Friend)\s+)?(?:Static\s+)?(Sub|Function|Property\s+(?:Get|Let|Set))\s+([A-Za-z_][A-Za-z0-9_]*)")
LONG_ENCODED_RE = re.compile(r'"([A-Za-z0-9+/=]{60,}|(?:[0-9A-Fa-f]{2}){30,})"')

AUTO_EXEC = {
    "workbook_open", "auto_open", "workbook_activate", "workbook_beforeclose", "auto_close",
    "workbook_beforesave", "workbook_aftersave", "workbook_sheetchange", "workbook_sheetcalculate",
    "worksheet_change", "worksheet_calculate", "worksheet_activate", "worksheet_selectionchange",
    "auto_exec", "document_open",
}
HIGH_API = {"urldownloadtofilea", "urldownloadtofilew", "urldownloadtofile", "virtualalloc", "virtualallocex",
            "rtlmovememory", "createthread", "createremotethread", "shellexecutea", "shellexecutew",
            "shellexecute", "winexec", "writeprocessmemory", "loadlibrarya", "loadlibraryw"}
PROGID_CLASS = [
    (re.compile(r"(?i)^(wscript\.shell|shell\.application|wscript\.network)$"), "HIGH", "command_execution"),
    (re.compile(r"(?i)^(msxml2\.|microsoft\.xmlhttp|winhttp\.|msxml2\.serverxmlhttp|internetexplorer\.application)"), "MEDIUM", "network"),
    (re.compile(r"(?i)^adodb\.(connection|recordset|command)"), "MEDIUM", "database_connection"),
    (re.compile(r"(?i)^(adodb\.stream|scripting\.filesystemobject)"), "MEDIUM", "file_io"),
    (re.compile(r"(?i)^(outlook\.application|cdo\.message)"), "MEDIUM", "email"),
    (re.compile(r"(?i)^(scripting\.dictionary|vbscript\.regexp|new:\{)"), None, None),  # benign helpers: counted only
]
KEYWORD_RULES = [
    # (regex on code with strings+comments stripped, severity, category, label)
    (re.compile(r"(?i)(?<![.\w])Shell\s*(\(|\s+[^=\s])"), "HIGH", "command_execution", "Shell statement"),
    (re.compile(r"(?i)\bVBProject\b|\bVBComponents\b|\bCodeModule\b"), "HIGH", "self_modifying_code", "VBA project object model access"),
    (re.compile(r"(?i)\bOpen\b[^\n]*\bFor\s+(Output|Append|Binary|Random)\b"), "MEDIUM", "file_io", "file write (Open ... For Output/Append/Binary)"),
    (re.compile(r"(?i)(?<![.\w])Kill\s+"), "MEDIUM", "file_io", "Kill (delete file)"),
    (re.compile(r"(?i)(?<![.\w])(FileCopy|RmDir|MkDir)\b"), "LOW", "file_io", "file system statement"),
    (re.compile(r"(?i)\.(SaveAs|SaveCopyAs|ExportAsFixedFormat)\b"), "LOW", "file_io", "workbook save/export"),
    (re.compile(r"(?i)\.(DeleteFile|DeleteFolder|CopyFile|MoveFile|CreateTextFile)\b"), "MEDIUM", "file_io", "FileSystemObject write/delete"),
    (re.compile(r"(?i)(?<![.\w])SendKeys\b"), "MEDIUM", "ui_automation", "SendKeys"),
    (re.compile(r"(?i)\bApplication\.Run\b|\bCallByName\b"), "LOW", "indirect_call", "dynamic procedure call"),
    (re.compile(r"(?i)\bAutomationSecurity\b|\bAccessVBOM\b"), "HIGH", "security_setting", "macro security setting change"),
    (re.compile(r"(?i)(?<![.\w])(SaveSetting|DeleteSetting|RegWrite|RegDelete)\b"), "LOW", "registry", "registry write"),
    (re.compile(r"(?i)\bStrReverse\b"), "LOW", "obfuscation", "StrReverse"),
    (re.compile(r"(?i)\.Send\b"), "LOW", "network_or_email", ".Send call"),
]
SEV_ORDER = {"HIGH": 0, "MEDIUM": 1, "LOW": 2}


def _strip_strings_and_comments(line: str) -> str:
    out, in_str, i = [], False, 0
    while i < len(line):
        ch = line[i]
        if in_str:
            if ch == '"':
                if i + 1 < len(line) and line[i + 1] == '"':
                    i += 2
                    continue
                in_str = False
                out.append('"')
            i += 1
            continue
        if ch == '"':
            in_str = True
            out.append('"')
        elif ch == "'":
            break
        else:
            out.append(ch)
        i += 1
    s = "".join(out)
    return "" if re.match(r"(?i)^\s*Rem\b", s) else s


def _redact(line: str, secret_names: Set[str]) -> str:
    s = INLINE_PWD_RE.sub(lambda m: f"{m.group(1)}=<redacted>", line)
    m = ASSIGN_LITERAL_RE.match(s)
    if m and (m.group(1) in secret_names or CRED_NAME_RE.search(m.group(1)) or ACCOUNT_NAME_RE.search(m.group(1))):
        val = m.group(2)
        s = s[: m.start(2)] + f"<redacted:{len(val)} chars>" + s[m.end(2):]
    return s.strip()[:160]


def scan_vba_risks(modules: Dict[str, str]) -> Dict[str, Any]:
    """modules: {module_name: VBE-visible source text (Attribute lines removed)}."""
    findings: List[Dict[str, Any]] = []
    procedures: Dict[str, List[str]] = {}
    benign_objects: Counter = Counter()
    per_module: Dict[str, Dict[str, int]] = {}
    secret_names: Set[str] = set()

    # pass 1: credential constants/variables with literal values (all modules)
    for mod, text in modules.items():
        for ln in text.splitlines():
            m = ASSIGN_LITERAL_RE.match(ln)
            if m and m.group(2) and CRED_NAME_RE.search(m.group(1)) and not re.match(r"(?i)^\s*(Dim|ReDim)\b", ln):
                secret_names.add(m.group(1))

    def add(sev, cat, mod, lineno, label, raw, extra=None):
        f = {"severity": sev, "category": cat, "module": mod, "line": lineno, "finding": label,
             "snippet": _redact(raw, secret_names)}
        if extra:
            f.update(extra)
        findings.append(f)

    for mod, text in modules.items():
        lines = text.splitlines()
        procs: List[str] = []
        oern = 0
        code_lines = 0
        chr_calls = 0
        for no, raw in enumerate(lines, 1):
            code = _strip_strings_and_comments(raw)
            if code.strip():
                code_lines += 1
            pm = PROC_RE.match(code)
            if pm:
                procs.append(pm.group(2))
                if pm.group(2).lower() in AUTO_EXEC:
                    add("MEDIUM", "auto_execution", mod, no, f"runs automatically: {pm.group(2)}", raw)
            if re.search(r"(?i)\bOn\s+Error\s+Resume\s+Next\b", code):
                oern += 1
            chr_calls += len(re.findall(r"(?i)\bChrW?\$?\s*\(", code))
            # credentials
            m = ASSIGN_LITERAL_RE.match(raw)
            if m and m.group(1) in secret_names:
                add("HIGH", "hardcoded_credential", mod, no, f"credential literal assigned to {m.group(1)}", raw,
                    {"identifier": m.group(1), "value_length": len(m.group(2))})
            elif m and m.group(2) and ACCOUNT_NAME_RE.search(m.group(1)) and not CRED_NAME_RE.search(m.group(1)):
                add("LOW", "account_identifier", mod, no, f"account name literal assigned to {m.group(1)}", raw,
                    {"identifier": m.group(1)})
            for pm2 in INLINE_PWD_RE.finditer(raw):
                v = pm2.group(2).strip()
                if v and not v.startswith("<"):
                    add("HIGH", "hardcoded_credential", mod, no, "password embedded in string literal", raw,
                        {"value_length": len(v)})
            if '"' in raw and CONNSTR_RE.search(raw):
                used = sorted(n for n in secret_names if re.search(rf"\b{re.escape(n)}\b", raw))
                add("HIGH" if used else "MEDIUM", "connection_string", mod, no,
                    "connection string" + (f" using credential {', '.join(used)}" if used else ""), raw,
                    {"uses_credentials": used} if used else None)
            elif secret_names and not (m and m.group(1) in secret_names):
                used = sorted(n for n in secret_names if re.search(rf"\b{re.escape(n)}\b", code))
                if used:
                    add("MEDIUM", "credential_use", mod, no, f"uses credential {', '.join(used)}", raw)
            for om in PROGID_RE.finditer(raw):
                pid = om.group(2)
                for rx, sev, cat in PROGID_CLASS:
                    if rx.search(pid):
                        if sev:
                            add(sev, cat, mod, no, f"{om.group(1)}(\"{pid}\")", raw, {"progid": pid})
                        else:
                            benign_objects[pid] += 1
                        break
                else:
                    add("LOW", "object_creation", mod, no, f"{om.group(1)}(\"{pid}\")", raw, {"progid": pid})
            dm = DECLARE_RE.search(code if "Declare" in code else raw)
            if dm is None:
                dm = DECLARE_RE.search(raw)
            if dm:
                fn = (dm.group(3) or dm.group(1))
                add("HIGH" if fn.lower() in HIGH_API else "MEDIUM", "windows_api", mod, no,
                    f"Declare {dm.group(1)} Lib \"{dm.group(2)}\"", raw, {"api": fn, "library": dm.group(2)})
            for um in URL_RE.finditer(raw):
                if "'" in raw and raw.find("'") < um.start() and '"' not in raw[:um.start()]:
                    continue  # URL inside a comment
                add("MEDIUM", "network", mod, no, f"URL to host {um.group(2)}", raw, {"host": um.group(2)})
            if re.search(r"(?i)\bEnviron\$?\s*\(", code):
                add("LOW", "environment", mod, no, "reads environment variable", raw)
            if LONG_ENCODED_RE.search(raw):
                add("MEDIUM", "obfuscation", mod, no, "long hex/base64-like string literal", raw)
            for rx, sev, cat, label in KEYWORD_RULES:
                if rx.search(code):
                    add(sev, cat, mod, no, label, raw)
        procedures[mod] = procs
        per_module[mod] = {"lines": len(lines), "code_lines": code_lines, "procedures": len(procs),
                           "on_error_resume_next": oern, "chr_calls": chr_calls}
        if oern:
            add("LOW", "error_suppression", mod, None, f"On Error Resume Next x{oern}", "")
        if chr_calls >= 20:
            add("MEDIUM", "obfuscation", mod, None, f"Chr()/ChrW() calls x{chr_calls}", "")

    findings.sort(key=lambda f: (SEV_ORDER.get(f["severity"], 9), f["module"], f["line"] or 0))
    counts = Counter(f["severity"] for f in findings)
    by_cat = Counter(f["category"] for f in findings)
    return {
        "summary": {"HIGH": counts.get("HIGH", 0), "MEDIUM": counts.get("MEDIUM", 0), "LOW": counts.get("LOW", 0)},
        "by_category": dict(sorted(by_cat.items())),
        "credential_identifiers": sorted(secret_names),
        "findings": findings,
        "per_module": per_module,
        "procedures": procedures,
        "benign_objects": dict(benign_objects),
        "note": "Static capability scan. Severity = what the code CAN do, not intent. Secret values are redacted. Line numbers follow the VBA editor (Attribute lines hidden).",
    }


def parse_vba_project(
    vba_bytes: bytes,
    active_codenames: Optional[Dict[str, Any]] = None,
    extract_code: bool = True,
    scan_risks: bool = False,
) -> Dict[str, Any]:
    if len(vba_bytes) < 512 or vba_bytes[:8] != b"\xD0\xCF\x11\xE0\xA1\xB1\x1A\xE1":
        return {"status": "INVALID_OLE2_HEADER", "size_bytes": len(vba_bytes), "decompression_warnings": ["Invalid OLE2 header."]}

    sector_shift, mini_shift = struct.unpack_from("<HH", vba_bytes, 30)
    sector_size, mini_size = 1 << sector_shift, 1 << mini_shift
    num_fat_sectors, first_dir_sector = struct.unpack_from("<II", vba_bytes, 44)
    mini_cutoff, first_minifat_sector = struct.unpack_from("<II", vba_bytes, 56)
    first_difat_sector, num_difat_sectors = struct.unpack_from("<II", vba_bytes, 68)

    difat = list(struct.unpack_from("<109I", vba_bytes, 76))
    curr_difat = first_difat_sector
    for _ in range(num_difat_sectors):
        if curr_difat >= 0xFFFFFFFE:
            break
        off = (curr_difat + 1) * sector_size
        entries = struct.unpack_from(f"<{sector_size // 4}I", vba_bytes, off)
        difat.extend(entries[:-1])
        curr_difat = entries[-1]
    difat = [s for s in difat if s < 0xFFFFFFFE]

    fat: List[int] = []
    for s in difat[:num_fat_sectors]:
        off = (s + 1) * sector_size
        if off + sector_size <= len(vba_bytes):
            fat.extend(struct.unpack_from(f"<{sector_size // 4}I", vba_bytes, off))

    def read_chain(start_sec: int, size: Optional[int] = None) -> bytes:
        res = bytearray()
        sec, visited = start_sec, set()
        while sec < 0xFFFFFFFE and sec not in visited and sec < len(fat):
            visited.add(sec)
            off = (sec + 1) * sector_size
            res.extend(vba_bytes[off : off + sector_size])
            sec = fat[sec]
        return bytes(res[:size]) if size is not None else bytes(res)

    dir_bytes = read_chain(first_dir_sector)
    minifat: List[int] = []
    if first_minifat_sector < 0xFFFFFFFE:
        mf_bytes = read_chain(first_minifat_sector)
        if len(mf_bytes) >= 4:
            minifat = list(struct.unpack(f"<{len(mf_bytes) // 4}I", mf_bytes))

    raw_entries: List[Dict[str, Any]] = []
    for idx, i in enumerate(range(0, len(dir_bytes), 128)):
        e = dir_bytes[i : i + 128]
        if len(e) < 128:
            break
        nlen = struct.unpack_from("<H", e, 64)[0]
        otype = e[66]
        lsib, rsib, cid = struct.unpack_from("<III", e, 68)
        ssec, sz = struct.unpack_from("<IQ", e, 116)
        if sector_size == 512:
            sz &= 0xFFFFFFFF
        name = e[: max(0, nlen - 2)].decode("utf-16le", errors="replace") if otype != 0 and nlen > 0 else ""
        raw_entries.append({"id": idx, "name": name, "obj_type": otype, "left": lsib, "right": rsib, "child": cid, "start": ssec, "size": sz})

    root_stream = b""
    for e in raw_entries:
        if e["obj_type"] == 5:
            root_stream = read_chain(e["start"], e["size"])
            break

    def get_bytes(e: Dict[str, Any]) -> bytes:
        if e["size"] < mini_cutoff and root_stream:
            res, sec, vis = bytearray(), e["start"], set()
            while sec < 0xFFFFFFFE and sec not in vis and sec < len(minifat):
                vis.add(sec)
                off = sec * mini_size
                res.extend(root_stream[off : off + mini_size])
                sec = minifat[sec]
            return bytes(res[: e["size"]])
        return read_chain(e["start"], e["size"])

    stream_paths: Dict[str, bytes] = {}
    visited_nodes: Set[int] = set()

    def walk(nid: int, prefix: str) -> None:
        if nid == 0xFFFFFFFF or nid >= len(raw_entries) or nid in visited_nodes:
            return
        visited_nodes.add(nid)
        node = raw_entries[nid]
        walk(node["left"], prefix)
        if node["obj_type"] == 1:
            walk(node["child"], f"{prefix}/{node['name']}".lstrip("/"))
        elif node["obj_type"] == 2:
            stream_paths[f"{prefix}/{node['name']}".lstrip("/")] = get_bytes(node)
        walk(node["right"], prefix)

    if raw_entries and raw_entries[0]["obj_type"] == 5:
        walk(raw_entries[0]["child"], "")
    for e in raw_entries:
        if e["obj_type"] == 2 and e["id"] not in visited_nodes:
            stream_paths[f"UNLINKED/{e['name']}"] = get_bytes(e)

    dir_raw = stream_paths.get("VBA/dir") or stream_paths.get("dir") or b""
    dir_info = parse_vba_dir_stream(dir_raw) if dir_raw else {
        "dir_decompression_status": "MISSING_DIR_STREAM", "dir_warnings": ["VBA/dir missing."],
        "codepage": 1252, "python_codec": "cp1252", "project_name": "", "modules": {},
    }

    codec = dir_info["python_codec"]
    dir_mods = dir_info["modules"]
    warnings: List[str] = list(dir_info["dir_warnings"])
    wb_cname = active_codenames.get("workbook_codename", "ThisWorkbook") if active_codenames else "ThisWorkbook"
    sh_cnames: Set[str] = set(active_codenames.get("sheet_codenames", set())) if active_codenames else set()

    exec_mods: Dict[str, str] = {}
    vbe_text: Dict[str, str] = {}
    ghost_sheets = 0
    ghost_wb = 0
    empty_active = 0

    for full_path, sdata in sorted(stream_paths.items()):
        sname = full_path.split("/")[-1]
        if sname in ("dir", "_VBA_PROJECT", "PROJECT", "PROJECTwm", "PROJECTlk") or sname.startswith("__SRP_"):
            continue
        if not full_path.startswith("VBA/") and "VBA/dir" in stream_paths:
            continue

        m_meta = dir_mods.get(sname)
        toff: Optional[int] = m_meta["text_offset"] if m_meta else None
        mtype = m_meta["module_type"] if m_meta else "unknown"
        dec_bytes, m_warn = b"", []

        if toff is not None and 0 <= toff < len(sdata):
            dec_bytes, _st, m_warn = decompress_ovba(sdata[toff:])
        else:
            for off in range(len(sdata) - 3):
                if sdata[off] == 0x01 and ((struct.unpack_from("<H", sdata, off + 1)[0] >> 12) & 0x07) == 0b011:
                    cand, _st, cw = decompress_ovba(sdata[off:])
                    if b"Attribute VB_Name" in cand:
                        dec_bytes, m_warn = cand, cw
                        break

        warnings.extend(f"{sname}: {w}" for w in m_warn)
        txt = dec_bytes.decode(codec, errors="replace") if dec_bytes else ""
        code_lines = [ln for ln in txt.splitlines() if ln.strip() and not ln.strip().startswith("Attribute ")]

        if not code_lines:
            if active_codenames is not None:
                if sname == wb_cname or sname in sh_cnames:
                    empty_active += 1
                elif sname.startswith("ThisWorkbook"):
                    ghost_wb += 1
                elif sname.startswith("Sheet") or mtype == "document_or_class":
                    ghost_sheets += 1
            else:
                if re.match(r"^Sheet\d{2,}$", sname):
                    ghost_sheets += 1
                elif re.match(r"^ThisWorkbook\d+$", sname):
                    ghost_wb += 1
        else:
            exec_mods[sname] = "\n".join(code_lines) if extract_code else f"<{len(code_lines)} lines>"
            vbe_text[sname] = "\n".join(ln for ln in txt.splitlines() if not ln.strip().startswith("Attribute "))

    declared_modules = []
    active_names = set(sh_cnames)
    active_names.add(wb_cname)
    for stream_name, meta in sorted(dir_mods.items(), key=lambda item: item[0].casefold()):
        module_name = meta.get("module_name_unicode") or meta.get("module_name") or stream_name
        stream_label = meta.get("stream_name_unicode") or meta.get("stream_name") or stream_name
        module_type = meta.get("module_type", "unknown")
        if module_type == "procedural":
            binding = "PROCEDURAL"
        elif stream_label == wb_cname:
            binding = "WORKBOOK_DOCUMENT"
        elif stream_label in sh_cnames:
            binding = "WORKSHEET_DOCUMENT"
        elif module_type == "document_or_class":
            binding = "POSSIBLE_GHOST_DOCUMENT_OR_CLASS"
        else:
            binding = "CLASS_OR_UNRESOLVED"
        declared_modules.append({
            "module_name": module_name, "stream_name": stream_label,
            "module_type": module_type, "binding_status": binding,
            "active_codename_match": stream_label in active_names,
            "text_offset": meta.get("text_offset"),
            "has_meaningful_source": stream_label in exec_mods,
        })

    return {
        "status": "OK" if not warnings else "DEGRADED_WITH_WARNINGS",
        "size_bytes": len(vba_bytes),
        "project_name": dir_info["project_name"],
        "codepage": dir_info["codepage"],
        "python_codec": codec,
        "total_ole_streams": len(stream_paths),
        "stream_inventory": [{"path": name, "size_bytes": len(data)} for name, data in sorted(stream_paths.items())],
        "dir_declared_modules_count": len(dir_mods),
        "declared_modules": declared_modules,
        "active_codenames": {"workbook": wb_cname, "sheets": sorted(sh_cnames)},
        "ghost_sheet_class_modules": ghost_sheets,
        "ghost_thisworkbook_modules": ghost_wb,
        "empty_active_document_modules": empty_active,
        "executable_modules_count": len(exec_mods),
        "executable_modules": exec_mods,
        "decompression_warnings": warnings,
        "risk_scan": scan_vba_risks(vbe_text) if scan_risks else None,
    }


def inspect_vba_binary(vba_bytes: bytes) -> Dict[str, Any]:
    """Backwards-compatible alias for parse_vba_project."""
    return parse_vba_project(vba_bytes, active_codenames=None, extract_code=True, scan_risks=True)


def main() -> None:
    ap = argparse.ArgumentParser(description="MS-OVBA inspector for xl/vbaProject.bin")
    ap.add_argument("filepath", help="Path to .xlsm or vbaProject.bin")
    ap.add_argument("--extract-code", action="store_true", default=False)
    ap.add_argument("--scan-risks", action="store_true", default=True, help="Run static capability & credential risk scan (default True)")
    ap.add_argument("--no-scan-risks", action="store_false", dest="scan_risks", help="Disable static risk scan")
    ap.add_argument("--export-json", help="Save JSON output")
    args = ap.parse_args()
    with open(args.filepath, "rb") as f:
        magic = f.read(8)
    if magic[:4] == b"PK\x03\x04":
        with zipfile.ZipFile(args.filepath, "r") as zf:
            cnames = extract_active_codenames_from_workbook(zf)
            res = parse_vba_project(zf.read("xl/vbaProject.bin"), cnames, args.extract_code, scan_risks=args.scan_risks)
    else:
        with open(args.filepath, "rb") as f:
            res = parse_vba_project(f.read(), None, args.extract_code, scan_risks=args.scan_risks)
    if args.export_json:
        with open(args.export_json, "w", encoding="utf-8") as f:
            json.dump(res, f, indent=2)
    print(json.dumps(res, indent=2))


if __name__ == "__main__":
    main()

