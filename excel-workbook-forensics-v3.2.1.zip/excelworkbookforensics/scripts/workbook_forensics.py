#!/usr/bin/env python3
"""
workbook_forensics.py (v2.4.0) — Workbook-Agnostic OOXML & Dependency Forensics Engine.
Implements canonical OPC path resolution, incremental `iterparse` XML streaming,
shared-formula coordinate translation, 3D/Table/DefinedName/Chart/Pivot bridges,
sheet- and cell-level Tarjan SCC cycle detection, and uniform Level 1-4 schemas.
"""

import argparse
import hashlib
import importlib.util
import json
import os
import posixpath
import re
import shutil
import subprocess
import sys
import tempfile
import threading
import time
import urllib.parse
import zipfile
from collections import Counter, defaultdict
from typing import Any, Dict, List, Optional, Set, Tuple

try:
    from lxml import etree as ET  # type: ignore
    USING_LXML = True
except ImportError:
    import xml.etree.ElementTree as ET  # type: ignore
    USING_LXML = False

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
if SCRIPT_DIR not in sys.path:
    sys.path.insert(0, SCRIPT_DIR)
try:
    import vba_inspector  # type: ignore
    HAS_VBA_INSPECTOR = True
except ImportError:
    HAS_VBA_INSPECTOR = False

NS_MAIN = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
NS_REL = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
NS_CHART = "http://schemas.openxmlformats.org/drawingml/2006/chart"
NS_CHARTEX = "http://schemas.microsoft.com/office/drawing/2014/chartex"
NS_CT = "http://schemas.openxmlformats.org/package/2006/content-types"
RIBBON_CALLBACK_ATTRS_RE = re.compile(r"^(on[A-Z]\w*|get[A-Z]\w*|loadImage)$")
CONN_SECRET_RE = re.compile(r'''(?i)\b(password|passwd|pwd|secret|token|api[_-]?key|apikey|access[_-]?token|client[_-]?secret)\s*=\s*(?:""[^"]*""|"[^"]*"|'[^']*'|[^;"&\s'<>]*)''')
URL_SECRET_PARAM_RE = re.compile(r"(?i)([?&](?:token|access[_-]?token|auth|api[_-]?key|apikey|key|secret|password|passwd|pwd|sig|signature)=)([^&#\"\s']+)")
BASIC_AUTH_URL_RE = re.compile(r"(?i)(https?://|ftp://)([^/\s:@\"']+):([^/\s@\"']+)@")


def _guard_output_path(source_path: str, output_path: Optional[str], label: str = "--export-json") -> None:
    """Reject output paths that alias or overwrite the input file (including symlinks/hardlinks)."""
    if not output_path:
        return
    src_abs = os.path.abspath(source_path)
    out_abs = os.path.abspath(output_path)
    if os.path.normcase(src_abs) == os.path.normcase(out_abs) or os.path.normcase(os.path.realpath(src_abs)) == os.path.normcase(os.path.realpath(out_abs)):
        raise ValueError(f"{label} path cannot point to the input file: {output_path}")
    if os.path.exists(out_abs) and os.path.exists(src_abs):
        try:
            if os.path.samefile(src_abs, out_abs):
                raise ValueError(f"{label} path resolves to the same underlying inode/file as the input: {output_path}")
        except OSError:
            pass
    if os.path.isdir(out_abs):
        raise ValueError(f"{label} path points to an existing directory: {output_path}")

# v2.2: shared progress state read by the optional --heartbeat thread.
PROGRESS: Dict[str, Any] = {"stage": "init", "sheet": None, "sheet_idx": 0, "sheet_total": 0, "cells": 0}
DYNAMIC_SAMPLE_CAP = 20
FORMULA_ERROR_SAMPLE_CAP = 20


class Heartbeat:
    """Print a one-line progress pulse to stderr every `interval` seconds.

    Stderr only, so stdout JSON stays machine-parseable. A heartbeat proves the
    process is alive; it does NOT extend any external sandbox/tool time limit.
    """

    def __init__(self, interval: float) -> None:
        self.interval = interval
        self.t0 = time.monotonic()
        self._stop = threading.Event()
        self._th = threading.Thread(target=self._run, daemon=True)

    def _line(self, tag: str) -> str:
        p = PROGRESS
        sh = f" sheet {p['sheet_idx']}/{p['sheet_total']} '{p['sheet']}'" if p.get("sheet") else ""
        return f"[{tag}] t={time.monotonic() - self.t0:.0f}s stage={p['stage']}{sh} cells={p['cells']}"

    def _run(self) -> None:
        while not self._stop.wait(self.interval):
            print(self._line("heartbeat"), file=sys.stderr, flush=True)

    def __enter__(self) -> "Heartbeat":
        if self.interval > 0:
            print(self._line("heartbeat-start"), file=sys.stderr, flush=True)
            self._th.start()
        return self

    def __exit__(self, *exc: Any) -> None:
        self._stop.set()
        if self.interval > 0:
            print(self._line("heartbeat-done"), file=sys.stderr, flush=True)


EXCEL_MAX_ROW, EXCEL_MAX_COL = 1048576, 16384
# v2.3: #REF! blast-radius limits and RTD classification.
BLAST_MAX_DEPTH = 25
BLAST_MAX_CELLS = 50000
BLAST_SAMPLE_CAP = 15
RTD_SAMPLE_CAP = 15
XSHEET_A1_RE = re.compile(
    r"(?:'((?:''|[^'])+)'|([A-Za-z_][A-Za-z0-9_.]*))!"
    r"(\$?[A-Za-z]{1,3}\$?[1-9]\d*(?::\$?[A-Za-z]{1,3}\$?[1-9]\d*)?)(?![A-Za-z0-9_(])"
)


def col_num_to_letter(c: int) -> str:
    out = ""
    while c > 0:
        c, rem = divmod(c - 1, 26)
        out = chr(65 + rem) + out
    return out


def classify_rtd_value(t: Optional[str], v: Optional[str]) -> str:
    """Literal classification of a cached RTD topic value. No inference about
    whether the feed is 'healthy' beyond what the cached value says."""
    v = v or ""
    if t == "n":
        return "NUMERIC"
    if t == "b":
        return "BOOLEAN"
    if t == "e":
        return "ERROR_VALUE"
    up = v.upper()
    if up.startswith("#N/A REQUESTING DATA"):
        return "REQUESTING_DATA"
    if up in ("#N/A N/A", "#N/A"):
        return "NO_DATA"
    if up.startswith("#N/A") or any(k in up for k in ("INVALID", "MANDATORY PARAMETER", "ERROR", "UNKNOWN", "NOT AUTHORIZED")):
        return "ERROR_MESSAGE"
    return "STRING"


def compute_ref_blast_radius(seeds, refs_by_cell, sheet_names):
    """BFS from cells with #REF! written in the formula, following static A1
    references (same-sheet and Sheet!A1) to every downstream formula cell.

    refs_by_cell: {(sheet, r, c): [(target_sheet, r1, r2, c1, c2), ...]}
    Not followed (reported as limitations): defined names, structured tables,
    whole-row/column refs, INDIRECT/OFFSET targets, charts.
    """
    # Reverse index on demand: for each layer, scan all cells once.
    reached = {}  # cell -> depth
    frontier = set(seeds)
    for sd in seeds:
        reached[sd] = 0
    depth = 0
    truncated = None
    items = list(refs_by_cell.items())
    while frontier:
        depth += 1
        if depth > BLAST_MAX_DEPTH:
            truncated = "DEPTH_LIMIT"
            break
        by_sheet = defaultdict(list)
        for (sh, r, c) in frontier:
            by_sheet[sh].append((r, c))
        nxt = set()
        for cell, refs in items:
            if cell in reached:
                continue
            hit = False
            for (tsh, r1, r2, c1, c2) in refs:
                for (r, c) in by_sheet.get(tsh, ()):
                    if r1 <= r <= r2 and c1 <= c <= c2:
                        hit = True
                        break
                if hit:
                    break
            if hit:
                nxt.add(cell)
                reached[cell] = depth
                if len(reached) > BLAST_MAX_CELLS:
                    truncated = "CELL_LIMIT"
                    break
        if truncated:
            break
        frontier = nxt
    return reached, depth - 1 if not truncated else depth, truncated


def _olevba_stomping_check(filepath: str) -> Dict[str, Any]:
    """Optional: compare VBA source to compiled p-code via oletools, if installed."""
    if importlib.util.find_spec("oletools") is None:
        return {"status": "NOT_CHECKED", "reason": "oletools not installed"}
    try:
        import io, contextlib, logging
        logging.getLogger("olevba").setLevel(logging.CRITICAL)
        from oletools.olevba import VBA_Parser  # type: ignore
        with contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
            vp = VBA_Parser(filepath)
            res = bool(vp.detect_vba_stomping())
            vp.close()
        return {"status": "POSSIBLE_MISMATCH" if res else "NO_MISMATCH_DETECTED", "tool": "oletools.olevba heuristic",
                "note": "Source/p-code mismatch can be malicious (VBA stomping) or benign (saved across Excel/VBA versions). Re-saving in the target Excel rebuilds p-code."}
    except Exception as exc:  # pragma: no cover
        return {"status": "ERROR", "reason": f"{type(exc).__name__}: {str(exc)[:120]}"}


def _parse_conn_string(cs: str) -> Dict[str, Any]:
    kv = {}
    for part in cs.split(";"):
        if "=" in part:
            k, v = part.split("=", 1)
            kv[k.strip().lower()] = v.strip()
    secret = any((kv.get(k) or "").strip('"\'') for k in ("password", "passwd", "pwd", "secret", "token", "api_key", "apikey", "access_token"))
    redacted = CONN_SECRET_RE.sub(lambda m: f"{m.group(1)}=<redacted>", cs)
    redacted = URL_SECRET_PARAM_RE.sub(r"\1<redacted>", redacted)
    redacted = BASIC_AUTH_URL_RE.sub(r"\1<redacted>@", redacted)
    return {"provider": kv.get("provider") or kv.get("driver"), "data_source": kv.get("data source") or kv.get("server"),
            "location": kv.get("location"), "embedded_password": secret, "connection_redacted": redacted[:200]}


def build_package_inventory(zf, filepath, namelist_set, lower_map, vba_summary, level) -> Dict[str, Any]:
    inv: Dict[str, Any] = {"container": {}, "ribbon": None, "connections": [], "query_tables": 0,
                           "power_query_present": False, "warnings": []}
    main_ct = ""
    try:
        ct = ET.fromstring(zf.read("[Content_Types].xml"))
        for ov in ct.iter(f"{{{NS_CT}}}Override"):
            if ov.attrib.get("PartName", "").lower() == "/xl/workbook.xml":
                main_ct = ov.attrib.get("ContentType", "")
    except Exception:
        pass
    ext = os.path.splitext(filepath)[1].lower()
    macro_ct = "macroenabled" in main_ct.lower()
    kind = "addin" if "addin" in main_ct.lower() else ("template" if "template" in main_ct.lower() else "workbook")
    has_vba = find_in_namelist("xl/vbaProject.bin", namelist_set, lower_map) is not None
    inv["container"] = {"extension": ext, "main_content_type": main_ct, "kind": kind,
                        "macro_enabled_container": macro_ct or ext in (".xlsm", ".xlam", ".xltm"),
                        "has_vba_project": has_vba}
    if (macro_ct or ext in (".xlsm", ".xlam", ".xltm")) and not has_vba:
        inv["warnings"].append({"code": "MACRO_ENABLED_WITHOUT_VBA",
                                "message": "Macro-enabled container with no VBA project (macros stripped, or saved with the wrong extension)."})
    if has_vba and not (macro_ct or ext in (".xlsm", ".xlam", ".xltm")):
        inv["warnings"].append({"code": "VBA_IN_NON_MACRO_CONTAINER",
                                "message": "vbaProject.bin present but container is not macro-enabled; Excel will not load it."})
    # Ribbon (customUI)
    ui_parts = sorted(n for n in namelist_set if n.lower().replace("\\", "/").startswith("customui/") and n.lower().endswith(".xml"))
    if ui_parts:
        procs: Dict[str, List[str]] = defaultdict(list)
        risk = (vba_summary or {}).get("risk_scan") if vba_summary else None
        vba_parse_complete = bool(risk) and (vba_summary or {}).get("status") == "OK"
        if vba_parse_complete:
            for module, plist in risk.get("procedures", {}).items():
                for proc in plist:
                    procs[str(proc).casefold()].append(f"{module}.{proc}")
        callbacks = []
        parse_failed = False
        for up in ui_parts:
            try:
                root = ET.fromstring(zf.read(up))
            except Exception:
                inv["warnings"].append({"code": "CUSTOMUI_PARSE_ERROR", "message": up})
                parse_failed = True
                continue
            for el in root.iter():
                for an, av in el.attrib.items():
                    an_local = an.split("}")[-1]
                    if RIBBON_CALLBACK_ATTRS_RE.match(an_local) and av:
                        name = av.strip().split(".")[-1].split("!")[-1].strip("'\" ")
                        candidates = procs.get(name.casefold(), [])
                        unsupported = "!" in av or av.startswith("=") or "[" in av or "]" in av
                        if unsupported:
                            status = "UNSUPPORTED"
                        elif not vba_parse_complete:
                            status = "NOT_CHECKED"
                        elif "." in av and not any(ch in av for ch in "![]="):
                            qualified = av.strip().strip("'\"").casefold()
                            exact = [candidate for candidate in candidates if candidate.casefold() == qualified]
                            candidates = exact or candidates
                            status = "RESOLVED" if len(candidates) == 1 else "AMBIGUOUS" if len(candidates) > 1 else "UNRESOLVED_CANDIDATE"
                        elif len(candidates) > 1:
                            status = "AMBIGUOUS"
                        elif len(candidates) == 1:
                            status = "RESOLVED"
                        else:
                            status = "UNRESOLVED_CANDIDATE"
                        callbacks.append({"part": up, "control_id": el.attrib.get("id") or el.attrib.get("idMso"),
                                          "label": el.attrib.get("label"), "attribute": an_local,
                                          "callback": av, "procedure_candidates": candidates, "status": status,
                                          "note": "Static name match only; this does not prove Excel will invoke or successfully execute the callback."})
        missing = [c for c in callbacks if c["status"] == "UNRESOLVED_CANDIDATE"]
        ambiguous = [c for c in callbacks if c["status"] == "AMBIGUOUS"]
        inv["ribbon"] = {"parts": ui_parts, "callbacks": callbacks, "callbacks_total": len(callbacks),
                         "callbacks_missing": len(missing), "callbacks_ambiguous": len(ambiguous),
                         "callbacks_unsupported": sum(c["status"] == "UNSUPPORTED" for c in callbacks),
                         "callbacks_not_checked": sum(c["status"] == "NOT_CHECKED" for c in callbacks),
                         "resolution_status": "PARTIAL" if parse_failed else "NOT_CHECKED" if not vba_parse_complete else "CHECKED_STATICALLY"}
        if missing:
            inv["warnings"].append({"code": "RIBBON_CALLBACK_MISSING",
                                    "message": f"{len(missing)} ribbon callback candidate(s) have no matching VBA procedure: "
                                               + ", ".join(sorted({c['callback'] for c in missing}))[:200]})
        if ambiguous:
            inv["warnings"].append({"code": "RIBBON_CALLBACK_AMBIGUOUS",
                                    "message": f"{len(ambiguous)} callback name(s) match multiple procedures."})
    # Connections
    cpart = find_in_namelist("xl/connections.xml", namelist_set, lower_map)
    if cpart:
        root = ET.fromstring(zf.read(cpart))
        for cn in root.findall(f"{{{NS_MAIN}}}connection"):
            entry = {"id": cn.attrib.get("id"), "name": cn.attrib.get("name"), "type": cn.attrib.get("type"),
                     "refresh_on_load": cn.attrib.get("refreshOnLoad") == "1",
                     "save_password": cn.attrib.get("savePassword") == "1",
                     "odc_file": cn.attrib.get("odcFile")}
            db = cn.find(f"{{{NS_MAIN}}}dbPr")
            if db is not None:
                entry.update(_parse_conn_string(db.attrib.get("connection", "")))
                entry["command"] = (db.attrib.get("command") or "")[:200]
            web = cn.find(f"{{{NS_MAIN}}}webPr")
            if web is not None:
                raw_url = web.attrib.get("url") or ""
                if URL_SECRET_PARAM_RE.search(raw_url) or BASIC_AUTH_URL_RE.search(raw_url):
                    entry["embedded_password"] = True
                red_url = URL_SECRET_PARAM_RE.sub(r"\1<redacted>", raw_url)
                red_url = BASIC_AUTH_URL_RE.sub(r"\1<redacted>@", red_url)
                entry["url"] = red_url
            txt = cn.find(f"{{{NS_MAIN}}}textPr")
            if txt is not None:
                entry["source_file"] = txt.attrib.get("sourceFile")
            entry["power_query"] = "mashup" in (entry.get("provider") or "").lower()
            inv["connections"].append(entry)
            if entry.get("embedded_password") or entry["save_password"]:
                inv["warnings"].append({"code": "CONNECTION_STORES_PASSWORD",
                                        "message": f"Connection '{entry['name']}' stores a password (value redacted)."})
            if entry["refresh_on_load"]:
                inv["warnings"].append({"code": "CONNECTION_REFRESH_ON_LOAD",
                                        "message": f"Connection '{entry['name']}' refreshes when the file opens."})
    inv["query_tables"] = sum(1 for n in namelist_set if n.lower().startswith("xl/querytables/") and n.lower().endswith(".xml"))
    pq = any(c.get("power_query") for c in inv["connections"])
    if not pq:
        for n in namelist_set:
            if n.lower().startswith("customxml/item") and n.lower().endswith(".xml") and "/_rels/" not in n.lower():
                try:
                    with zf.open(n) as fh:
                        if b"DataMashup" in fh.read(400):
                            pq = True
                            break
                except Exception:
                    pass
    inv["power_query_present"] = pq
    return inv


def rank_ref_seeds(seeds, reached, refs_by_cell):
    """v2.4: per-seed downstream counts for ALL seeds, computed on the subgraph of
    cells already reached by the combined BFS (small), so ranking is cheap."""
    import bisect
    by_sheet: Dict[str, List[Tuple[int, int]]] = defaultdict(list)
    for (sh, r, c) in reached:
        by_sheet[sh].append((r, c))
    for sh in by_sheet:
        by_sheet[sh].sort()
    fwd: Dict[Tuple[str, int, int], Set[Tuple[str, int, int]]] = defaultdict(set)
    for cell in reached:
        for (tsh, r1, r2, c1, c2) in refs_by_cell.get(cell, ()):
            lst = by_sheet.get(tsh)
            if not lst:
                continue
            i = bisect.bisect_left(lst, (r1, 0))
            while i < len(lst) and lst[i][0] <= r2:
                r, c = lst[i]
                if c1 <= c <= c2 and (tsh, r, c) != cell:
                    fwd[(tsh, r, c)].add(cell)
                i += 1
    out = []
    for sd in seeds:
        seen = {sd}
        frontier = [sd]
        depth = 0
        while frontier:
            nxt = []
            for cur in frontier:
                for nx in fwd.get(cur, ()):
                    if nx not in seen:
                        seen.add(nx)
                        nxt.append(nx)
            if nxt:
                depth += 1
            frontier = nxt
        seen.discard(sd)
        out.append((sd, seen, depth))
    return out


ERROR_LITERALS = {"#REF!", "#NAME?", "#VALUE!", "#N/A", "#DIV/0!", "#NUM!", "#NULL!", "#GETTING_DATA"}
DYNAMIC_INDIRECTION_FUNCS = {"INDIRECT", "OFFSET", "ADDRESS"}
CELL_COORD_RE = re.compile(r"^(\$?)([A-Z]{1,3})(\$?)(\d+)$", re.IGNORECASE)

FORMULA_TRANSLATE_TOKEN_RE = re.compile(
    r'("(?:""|[^"])*")'
    r"|('(?:''|[^'])*'!)"
    r"|(\[[^\]]*\])"
    r"|(\b[A-Za-z0-9_.]+\s*\()"
    r"|([A-Za-z0-9_.]+\s*!)"
    r"|((?<![A-Za-z0-9_])\$?[A-Za-z]{1,3}\$?[1-9]\d*(?![A-Za-z0-9_(!]))"
)
STRING_LITERAL_RE = re.compile(r'"(?:""|[^"])*"')
SINGLE_QUOTED_RE = re.compile(r"'(?:''|[^'])*'")
EXT_REF_RE = re.compile(
    r"(?:'\[(\d+)\]([^']+)'!|\[(\d+)\]([^!\s()+\-*/^&,<>='\":]+)!|\[(\d+)\]!([^\s()+\-*/^&,<>='\":]+))"
)
QUOTED_3D_SPAN_RE = re.compile(r"'((?:''|[^':])+):((?:''|[^'])+)'!")
UNQUOTED_3D_SPAN_RE = re.compile(r"(?<![\[\w'])([A-Za-z0-9_.\s]+):([A-Za-z0-9_.\s]+)!")
FUNC_CALL_RE = re.compile(r"([A-Z_][A-Z0-9_.]*)\s*\(")
TABLE_REF_RE = re.compile(r"([A-Za-z_][A-Za-z0-9_.]*)\s*\[")
BARE_IDENT_RE = re.compile(r"(?<![A-Za-z0-9_.$'!])([A-Za-z_\\][A-Za-z0-9_.]*)(?![A-Za-z0-9_($!\[])")
INTRA_SHEET_RANGE_RE = re.compile(
    r"(?<![A-Za-z0-9_!'])\$?[A-Za-z]{1,3}\$?[1-9]\d*(?::\$?[A-Za-z]{1,3}\$?[1-9]\d*)?(?![A-Za-z0-9_(!'])"
)
# Qualified sheet references are removed together with their target coordinate.
# Removing only `OtherSheet!` leaves `A1` behind and creates false intra-sheet edges.
QUALIFIED_A1_REF_RE = re.compile(
    r"(?:'(?:''|[^'])*'|[A-Za-z_][A-Za-z0-9_. ]*)!\s*"
    r"(?:\$?[A-Za-z]{1,3}\$?[1-9]\d*"
    r"(?::\$?[A-Za-z]{1,3}\$?[1-9]\d*)?)?"
)


def parse_a1_bounds(ref: str) -> Optional[Tuple[int, int, int, int]]:
    """Return rectangular bounds, without enumerating millions of coordinates."""
    parts = ref.replace("$", "").split(":")
    if len(parts) not in (1, 2):
        return None
    parsed = [parse_a1_coord(x) for x in parts]
    if any(x is None for x in parsed):
        return None
    a, b = parsed[0], parsed[-1]
    return (min(a[0], b[0]), max(a[0], b[0]), min(a[1], b[1]), max(a[1], b[1]))


def build_intra_formula_graph(
    coords: Set[str], references: Dict[str, List[str]],
    max_graph_nodes: int = 50000, max_pairs: int = 4000000,
) -> Tuple[Optional[Dict[str, Set[str]]], str]:
    """Only formula cells can carry calculation cycles. Preserve large ranges symbolically.

    Ranges larger than the old 5,000-cell expansion threshold are matched against
    the *existing formula coordinates*, not truncated to their endpoints.
    Return None instead of silently claiming no cycles when analysis is too large.
    """
    if len(coords) > max_graph_nodes:
        return None, "SKIPPED_FORMULA_NODE_LIMIT"
    parsed = {coord: parse_a1_coord(coord) for coord in coords}
    valid = {key: (v[0], v[1]) for key, v in parsed.items() if v is not None}
    by_row: Dict[int, List[Tuple[int, str]]] = defaultdict(list)
    for key, (r, c) in valid.items():
        by_row[r].append((c, key))
    rows = sorted(by_row)
    import bisect
    adj: Dict[str, Set[str]] = defaultdict(set)
    touched = 0
    for src, refs in references.items():
        adj.setdefault(src, set())
        for ref in refs:
            bounds = parse_a1_bounds(ref)
            if bounds is None:
                continue
            r1, r2, c1, c2 = bounds
            for row in rows[bisect.bisect_left(rows, r1):bisect.bisect_right(rows, r2)]:
                for col, target in by_row[row]:
                    touched += 1
                    if touched > max_pairs:
                        return None, "SKIPPED_GRAPH_PAIR_LIMIT"
                    if c1 <= col <= c2:
                        adj[src].add(target)
    return adj, "EXAMINED_STATIC_A1"



def resolve_opc_target(source_part: str, target_uri: str) -> str:
    target_clean = urllib.parse.unquote(target_uri.strip()).replace("\\", "/")
    if target_clean.startswith("/"):
        return posixpath.normpath(target_clean.lstrip("/"))
    return posixpath.normpath(posixpath.join(posixpath.dirname(source_part), target_clean))


def get_rels_path(part_path: str) -> str:
    return posixpath.normpath(posixpath.join(posixpath.dirname(part_path), "_rels", f"{posixpath.basename(part_path)}.rels"))


def find_in_namelist(target_path: str, namelist_set: Set[str], lower_map: Dict[str, str]) -> Optional[str]:
    return target_path if target_path in namelist_set else lower_map.get(target_path.lower())


def read_rels_map(zf: zipfile.ZipFile, part_path: str, namelist_set: Set[str], lower_map: Dict[str, str]) -> Dict[str, Dict[str, str]]:
    actual_rels = find_in_namelist(get_rels_path(part_path), namelist_set, lower_map)
    if not actual_rels:
        return {}
    root = ET.fromstring(zf.read(actual_rels))
    out: Dict[str, Dict[str, str]] = {}
    for rel in root:
        rid = rel.attrib.get("Id")
        if not rid:
            continue
        raw_t = rel.attrib.get("Target", "")
        tmode = rel.attrib.get("TargetMode", "Internal")
        out[rid] = {
            "id": rid,
            "raw_target": raw_t,
            "resolved_target": raw_t if tmode == "External" else resolve_opc_target(part_path, raw_t),
            "type": rel.attrib.get("Type", ""),
            "target_mode": tmode,
        }
    return out


def col_to_idx(col_str: str) -> int:
    idx = 0
    for ch in col_str.upper():
        idx = idx * 26 + (ord(ch) - ord("A") + 1)
    return idx


def idx_to_col(idx: int) -> str:
    chars: List[str] = []
    while idx > 0:
        idx, rem = divmod(idx - 1, 26)
        chars.append(chr(ord("A") + rem))
    return "".join(reversed(chars))


def parse_a1_coord(coord: str) -> Optional[Tuple[int, int, bool, bool]]:
    m = CELL_COORD_RE.match(coord.strip())
    if not m:
        return None
    col_abs_s, col_s, row_abs_s, row_s = m.groups()
    r, c = int(row_s), col_to_idx(col_s)
    if not (1 <= r <= EXCEL_MAX_ROW and 1 <= c <= EXCEL_MAX_COL):
        return None
    return r, c, bool(row_abs_s), bool(col_abs_s)


def translate_formula_references(formula: str, master_coord: str, slave_coord: str) -> str:
    if not formula or master_coord == slave_coord:
        return formula
    mp, sp = parse_a1_coord(master_coord), parse_a1_coord(slave_coord)
    if not mp or not sp:
        return formula
    d_row, d_col = sp[0] - mp[0], sp[1] - mp[1]
    if d_row == 0 and d_col == 0:
        return formula

    def _repl(match: re.Match) -> str:
        a1_tok = match.group(6)
        if not a1_tok:
            return match.group(0)
        p = parse_a1_coord(a1_tok)
        if not p:
            return a1_tok
        r, c, r_abs, c_abs = p
        nr, nc = (r if r_abs else r + d_row), (c if c_abs else c + d_col)
        if not (1 <= nr <= EXCEL_MAX_ROW and 1 <= nc <= EXCEL_MAX_COL):
            return "#REF!"
        return f"{'$' if c_abs else ''}{idx_to_col(nc)}{'$' if r_abs else ''}{nr}"

    return FORMULA_TRANSLATE_TOKEN_RE.sub(_repl, formula)


def normalize_formula_r1c1(formula: str, cell_coord: str) -> str:
    cp = parse_a1_coord(cell_coord)
    if not cp or not formula:
        return formula
    br, bc, _, _ = cp

    def _repl(match: re.Match) -> str:
        a1_tok = match.group(6)
        if not a1_tok:
            return match.group(0)
        p = parse_a1_coord(a1_tok)
        if not p:
            return a1_tok
        r, c, r_abs, c_abs = p
        rp = f"R{r}" if r_abs else (f"R[{r - br}]" if r != br else "R")
        cp_s = f"C{c}" if c_abs else (f"C[{c - bc}]" if c != bc else "C")
        return f"{rp}{cp_s}"

    return FORMULA_TRANSLATE_TOKEN_RE.sub(_repl, formula)


def expand_a1_range(range_str: str, max_cells: int = 5000) -> List[str]:
    clean = range_str.replace("$", "").strip()
    if ":" not in clean:
        return [clean.upper()] if parse_a1_coord(clean) else []
    l_s, r_s = clean.split(":", 1)
    p1, p2 = parse_a1_coord(l_s), parse_a1_coord(r_s)
    if not p1 or not p2:
        return []
    r1, r2 = min(p1[0], p2[0]), max(p1[0], p2[0])
    c1, c2 = min(p1[1], p2[1]), max(p1[1], p2[1])
    if (r2 - r1 + 1) * (c2 - c1 + 1) > max_cells:
        return [f"{idx_to_col(c1)}{r1}", f"{idx_to_col(c2)}{r2}"]
    return [f"{idx_to_col(c)}{r}" for r in range(r1, r2 + 1) for c in range(c1, c2 + 1)]


def find_sccs_and_self_loops(adj: Dict[str, Set[str]]) -> List[List[str]]:
    index = 0
    indices: Dict[str, int] = {}
    lowlink: Dict[str, int] = {}
    stack: List[str] = []
    on_stack: Set[str] = set()
    cycles: List[List[str]] = []
    all_nodes = set(adj.keys()) | {v for targets in adj.values() for v in targets}

    for start_node in sorted(all_nodes):
        if start_node in indices:
            continue
        call_stack: List[Tuple[str, List[str], int]] = [(start_node, sorted(adj.get(start_node, set())), 0)]
        indices[start_node] = lowlink[start_node] = index
        index += 1
        stack.append(start_node)
        on_stack.add(start_node)

        while call_stack:
            u, nbrs, n_idx = call_stack[-1]
            if n_idx < len(nbrs):
                v = nbrs[n_idx]
                call_stack[-1] = (u, nbrs, n_idx + 1)
                if v not in indices:
                    indices[v] = lowlink[v] = index
                    index += 1
                    stack.append(v)
                    on_stack.add(v)
                    call_stack.append((v, sorted(adj.get(v, set())), 0))
                elif v in on_stack:
                    lowlink[u] = min(lowlink[u], indices[v])
            else:
                call_stack.pop()
                if call_stack:
                    lowlink[call_stack[-1][0]] = min(lowlink[call_stack[-1][0]], lowlink[u])
                if lowlink[u] == indices[u]:
                    scc: List[str] = []
                    while True:
                        w = stack.pop()
                        on_stack.remove(w)
                        scc.append(w)
                        if w == u:
                            break
                    scc.reverse()
                    if len(scc) > 1 or (len(scc) == 1 and scc[0] in adj.get(scc[0], set())):
                        cycles.append(scc)
    return cycles


def check_environment() -> Dict[str, Any]:
    return {
        "python_version": sys.version.split()[0],
        "lxml_available": USING_LXML,
        "xml_engine": "lxml.etree" if USING_LXML else "xml.etree.ElementTree",
        "openpyxl_tokenizer_available": importlib.util.find_spec("openpyxl") is not None,
        "vba_inspector_available": HAS_VBA_INSPECTOR,
        "pyxlsb_available": importlib.util.find_spec("pyxlsb") is not None,
        "xlrd_available": importlib.util.find_spec("xlrd") is not None,
        "libreoffice_cli_available": shutil.which("libreoffice") is not None or shutil.which("soffice") is not None,
    }


def compute_sha256(filepath: str) -> str:
    h = hashlib.sha256()
    with open(filepath, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def analyze_workbook(
    filepath: str, level: int = 3, max_range_expand: int = 5000, convert_legacy: bool = False,
    include_rtd: bool = True, skip_vba_parser: bool = False,
) -> Dict[str, Any]:
    sha256_before = compute_sha256(filepath)
    file_size = os.path.getsize(filepath)
    capabilities = check_environment()
    structural_errors: List[Dict[str, str]] = []

    with zipfile.ZipFile(filepath, "r") as zf:
        infolist = zf.infolist()
        namelist_set = {i.filename for i in infolist}
        lower_map = {n.lower(): n for n in namelist_set}
        size_map = {i.filename: i.file_size for i in infolist}

        wb_part = find_in_namelist("xl/workbook.xml", namelist_set, lower_map)
        if not wb_part:
            return {
                "schema_version": "2.4.0", "inspection_level": level, "status": "FAILED",
                "structural_errors": [{"code": "MISSING_WORKBOOK_XML", "message": "xl/workbook.xml missing"}],
                "quality_gates": {"G1_preflight_integrity": "FAIL", "G9_source_preserved": True},
            }

        wb_xml = ET.fromstring(zf.read(wb_part))
        wb_rels = read_rels_map(zf, wb_part, namelist_set, lower_map)
        wb_pr = wb_xml.find(f"{{{NS_MAIN}}}workbookPr")
        date1904 = wb_pr is not None and wb_pr.attrib.get("date1904") in ("1", "true", "True")
        wb_codename = wb_pr.attrib.get("codeName", "ThisWorkbook") if wb_pr is not None else "ThisWorkbook"
        calc_pr = wb_xml.find(f"{{{NS_MAIN}}}calcPr")
        calc_mode = calc_pr.attrib.get("calcMode", "auto") if calc_pr is not None else "auto"
        iterate = calc_pr is not None and calc_pr.attrib.get("iterate") in ("1", "true", "True")

        sheets_meta: List[Dict[str, Any]] = []
        sheet_names_ordered: List[str] = []
        sheet_names_set: Set[str] = set()
        missing_sheet_xmls: List[str] = []

        for idx, sh in enumerate(wb_xml.findall(f".//{{{NS_MAIN}}}sheet"), start=1):
            name = sh.attrib.get("name", f"Sheet{idx}")
            sid = sh.attrib.get("sheetId", str(idx))
            state = sh.attrib.get("state", "visible")
            rid = sh.attrib.get(f"{{{NS_REL}}}id", "")
            rinfo = wb_rels.get(rid)
            resolved = rinfo["resolved_target"] if rinfo else ""
            actual = find_in_namelist(resolved, namelist_set, lower_map) if resolved else None
            if not rinfo or not actual:
                missing_sheet_xmls.append(name)
                structural_errors.append({
                    "code": "MISSING_WORKSHEET_XML", "sheet_name": name, "r_id": rid,
                    "resolved_target": resolved, "message": f"Missing XML for sheet '{name}' ({resolved}).",
                })
            sheets_meta.append({
                "index": idx, "sheet_id": sid, "name": name, "state": state,
                "xml_path": actual or resolved, "xml_exists": actual is not None,
                "uncompressed_xml_bytes": size_map.get(actual, 0) if actual else 0,
            })
            sheet_names_ordered.append(name)
            sheet_names_set.add(name)

        ext_links: Dict[int, Dict[str, Any]] = {}
        for idx, er in enumerate(wb_xml.findall(f".//{{{NS_MAIN}}}externalReference"), start=1):
            rid = er.attrib.get(f"{{{NS_REL}}}id", "")
            rinfo = wb_rels.get(rid)
            ext_part = find_in_namelist(rinfo["resolved_target"], namelist_set, lower_map) if rinfo else None
            targets = [urllib.parse.unquote(v["raw_target"]) for v in read_rels_map(zf, ext_part, namelist_set, lower_map).values()] if ext_part else []
            primary = targets[0] if targets else (ext_part or "")
            ext_links[idx] = {"index": idx, "xml_part": ext_part or "", "filename": primary.replace("\\", "/").split("/")[-1], "full_target": primary}

        defined_names_summary = Counter()
        custom_defined_names: List[Dict[str, Any]] = []
        for dn in wb_xml.findall(f".//{{{NS_MAIN}}}definedName"):
            dname = dn.attrib.get("name", "")
            dval = (dn.text or "").strip()
            lid = dn.attrib.get("localSheetId")
            scope = sheets_meta[int(lid)]["name"] if lid is not None and lid.isdigit() and int(lid) < len(sheets_meta) else "Global"
            if dname.startswith("IQ_"):
                defined_names_summary["CapitalIQ Add-In (IQ_*)"] += 1
            elif dname.startswith(("_AtRisk_", "Risk")):
                defined_names_summary["@RISK Simulation Add-In (_AtRisk_*/Risk*)"] += 1
            elif dname.startswith(("_xlpm.", "_xleta.")):
                defined_names_summary["Excel LAMBDA Parameters (_xlpm/_xleta)"] += 1
            else:
                defined_names_summary["Custom / Built-in Defined Names"] += 1
                custom_defined_names.append({"name": dname, "scope": scope, "formula": dval, "has_ref_error": "#REF!" in dval})

        sheet_audits: Dict[str, Dict[str, Any]] = {}
        for sm in sheets_meta:
            sname = sm["name"]
            dim_ref, codename = "A1", None
            if sm["xml_exists"]:
                with zf.open(sm["xml_path"], "r") as wf:
                    for _ev, el in ET.iterparse(wf, events=("start",)):
                        if el.tag == f"{{{NS_MAIN}}}sheetPr":
                            codename = el.attrib.get("codeName")
                        elif el.tag == f"{{{NS_MAIN}}}dimension":
                            dim_ref = el.attrib.get("ref", "A1")
                            break
                        elif el.tag == f"{{{NS_MAIN}}}sheetData":
                            break
            sheet_audits[sname] = {
                "index": sm["index"], "name": sname, "state": sm["state"],
                "status": "OK" if sm["xml_exists"] else "MISSING_XML",
                "xml_path": sm["xml_path"], "codename": codename or f"Sheet{sm['sheet_id']}",
                "dimension": dim_ref, "sparse_million_row_flag": "1048576" in dim_ref,
                "xml_cell_nodes_total": None if level == 1 else 0,
                "populated_cells": None if level == 1 else 0,
                "styled_blank_cells": None if level == 1 else 0,
                "formula_cells_total": None if level == 1 else 0,
                "formula_cells_explicit_or_master": None if level == 1 else 0,
                "formula_cells_shared_slaves": None if level == 1 else 0,
                "uncalculated_formula_cells": None if level == 1 else 0,
                "shared_formula_groups": None if level == 1 else 0,
                "error_counts": None if level == 1 else {},
                "top_functions": None if level == 1 else [],
                "data_validations": None if level == 1 else [],
                "tables": None if level == 1 else [],
                "charts": None if level == 1 else [],
                "pivot_tables": None if level == 1 else [],
                "dynamic_indirection_cells": None if level == 1 else [],
                "dynamic_indirection_cells_total": None if level == 1 else 0,
                "dynamic_indirection_function_counts": None if level == 1 else {},
                "dynamic_indirection_samples_truncated": None if level == 1 else False,
                "formula_ref_error_cells": None if level == 1 else 0,
                "formula_ref_error_samples": None if level == 1 else [],
                "ref_blast_radius_cells": None if level == 1 else 0,
                "dependency_completeness": None if level == 1 else "COMPLETE_STATIC",
                "dependency_completeness_reasons": None if level == 1 else [],
                "intra_sheet_cycles": None if level < 3 else [],
            "intra_sheet_graph_status": None if level < 3 else "PENDING",
                "formula_patterns_count": None if level < 3 else 0,
                "tier": None, "role": "Not Evaluated at Level 1" if level == 1 else "",
            }

        if level == 1:
            g1_ok = len(missing_sheet_xmls) == 0
            return {
                "schema_version": "2.4.0", "inspection_level": 1, "status": "OK" if g1_ok else "FAILED",
                "structural_errors": structural_errors, "capabilities_used": capabilities,
                "workbook_meta": {"filepath": filepath, "sha256": sha256_before, "file_size_bytes": file_size, "date1904": date1904, "calc_mode": calc_mode, "iterate": iterate},
                "summary": {
                    "sheet_count": len(sheets_meta), "missing_worksheet_xml_count": len(missing_sheet_xmls),
                    "defined_names_total": sum(defined_names_summary.values()), "external_links_defined": len(ext_links),
                    "xml_cell_nodes_total": None, "populated_cells": None, "styled_blank_cells": None,
                    "formula_cells_total": None, "total_internal_cross_sheet_edges": None, "total_internal_cross_sheet_refs": None,
                },
                "sheets": [sheet_audits[s["name"]] for s in sheets_meta],
                "internal_edges": None, "quality_gates": {"G1_preflight_integrity": "PASS" if g1_ok else "FAIL", "G9_source_preserved": sha256_before == compute_sha256(filepath)},
            }

        sorted_sheets = sorted(sheet_names_set, key=len, reverse=True)
        escaped_sheets = [re.escape(s.replace("'", "''")) + "|" + re.escape(s) for s in sorted_sheets]
        internal_sheet_pattern = re.compile(r"(?:'(" + "|".join(escaped_sheets) + r")'|(?<![\[\w'])(" + "|".join(escaped_sheets) + r"))!") if escaped_sheets else None

        def extract_sheets_from_expr(expr: str) -> Set[str]:
            if not expr:
                return set()
            no_ext = EXT_REF_RE.sub(" ", STRING_LITERAL_RE.sub('""', expr))
            res: Set[str] = set()
            for m3 in QUOTED_3D_SPAN_RE.finditer(no_ext):
                s1, s2 = m3.group(1).replace("''", "'"), m3.group(2).replace("''", "'")
                if s1 in sheet_names_set and s2 in sheet_names_set:
                    i1, i2 = sheet_names_ordered.index(s1), sheet_names_ordered.index(s2)
                    res.update(sheet_names_ordered[min(i1, i2) : max(i1, i2) + 1])
            no_q3d = QUOTED_3D_SPAN_RE.sub(" ", no_ext)
            for m3u in UNQUOTED_3D_SPAN_RE.finditer(no_q3d):
                s1, s2 = m3u.group(1).strip(), m3u.group(2).strip()
                if s1 in sheet_names_set and s2 in sheet_names_set:
                    i1, i2 = sheet_names_ordered.index(s1), sheet_names_ordered.index(s2)
                    res.update(sheet_names_ordered[min(i1, i2) : max(i1, i2) + 1])
            no_3d = UNQUOTED_3D_SPAN_RE.sub(" ", no_q3d)
            if internal_sheet_pattern:
                for im in internal_sheet_pattern.finditer(no_3d):
                    rsh = (im.group(1) or im.group(2)).replace("''", "'")
                    if rsh in sheet_names_set:
                        res.add(rsh)
            return res

        defined_name_targets: Dict[Tuple[str, str], Set[str]] = {}
        for dn in custom_defined_names:
            if not dn["name"].startswith("_xlnm."):
                ts = extract_sheets_from_expr(dn["formula"])
                if ts:
                    defined_name_targets[(dn["scope"], dn["name"].upper())] = ts

        pivot_cache_sources: Dict[str, str] = {}
        for pc_el in wb_xml.findall(f".//{{{NS_MAIN}}}pivotCache"):
            cid, rid = pc_el.attrib.get("cacheId", ""), pc_el.attrib.get(f"{{{NS_REL}}}id", "")
            if rid in wb_rels:
                pc_part = find_in_namelist(wb_rels[rid]["resolved_target"], namelist_set, lower_map)
                if pc_part:
                    ws_src = ET.fromstring(zf.read(pc_part)).find(f".//{{{NS_MAIN}}}worksheetSource")
                    if ws_src is not None and ws_src.attrib.get("sheet"):
                        pivot_cache_sources[cid] = ws_src.attrib["sheet"]

        table_host_map: Dict[str, str] = {}
        chart_edges = defaultdict(lambda: {"count": 0, "charts": []})
        pivot_edges = defaultdict(lambda: {"count": 0, "pivot_tables": []})

        for sm in sheets_meta:
            if not sm["xml_exists"]:
                continue
            sname, ws_part = sm["name"], sm["xml_path"]
            for rinfo in read_rels_map(zf, ws_part, namelist_set, lower_map).values():
                rtype = rinfo["type"]
                rtarget = find_in_namelist(rinfo["resolved_target"], namelist_set, lower_map)
                if not rtarget:
                    continue
                if rtype.endswith("/table"):
                    t_root = ET.fromstring(zf.read(rtarget))
                    for k in (t_root.attrib.get("name", ""), t_root.attrib.get("displayName", "")):
                        if k:
                            table_host_map[k.upper()] = sname
                    if sheet_audits[sname]["tables"] is not None:
                        sheet_audits[sname]["tables"].append({
                            "name": t_root.attrib.get("displayName") or t_root.attrib.get("name", ""),
                            "ref": t_root.attrib.get("ref", ""),
                            "table_type": t_root.attrib.get("tableType", "worksheet"),
                            "part": rtarget,
                        })
                elif rtype.endswith("/drawing"):
                    for dr in read_rels_map(zf, rtarget, namelist_set, lower_map).values():
                        if dr["type"].endswith("/chart"):
                            c_part = find_in_namelist(dr["resolved_target"], namelist_set, lower_map)
                            if c_part:
                                c_root = ET.fromstring(zf.read(c_part))
                                c_refs = [(f_el.text or "").strip() for f_el in c_root.findall(f".//{{{NS_CHART}}}f")]
                                c_src: Set[str] = set()
                                for ref_txt in c_refs:
                                    c_src |= extract_sheets_from_expr(ref_txt)
                                sheet_audits[sname]["charts"].append({
                                    "kind": "chart",
                                    "part": c_part,
                                    "series_ref_count": len(c_refs),
                                    "source_sheets": sorted(c_src),
                                    "plots_own_sheet_only": c_src <= {sname},
                                })
                                for f_el in c_root.findall(f".//{{{NS_CHART}}}f"):
                                    for rsh in extract_sheets_from_expr(f_el.text or ""):
                                        if rsh != sname:
                                            ce = chart_edges[(sname, rsh)]
                                            ce["count"] += 1
                                            if c_part not in ce["charts"]:
                                                ce["charts"].append(c_part)
                    for dr in read_rels_map(zf, rtarget, namelist_set, lower_map).values():
                        if dr["type"].lower().endswith("/chartex"):
                            c_part = find_in_namelist(dr["resolved_target"], namelist_set, lower_map)
                            if c_part:
                                c_root = ET.fromstring(zf.read(c_part))
                                c_refs = [(f_el.text or "").strip() for f_el in c_root.iter(f"{{{NS_CHARTEX}}}f")]
                                c_src = set()
                                for ref_txt in c_refs:
                                    c_src |= extract_sheets_from_expr(ref_txt)
                                sheet_audits[sname]["charts"].append({
                                    "kind": "chartEx",
                                    "part": c_part,
                                    "series_ref_count": len(c_refs),
                                    "source_sheets": sorted(c_src),
                                    "plots_own_sheet_only": c_src <= {sname},
                                })
                                for rsh in c_src:
                                    if rsh != sname:
                                        ce = chart_edges[(sname, rsh)]
                                        ce["count"] += 1
                                        if c_part not in ce["charts"]:
                                            ce["charts"].append(c_part)
                elif rtype.endswith("/pivotTable"):
                    pt_root = ET.fromstring(zf.read(rtarget))
                    cid = pt_root.attrib.get("cacheId", "")
                    src_sh = pivot_cache_sources.get(cid)
                    if src_sh and src_sh in sheet_names_set and src_sh != sname:
                        pe = pivot_edges[(sname, src_sh)]
                        pe["count"] += 1
                        pe["pivot_tables"].append(pt_root.attrib.get("name", os.path.basename(rtarget)))
                    sheet_audits[sname]["pivot_tables"].append({
                        "name": pt_root.attrib.get("name", os.path.basename(rtarget)),
                        "part": rtarget, "cache_id": cid, "source_sheet": src_sh,
                    })

        refs_by_cell: Dict[Tuple[str, int, int], List[Tuple[str, int, int, int, int]]] = {}
        ref_seeds: List[Tuple[str, int, int]] = []
        cached_ref_cells: Set[Tuple[str, int, int]] = set()
        cached_ref_static: Set[Tuple[str, int, int]] = set()
        internal_edges = defaultdict(lambda: {"count": 0, "samples": [], "mechanisms": Counter()})
        external_edges = defaultdict(lambda: {"count": 0, "tabs": Counter(), "samples": []})
        global_functions = Counter()
        unresolved_slaves = 0

        for sm in sheets_meta:
            if not sm["xml_exists"]:
                continue
            sname, ws_part = sm["name"], sm["xml_path"]
            audit = sheet_audits[sname]
            PROGRESS.update(stage="cell_scan", sheet=sname, sheet_idx=sm["index"], sheet_total=len(sheets_meta))
            shared_masters: Dict[str, Tuple[str, str]] = {}
            deferred_slaves: List[Tuple[str, str]] = []
            sheet_funcs, sheet_errors, r1c1_patterns = Counter(), Counter(), Counter()
            intra_references: Dict[str, List[str]] = defaultdict(list)
            formula_coords: Set[str] = set()
            intra_graph_status = "NOT_REQUESTED"

            def process_formula(coord: str, ft: str) -> None:
                if not ft:
                    return
                if level >= 3:
                    formula_coords.add(coord)
                    r1c1_patterns[normalize_formula_r1c1(ft, coord)] += 1
                ft_no_str = STRING_LITERAL_RE.sub('""', ft)
                rc_here = parse_a1_coord(coord) if (level >= 2 and coord) else None
                if "#REF!" in ft_no_str.upper():
                    audit["formula_ref_error_cells"] += 1
                    if rc_here:
                        ref_seeds.append((sname, rc_here[0], rc_here[1]))
                    if len(audit["formula_ref_error_samples"]) < FORMULA_ERROR_SAMPLE_CAP:
                        audit["formula_ref_error_samples"].append({"cell": coord, "formula": ft[:120]})
                for em in EXT_REF_RE.finditer(ft_no_str):
                    ext_id = int(em.group(1) or em.group(3) or em.group(5))
                    ext_tab = em.group(2) or em.group(4) or em.group(6) or ""
                    ee = external_edges[(sname, ext_id)]
                    ee["count"] += 1
                    ee["tabs"][ext_tab] += 1
                    if len(ee["samples"]) < 2:
                        ee["samples"].append(f"{coord}: ={ft[:100]}")

                ft_int = EXT_REF_RE.sub(" ", ft_no_str)
                for m3 in QUOTED_3D_SPAN_RE.finditer(ft_int):
                    s1, s2 = m3.group(1).replace("''", "'"), m3.group(2).replace("''", "'")
                    if s1 in sheet_names_set and s2 in sheet_names_set:
                        i1, i2 = sheet_names_ordered.index(s1), sheet_names_ordered.index(s2)
                        for rsh in sheet_names_ordered[min(i1, i2) : max(i1, i2) + 1]:
                            if rsh != sname:
                                ie = internal_edges[(sname, rsh)]
                                ie["count"] += 1
                                ie["mechanisms"]["3d_span"] += 1
                                if len(ie["samples"]) < 2:
                                    ie["samples"].append(f"{coord}: ={ft[:100]}")
                ft_no_q3d = QUOTED_3D_SPAN_RE.sub(" ", ft_int)
                for m3u in UNQUOTED_3D_SPAN_RE.finditer(ft_no_q3d):
                    s1, s2 = m3u.group(1).strip(), m3u.group(2).strip()
                    if s1 in sheet_names_set and s2 in sheet_names_set:
                        i1, i2 = sheet_names_ordered.index(s1), sheet_names_ordered.index(s2)
                        for rsh in sheet_names_ordered[min(i1, i2) : max(i1, i2) + 1]:
                            if rsh != sname:
                                ie = internal_edges[(sname, rsh)]
                                ie["count"] += 1
                                ie["mechanisms"]["3d_span"] += 1
                                if len(ie["samples"]) < 2:
                                    ie["samples"].append(f"{coord}: ={ft[:100]}")
                ft_no_3d = UNQUOTED_3D_SPAN_RE.sub(" ", ft_no_q3d)

                if internal_sheet_pattern:
                    for im in internal_sheet_pattern.finditer(ft_no_3d):
                        rsh = (im.group(1) or im.group(2)).replace("''", "'")
                        if rsh in sheet_names_set and rsh != sname:
                            ie = internal_edges[(sname, rsh)]
                            ie["count"] += 1
                            ie["mechanisms"]["direct_cell_ref"] += 1
                            if len(ie["samples"]) < 2:
                                ie["samples"].append(f"{coord}: ={ft[:100]}")

                ft_unquoted = SINGLE_QUOTED_RE.sub(" ", ft_no_3d)
                # Remove the *entire* Sheet!A1 or 'Sheet'!A1:B10 token, never just
                # the Sheet! prefix (which caused false self-cycles in v2).
                ft_same_sheet = QUALIFIED_A1_REF_RE.sub(" ", ft_no_str)
                ft_same_sheet = SINGLE_QUOTED_RE.sub(" ", ft_same_sheet)
                if level >= 3 and coord:
                    intra_references[coord].extend(m.group(0) for m in INTRA_SHEET_RANGE_RE.finditer(ft_same_sheet))
                if rc_here:
                    cell_refs: List[Tuple[str, int, int, int, int]] = []
                    for m in INTRA_SHEET_RANGE_RE.finditer(ft_same_sheet):
                        b = parse_a1_bounds(m.group(0))
                        if b:
                            cell_refs.append((sname, b[0], b[1], b[2], b[3]))
                    for xm in XSHEET_A1_RE.finditer(ft_int):
                        tsh = (xm.group(1) or xm.group(2) or "").replace("''", "'")
                        if tsh in sheet_names_set:
                            b = parse_a1_bounds(xm.group(3))
                            if b:
                                cell_refs.append((tsh, b[0], b[1], b[2], b[3]))
                    if cell_refs:
                        refs_by_cell[(sname, rc_here[0], rc_here[1])] = cell_refs

                for tm in TABLE_REF_RE.finditer(ft_unquoted):
                    hsh = table_host_map.get(tm.group(1).upper())
                    if hsh and hsh != sname:
                        ie = internal_edges[(sname, hsh)]
                        ie["count"] += 1
                        ie["mechanisms"]["structured_table"] += 1

                if defined_name_targets:
                    for bm in BARE_IDENT_RE.finditer(ft_unquoted):
                        ident = bm.group(1).upper()
                        if ident in ("TRUE", "FALSE") or parse_a1_coord(ident):
                            continue
                        for dsh in defined_name_targets.get((sname, ident)) or defined_name_targets.get(("Global", ident)) or set():
                            if dsh != sname:
                                ie = internal_edges[(sname, dsh)]
                                ie["count"] += 1
                                ie["mechanisms"]["defined_name"] += 1

                cell_dyn: Set[str] = set()
                for fm in FUNC_CALL_RE.finditer(ft_unquoted.upper()):
                    fn = re.sub(r"^(?:_XLFN\.|_XLWS\.)+", "", fm.group(1))
                    sheet_funcs[fn] += 1
                    global_functions[fn] += 1
                    if fn in DYNAMIC_INDIRECTION_FUNCS:
                        cell_dyn.add(fn)
                if cell_dyn:
                    audit["dynamic_indirection_cells_total"] += 1
                    dcounts = audit["dynamic_indirection_function_counts"]
                    for fn in cell_dyn:
                        dcounts[fn] = dcounts.get(fn, 0) + 1
                    if "PARTIAL_DYNAMIC_INDIRECTION" not in audit["dependency_completeness_reasons"]:
                        audit["dependency_completeness_reasons"].append("PARTIAL_DYNAMIC_INDIRECTION")
                    if len(audit["dynamic_indirection_cells"]) < DYNAMIC_SAMPLE_CAP:
                        audit["dynamic_indirection_cells"].append({"cell": coord, "functions": sorted(cell_dyn), "function": sorted(cell_dyn)[0], "formula": ft[:100]})
                    else:
                        audit["dynamic_indirection_samples_truncated"] = True

            with zf.open(ws_part, "r") as wf:
                for _ev, elem in ET.iterparse(wf, events=("end",)):
                    if elem.tag == f"{{{NS_MAIN}}}c":
                        audit["xml_cell_nodes_total"] += 1
                        PROGRESS["cells"] += 1
                        coord = elem.attrib.get("r", "")
                        ctype = elem.attrib.get("t")
                        f_el = elem.find(f"{{{NS_MAIN}}}f")
                        v_el = elem.find(f"{{{NS_MAIN}}}v")
                        is_el = elem.find(f"{{{NS_MAIN}}}is")
                        has_f = f_el is not None
                        has_v = v_el is not None and bool(v_el.text)
                        v_txt = v_el.text.strip() if has_v and v_el.text else ""

                        if has_f or has_v or is_el is not None:
                            audit["populated_cells"] += 1
                        else:
                            audit["styled_blank_cells"] += 1

                        if ctype == "e" or v_txt in ERROR_LITERALS:
                            sheet_errors[v_txt or "ERROR"] += 1
                            if (v_txt == "#REF!") and level >= 2:
                                _rc = parse_a1_coord(coord)
                                if _rc:
                                    cached_ref_cells.add((sname, _rc[0], _rc[1]))
                                    if not has_f:
                                        cached_ref_static.add((sname, _rc[0], _rc[1]))

                        if has_f and f_el is not None:
                            audit["formula_cells_total"] += 1
                            if not has_v and ctype != "str":
                                audit["uncalculated_formula_cells"] += 1
                            f_type, si = f_el.attrib.get("t", ""), f_el.attrib.get("si")
                            raw_ft = f_el.text.strip() if f_el.text else ""
                            if raw_ft:
                                audit["formula_cells_explicit_or_master"] += 1
                                if f_type == "shared" and si is not None:
                                    shared_masters[si] = (coord, raw_ft)
                                process_formula(coord, raw_ft)
                            elif f_type == "shared" and si is not None:
                                audit["formula_cells_shared_slaves"] += 1
                                if si in shared_masters:
                                    mc, mft = shared_masters[si]
                                    process_formula(coord, translate_formula_references(mft, mc, coord))
                                else:
                                    deferred_slaves.append((coord, si))
                            else:
                                audit["formula_cells_explicit_or_master"] += 1
                        elem.clear()
                    elif elem.tag == f"{{{NS_MAIN}}}row":
                        elem.clear()
                        # lxml can detach processed rows, avoiding an ever-growing
                        # list of empty row elements for million-row worksheets.
                        if USING_LXML and elem.getparent() is not None:
                            elem.getparent().remove(elem)

            for coord, si in deferred_slaves:
                if si in shared_masters:
                    mc, mft = shared_masters[si]
                    process_formula(coord, translate_formula_references(mft, mc, coord))
                else:
                    unresolved_slaves += 1

            audit["shared_formula_groups"] = len(shared_masters)
            audit["error_counts"] = dict(sheet_errors)
            audit["top_functions"] = sheet_funcs.most_common(8)
            if level >= 3:
                audit["formula_patterns_count"] = len(r1c1_patterns)
                PROGRESS["stage"] = "intra_sheet_graph"
                graph, intra_graph_status = build_intra_formula_graph(formula_coords, intra_references)
                audit["intra_sheet_graph_status"] = intra_graph_status
                audit["intra_sheet_cycles"] = find_sccs_and_self_loops(graph) if graph is not None else None
                if graph is None:
                    audit["dependency_completeness_reasons"].append("PARTIAL_INTRA_GRAPH_SIZE_LIMIT")
            # v2.2: primary status keeps the FIRST reason (back-compatible); all
            # reasons are retained in dependency_completeness_reasons.
            if audit["dependency_completeness_reasons"]:
                audit["dependency_completeness"] = audit["dependency_completeness_reasons"][0]

        ref_blast_radius = None
        if level >= 2:
            PROGRESS.update(stage="ref_blast_radius", sheet=None)
            def _a1(r: int, c: int) -> str:
                return f"{col_num_to_letter(c)}{r}"
            if ref_seeds:
                reached, max_depth, trunc = compute_ref_blast_radius(ref_seeds, refs_by_cell, sheet_names_set)
                downstream = {k: d for k, d in reached.items() if d > 0}
                by_sheet_cnt = Counter(k[0] for k in downstream)
                for shn, cnt in by_sheet_cnt.items():
                    sheet_audits[shn]["ref_blast_radius_cells"] = cnt
                PROGRESS["stage"] = "ref_blast_rank"
                ranked = rank_ref_seeds(ref_seeds, reached, refs_by_cell)
                ranked.sort(key=lambda x: (-len(x[1]), x[0]))
                per_seed = []
                for sd, ds_set, sd_depth in ranked[:BLAST_SAMPLE_CAP]:
                    ds = sorted(ds_set)
                    per_seed.append({
                        "seed": f"{sd[0]}!{_a1(sd[1], sd[2])}",
                        "downstream_cells": len(ds),
                        "downstream_sheets": sorted({k[0] for k in ds}),
                        "max_depth": sd_depth, "truncated": trunc,
                        "sample_downstream": [f"{k[0]}!{_a1(k[1], k[2])}" for k in ds[:10]],
                    })
                seeds_zero = sum(1 for _sd, ds_set, _d in ranked if not ds_set)
                cached_hit = len(cached_ref_cells & set(reached))
                ref_blast_radius = {
                    "seed_cells": len(ref_seeds),
                    "downstream_formula_cells": len(downstream),
                    "downstream_by_sheet": dict(sorted(by_sheet_cnt.items())),
                    "max_depth": max_depth,
                    "truncated": trunc,
                    "cached_ref_cells_total": len(cached_ref_cells),
                    "cached_ref_cells_explained": cached_hit,
                    "cached_ref_cells_unexplained": len(cached_ref_cells) - cached_hit,
                    "per_seed": per_seed,
                    "per_seed_ranking": "by downstream_cells, descending (v2.4)",
                    "per_seed_truncated": len(ref_seeds) > BLAST_SAMPLE_CAP,
                    "seeds_with_no_downstream": seeds_zero,
                    "seeds_by_sheet": dict(sorted(Counter(sd[0] for sd in ref_seeds).items())),
                    "cached_ref_static_values": len(cached_ref_static),
                    "cached_ref_unexplained_formulas": len(cached_ref_cells - set(reached) - cached_ref_static),
                    "cached_ref_static_by_sheet": dict(sorted(Counter(k[0] for k in cached_ref_static).items())),
                    "cached_ref_static_samples": [f"{k[0]}!{_a1(k[1], k[2])}" for k in sorted(cached_ref_static)[:10]],
                    "limitations": [
                        "Follows static A1 refs (same-sheet and Sheet!A1) only",
                        "Not followed: defined names, structured tables, whole row/column refs, INDIRECT/OFFSET targets, chart series",
                    ],
                }
            else:
                ref_blast_radius = {"seed_cells": 0, "downstream_formula_cells": 0,
                                    "cached_ref_cells_total": len(cached_ref_cells),
                                    "cached_ref_cells_explained": 0,
                                    "cached_ref_cells_unexplained": len(cached_ref_cells),
                                    "cached_ref_static_values": len(cached_ref_static),
                                    "cached_ref_unexplained_formulas": len(cached_ref_cells - cached_ref_static),
                                    "cached_ref_static_by_sheet": dict(sorted(Counter(k[0] for k in cached_ref_static).items())),
                                    "cached_ref_static_samples": [f"{k[0]}!{_a1(k[1], k[2])}" for k in sorted(cached_ref_static)[:10]]}
        refs_by_cell.clear()

        depends_on: Dict[str, Set[str]] = defaultdict(set)
        feeds_into: Dict[str, Set[str]] = defaultdict(set)
        for (src, dst) in internal_edges.keys():
            depends_on[src].add(dst)
            feeds_into[dst].add(src)
        # Chart/Pivot source edges are *presentation/data lineage*, not necessarily
        # calculation graph edges. Use them for sheet role classification only.
        presentation_sources = defaultdict(set)
        presentation_consumers = defaultdict(set)
        for (src, dst) in list(chart_edges) + list(pivot_edges):
            presentation_sources[src].add(dst)
            presentation_consumers[dst].add(src)

        sheet_cycles = find_sccs_and_self_loops(depends_on)
        cyclic_sheets = {sh for scc in sheet_cycles for sh in scc}
        memo_tier: Dict[str, Optional[int]] = {}

        def compute_tier(sh: str, vis: Set[str]) -> Optional[int]:
            if sh in cyclic_sheets or sh in vis:
                return None
            if sh in memo_tier:
                return memo_tier[sh]
            if not depends_on[sh]:
                memo_tier[sh] = 0
                return 0
            vis.add(sh)
            ut = [compute_tier(u, vis) for u in depends_on[sh]]
            vis.remove(sh)
            memo_tier[sh] = None if any(x is None for x in ut) else 1 + max(x for x in ut if x is not None)
            return memo_tier[sh]

        for sm in sheets_meta:
            sname = sm["name"]
            if not sm["xml_exists"]:
                continue
            t = compute_tier(sname, set())
            sheet_audits[sname]["tier"] = t
            if sname in cyclic_sheets:
                sheet_audits[sname]["role"] = "Cyclic Dependency Member (SCC)"
            elif t == 0 and presentation_sources[sname]:
                sheet_audits[sname]["role"] = "Presentation / Pivot Host (No Formula-Level Upstream)"
            elif t == 0 and feeds_into[sname]:
                sheet_audits[sname]["role"] = "Tier-0 Primary Source (Feeds Downstream)"
            elif t == 0 and presentation_consumers[sname]:
                sheet_audits[sname]["role"] = "Data Source Consumed by Charts / PivotTables"
            elif t == 0:
                sheet_audits[sname]["role"] = "Standalone by Observed Static Relationships"
            elif feeds_into[sname]:
                sheet_audits[sname]["role"] = f"Tier-{t} Intermediate Calculation Sheet"
            else:
                sheet_audits[sname]["role"] = f"Tier-{t} Terminal Output / Report Sheet"

        PROGRESS.update(stage="sheet_roles_and_advanced", sheet=None)
        volatile_rtd, vba_summary = None, None
        if level >= 4 or include_rtd:
            volatile_rtd = {"types": [], "total_entries": 0}
            vd_part = find_in_namelist("xl/volatileDependencies.xml", namelist_set, lower_map)
            if vd_part:
                vd_xml = ET.fromstring(zf.read(vd_part))
                sid_to_name = {sm["sheet_id"]: sm["name"] for sm in sheets_meta}
                for vt in vd_xml.findall(f".//{{{NS_MAIN}}}volType"):
                    mains = vt.findall(f".//{{{NS_MAIN}}}main")
                    cnt = sum(len(m.findall(f".//{{{NS_MAIN}}}v")) for m in mains)
                    volatile_rtd["types"].append({"type": vt.attrib.get("type", ""), "entries": cnt})
                    volatile_rtd["total_entries"] += cnt
                    # v2.3: per-server health of cached topic values.
                    servers: Dict[str, Any] = {}
                    for m in mains:
                        srv = m.attrib.get("first", "")
                        sv = servers.setdefault(srv, {"server": srv, "topics": 0, "cells": 0,
                                                      "status_topics": Counter(), "status_cells": Counter(),
                                                      "function_topics": Counter(),
                                                      "by_sheet_cells": defaultdict(Counter),
                                                      "problem_samples": []})
                        for tp in m.findall(f"{{{NS_MAIN}}}tp"):
                            v = tp.findtext(f"{{{NS_MAIN}}}v")
                            st = classify_rtd_value(tp.attrib.get("t"), v)
                            stps = [x.text or "" for x in tp.findall(f"{{{NS_MAIN}}}stp")]
                            fn = next((x.split("|", 1)[0] for x in stps if "|" in x), stps[0] if stps else "")
                            trs = tp.findall(f"{{{NS_MAIN}}}tr")
                            sv["topics"] += 1
                            sv["cells"] += len(trs)
                            sv["status_topics"][st] += 1
                            sv["status_cells"][st] += len(trs)
                            sv["function_topics"][fn or "?"] += 1
                            for tr in trs:
                                shn = sid_to_name.get(tr.attrib.get("s", ""), f"sheetId:{tr.attrib.get('s')}")
                                sv["by_sheet_cells"][shn][st] += 1
                            if st in ("NO_DATA", "ERROR_MESSAGE", "ERROR_VALUE", "REQUESTING_DATA") and len(sv["problem_samples"]) < RTD_SAMPLE_CAP:
                                sv["problem_samples"].append({
                                    "status": st, "function": fn, "cached_value": (v or "")[:80],
                                    "cells": [f"{sid_to_name.get(tr.attrib.get('s',''), tr.attrib.get('s'))}!{tr.attrib.get('r')}" for tr in trs[:5]],
                                })
                    for sv in servers.values():
                        bad = sum(sv["status_topics"][k] for k in ("NO_DATA", "ERROR_MESSAGE", "ERROR_VALUE", "REQUESTING_DATA"))
                        sv["problem_topics"] = bad
                        sv["problem_topic_share"] = round(bad / sv["topics"], 4) if sv["topics"] else 0.0
                        sv["status_topics"] = dict(sv["status_topics"])
                        sv["status_cells"] = dict(sv["status_cells"])
                        sv["function_topics"] = dict(sv["function_topics"])
                        sv["by_sheet_cells"] = {k: dict(c) for k, c in sorted(sv["by_sheet_cells"].items())}
                        volatile_rtd.setdefault("servers", []).append(sv)
                volatile_rtd["note"] = ("Cached values at last save. BOOLEAN/NUMERIC = a value was cached; "
                                        "NO_DATA/ERROR_MESSAGE/REQUESTING_DATA = feed had not delivered at save time. "
                                        "Refresh on a live terminal before trusting dependent outputs.")
            vba_part = find_in_namelist("xl/vbaProject.bin", namelist_set, lower_map)
            if level >= 4 and vba_part and HAS_VBA_INSPECTOR and not skip_vba_parser:
                cnames = {"workbook_codename": wb_codename, "sheet_codenames": {sheet_audits[s["name"]]["codename"] for s in sheets_meta} | sheet_names_set}
                PROGRESS.update(stage="vba_risk_scan", sheet=None)
                vba_summary = vba_inspector.parse_vba_project(zf.read(vba_part), active_codenames=cnames, extract_code=False, scan_risks=True)
                vba_summary["stomping_check"] = _olevba_stomping_check(filepath)

        active_ext = sorted({eid for (_s, eid) in external_edges.keys()})
        # v2.4: links referenced only by defined names are not orphaned.
        name_ext: Dict[int, List[str]] = defaultdict(list)
        for dn in wb_xml.findall(f".//{{{NS_MAIN}}}definedName"):
            for m in re.finditer(r"\[(\d+)\]", STRING_LITERAL_RE.sub('""', dn.text or "")):
                eid = int(m.group(1))
                if eid in ext_links and dn.attrib.get("name", "") not in name_ext[eid]:
                    name_ext[eid].append(dn.attrib.get("name", ""))
        for eid, names in name_ext.items():
            ext_links[eid]["used_by_defined_names"] = names
        orphaned_ext = sorted(set(ext_links.keys()) - set(active_ext) - set(name_ext))
        ext_only_names = sorted(set(name_ext) - set(active_ext))

        package_inventory = None
        if level >= 2:
            package_inventory = build_package_inventory(zf, filepath, namelist_set, lower_map, vba_summary, level)
        g1_ok, g2_ok = len(missing_sheet_xmls) == 0, unresolved_slaves == 0
        graph_is_partial = any((sh.get("intra_sheet_graph_status") or "").startswith("SKIPPED") for sh in sheet_audits.values())
        dynamic_exists = any((sh.get("dependency_completeness") or "").startswith("PARTIAL") for sh in sheet_audits.values())

        return {
            "schema_version": "2.4.0", "inspection_level": level,
            "status": "OK" if (g1_ok and g2_ok) else "FAILED",
            "structural_errors": structural_errors, "capabilities_used": capabilities,
            "workbook_meta": {"filepath": filepath, "sha256": sha256_before, "file_size_bytes": file_size, "date1904": date1904, "calc_mode": calc_mode, "iterate": iterate},
            "summary": {
                "sheet_count": len(sheets_meta),
                "missing_worksheet_xml_count": len(missing_sheet_xmls),
                "defined_names_total": sum(defined_names_summary.values()),
                "external_links_defined": len(ext_links),
                "active_external_links_count": len(active_ext),
                "orphaned_external_links_ids": orphaned_ext,
                "external_links_used_only_by_defined_names": ext_only_names,
                "xml_cell_nodes_total": sum(a["xml_cell_nodes_total"] or 0 for a in sheet_audits.values()),
                "populated_cells": sum(a["populated_cells"] or 0 for a in sheet_audits.values()),
                "styled_blank_cells": sum(a["styled_blank_cells"] or 0 for a in sheet_audits.values()),
                "formula_cells_total": sum(a["formula_cells_total"] or 0 for a in sheet_audits.values()),
                "formula_cells_explicit_or_master": sum(a["formula_cells_explicit_or_master"] or 0 for a in sheet_audits.values()),
                "formula_cells_shared_slaves": sum(a["formula_cells_shared_slaves"] or 0 for a in sheet_audits.values()),
                "uncalculated_formula_cells": sum(a["uncalculated_formula_cells"] or 0 for a in sheet_audits.values()),
                "total_internal_cross_sheet_edges": len(internal_edges),
                "total_internal_cross_sheet_refs": sum(v["count"] for v in internal_edges.values()),
                "sheet_cycles_count": len(sheet_cycles),
                "charts_total": sum(len(a["charts"] or []) for a in sheet_audits.values()),
                "chartex_total": sum(1 for a in sheet_audits.values() for c in (a["charts"] or []) if c.get("kind") == "chartEx"),
                "tables_total": sum(len(a["tables"] or []) for a in sheet_audits.values()),
                "vba_risk_high": ((vba_summary or {}).get("risk_scan") or {}).get("summary", {}).get("HIGH") if vba_summary else None,
                "package_warnings": len((package_inventory or {}).get("warnings", [])) if package_inventory else None,
                "pivot_tables_total": sum(len(a["pivot_tables"] or []) for a in sheet_audits.values()),
                "formula_ref_error_cells": sum(a["formula_ref_error_cells"] or 0 for a in sheet_audits.values()),
                "dynamic_indirection_cells_total": sum(a["dynamic_indirection_cells_total"] or 0 for a in sheet_audits.values()),
                "ref_blast_radius_downstream_cells": (ref_blast_radius or {}).get("downstream_formula_cells"),
                "rtd_problem_topics": (sum(sv["problem_topics"] for sv in (volatile_rtd or {}).get("servers", [])) if volatile_rtd else None),
                "rtd_topics": (sum(sv["topics"] for sv in (volatile_rtd or {}).get("servers", [])) if volatile_rtd else None),
            },
            "defined_names_summary": dict(defined_names_summary),
            "custom_defined_names": custom_defined_names,
            "external_links_catalog": ext_links,
            "global_top_functions": global_functions.most_common(25),
            "sheets": [sheet_audits[s["name"]] for s in sheets_meta],
            "internal_edges": [
                {"formula_sheet": src, "depends_on_sheet": dst, "reference_count": info["count"], "mechanisms": dict(info["mechanisms"]), "sample_formulas": info["samples"]}
                for (src, dst), info in sorted(internal_edges.items(), key=lambda x: (-x[1]["count"], x[0]))
            ],
            "chart_cross_sheet_edges": [
                {"chart_host_sheet": src, "plots_data_from_sheet": dst, "series_count": info["count"], "charts": info["charts"]}
                for (src, dst), info in sorted(chart_edges.items())
            ],
            "pivot_cross_sheet_edges": [
                {"pivot_host_sheet": src, "source_data_sheet": dst, "pivot_count": info["count"], "pivot_tables": info["pivot_tables"]}
                for (src, dst), info in sorted(pivot_edges.items())
            ],
            "external_edges": [
                {"sheet": src, "external_id": eid, "external_file": ext_links.get(eid, {}).get("filename", ""), "reference_count": info["count"]}
                for (src, eid), info in sorted(external_edges.items())
            ],
            "sheet_cycles": sheet_cycles,
            "sheet_cycles_interpretation": "Potential sheet-level feedback: NOT proof of cell-level circularity across sheets",
            "graph_limitations": ["Dynamic/unsupported references may have unresolved targets"] if dynamic_exists else [],
            "volatile_rtd": volatile_rtd,
            "ref_blast_radius": ref_blast_radius,
            "vba_project": vba_summary,
            "package_inventory": package_inventory,
            "quality_gates": {
                "G1_preflight_integrity": "PASS" if g1_ok else "FAIL",
                "G2_shared_formula_accounting": "PASS" if g2_ok else "FAIL",
                # The engine cannot self-certify parser accuracy without an independent
                # reference oracle. Do not manufacture PASS statuses.
                "G3_string_and_external_disambiguation": "REVIEW_REQUIRED",
                "G4_quote_safe_function_tokenization": "REVIEW_REQUIRED",
                "G5_cycle_and_bridge_accounting": ("SKIPPED" if level < 3 else ("PARTIAL" if graph_is_partial or dynamic_exists else "REVIEW_REQUIRED")),
                "G6_cached_values_and_calc_mode": "DISCLOSED_NOT_RECALCULATED",
                "G7_dynamic_and_unresolved": "PARTIAL" if dynamic_exists or unresolved_slaves else "REVIEW_REQUIRED",
                "G8_evidence_traceability": "PARTIAL_SAMPLED",
                "G9_source_preserved": sha256_before == compute_sha256(filepath),
            },
        }




def export_dot(report: Dict[str, Any], dot_path: str) -> None:
    """Exports the sheet-level Directed Acyclic Graph (Plus chart and pivot bridges) to Graphviz DOT."""
    lines = [
        "digraph Workbook_Sheet_DAG {",
        '  rankdir="LR";',
        '  graph [fontname="Helvetica", fontsize=11, pad="0.4", nodesep="0.3", ranksep="0.9"];',
        '  node [shape=box, style="rounded,filled", fontname="Helvetica", fontsize=10, fillcolor="#F4F6F9"];',
        '  edge [fontname="Helvetica", fontsize=8];',
    ]
    for sh in report.get("sheets", []) or []:
        name = sh.get("name", "")
        tier = sh.get("tier")
        tier_s = f"Tier {tier}" if tier is not None else "Cyclic/N/A"
        fmls = sh.get("formula_cells_total") or 0
        lines.append(f'  "{name}" [label="{name}\\n({tier_s} | {fmls:,} fmls)"];')
    for edge in report.get("internal_edges", []) or []:
        u = edge["depends_on_sheet"]
        v = edge["formula_sheet"]
        c = edge["reference_count"]
        lines.append(f'  "{u}" -> "{v}" [label="{c:,}"];')
    for cedge in report.get("chart_cross_sheet_edges", []) or []:
        u = cedge["plots_data_from_sheet"]
        v = cedge["chart_host_sheet"]
        c = cedge["series_count"]
        lines.append(f'  "{u}" -> "{v}" [label="chart ({c})", style="dashed", color="#1F4E79"];')
    for pedge in report.get("pivot_cross_sheet_edges", []) or []:
        u = pedge["source_data_sheet"]
        v = pedge["pivot_host_sheet"]
        c = pedge["pivot_count"]
        lines.append(f'  "{u}" -> "{v}" [label="pivot ({c})", style="dotted", color="#7F6000"];')
    lines.append("}")
    with open(dot_path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))


def run_forensics(filepath: str, level: int = 3) -> Dict[str, Any]:
    """Backwards-compatible alias for analyze_workbook."""
    return analyze_workbook(filepath, level=level)


def main() -> None:
    ap = argparse.ArgumentParser(description="Workbook-Agnostic Excel Forensics CLI (v2.4.0)")
    ap.add_argument("workbook", nargs="?")
    ap.add_argument("--level", type=int, choices=[1, 2, 3, 4], default=3)
    ap.add_argument("--check-env", action="store_true")
    ap.add_argument("--export-json")
    ap.add_argument("--export-dot", help="Path to write Graphviz .dot dependency graph")
    ap.add_argument("--strict", action="store_true")
    ap.add_argument("--convert-legacy", action="store_true", help="Not implemented; fails explicitly")
    ap.add_argument("--heartbeat", type=float, default=60.0, metavar="SECONDS",
                    help="Print a progress pulse to stderr every N seconds (default 60; 0 disables)")
    args = ap.parse_args()
    if args.check_env:
        print(json.dumps(check_environment(), indent=2))
        return
    if not args.workbook:
        ap.error("workbook path required unless --check-env is passed")
    if args.convert_legacy:
        ap.error("--convert-legacy is not implemented. Convert a *copy* with a trusted application, verify preservation, then inspect OOXML; never assume conversion preserves macros or links.")
    try:
        _guard_output_path(args.workbook, args.export_json, "--export-json")
        _guard_output_path(args.workbook, args.export_dot, "--export-dot")
        if args.export_json and args.export_dot and os.path.normcase(os.path.abspath(args.export_json)) == os.path.normcase(os.path.abspath(args.export_dot)):
            raise ValueError("--export-json and --export-dot cannot point to the same file")
    except ValueError as exc:
        ap.error(str(exc))
    with Heartbeat(args.heartbeat):
        rep = analyze_workbook(args.workbook, level=args.level)
    if args.export_json:
        _guard_output_path(args.workbook, args.export_json, "--export-json")
        with open(args.export_json, "w", encoding="utf-8") as f:
            json.dump(rep, f, indent=2)
    if args.export_dot and args.level >= 2:
        _guard_output_path(args.workbook, args.export_dot, "--export-dot")
        export_dot(rep, args.export_dot)
    print(json.dumps({"status": rep["status"], "summary": rep["summary"], "quality_gates": rep["quality_gates"]}, indent=2))
    if args.strict and rep["status"] == "FAILED":
        sys.exit(2)


if __name__ == "__main__":
    main()

