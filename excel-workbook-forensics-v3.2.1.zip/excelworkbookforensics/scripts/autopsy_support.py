"""Maintained implementations behind the original Office Autopsy API."""
from pathlib import Path
import hashlib
import json
import os
import re
import shutil
import struct
import time
import xml.etree.ElementTree as ET
import zipfile

NS = "{http://schemas.openxmlformats.org/spreadsheetml/2006/main}"


def sha(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for b in iter(lambda: f.read(1024*1024), b""): h.update(b)
    return h.hexdigest()


def empty_report(path, kind):
    return dict(file=str(Path(path).resolve()), size=Path(path).stat().st_size, kind=kind,
                sha256=sha(path), workbook_protection=None, file_sharing=None, sheets=[],
                findings=[], vba=dict(available=True, modules=[], analysis=[], error=None),
                embed_vba=None, magic=None, ole_streams=None, raw_preview=None,
                limitations=[], issues=[])


def detect_kind(path):
    with open(path, "rb") as f: head=f.read(8)
    if head.startswith(b"PK") and zipfile.is_zipfile(path):
        with zipfile.ZipFile(path) as z:
            names=set(z.namelist())
            for prefix, part, plain, macro in [("xl", "workbook.xml", "xlsx", "xlsm"),
                ("word", "document.xml", "docx", "docm"), ("ppt", "presentation.xml", "pptx", "pptm")]:
                if f"{prefix}/{part}" in names:
                    return macro if f"{prefix}/vbaProject.bin" in names else plain
            if "xl/workbook.bin" in names: return "xlsb"
        return "zip"
    if head.startswith(b"\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1"):
        try:
            import olefile
            with olefile.OleFileIO(path) as ole:
                streams={"/".join(s) for s in ole.listdir()}
                if {"EncryptedPackage", "EncryptionInfo"} <= streams: return "encrypted_office"
                if "Workbook" in streams or "Book" in streams: return "xls"
                if "WordDocument" in streams: return "doc"
                if "PowerPoint Document" in streams: return "ppt"
                if "__properties_version1.0" in streams: return "msg"
                if any(s.startswith("VBA/") for s in streams): return "vbaProject.bin"
        except Exception: pass
        return "ole_unknown"
    for sig, kind in [(b"%PDF", "pdf"),(b"\x89PNG\r\n\x1a\n", "png"),(b"\xff\xd8\xff", "jpg"),
                       (b"\x1f\x8b", "gzip"),(b"7z\xbc\xaf\x27\x1c", "7z"),(b"MZ", "exe")]:
        if head.startswith(sig): return kind
    return "raw"


def extract_vba(path):
    from oletools.olevba import VBA_Parser
    result=dict(available=True, modules=[], analysis=[], error=None)
    parser=None
    try:
        parser=VBA_Parser(str(path))
        for filename, stream, module, code in parser.extract_macros():
            result["modules"].append(dict(filename=filename, stream=stream, vba_filename=module, code=code))
        try: result["analysis"]=list(parser.analyze_macros() or [])
        except Exception as exc: result["analysis_error"]=str(exc)
    except Exception as exc: result["error"]=str(exc)
    finally:
        if parser is not None: parser.close()
    return result


def inspect_vba(path):
    """Correlate native extraction with the retained project and risk parsers.

    The parsers remain independent: failures and count disagreements are kept
    as evidence instead of allowing one implementation to erase the other.
    """
    from collections import Counter
    import re
    import zipfile
    import vba_inspector

    path = Path(path)
    result = {"status": "PARTIAL", "backend": "Office Autopsy + oletools + retained VBA inspector",
              "modules": [], "oletools_analysis": [], "custom_project": None,
              "extraction_status": "NOT_CHECKED", "custom_parser_status": "NOT_CHECKED",
              "risk_scan": None, "stomping_check": {"status": "NOT_CHECKED", "reason": "No VBA project."},
              "parser_disagreement": [], "limitations": [
                  "Static VBA parsing only; no macro execution and no malware-clearance claim."]}
    parser = None
    has_vba = None
    try:
        from oletools.olevba import VBA_Parser
        parser = VBA_Parser(str(path))
        has_vba = parser.detect_vba_macros()
        result["extraction_status"] = "AVAILABLE" if has_vba else "NOT_PRESENT"
        if has_vba:
            for filename, stream, module, code in parser.extract_macros():
                code_lines = [ln for ln in code.splitlines() if ln.strip() and not ln.strip().lstrip().lower().startswith("attribute ")]
                meaningful = [ln for ln in code_lines if not ln.strip().startswith("'") and not re.match(r"(?i)^\s*Rem\b", ln)]
                result["modules"].append({"filename": filename, "stream": stream, "vba_filename": module,
                    "name": module, "lines": len(code_lines), "has_meaningful_code": bool(meaningful),
                    "code_sha256": hashlib.sha256(code.encode("utf-8", "replace")).hexdigest()})
            result["extraction_status"] = "COMPLETED"
            try:
                result["oletools_analysis"] = list(parser.analyze_macros() or [])
            except Exception as exc:
                result["analysis_error"] = f"{type(exc).__name__}: {exc}"
                result["extraction_status"] = "PARTIAL"
            try:
                stomped = bool(parser.detect_vba_stomping())
                result["stomping_check"] = {"status": "POSSIBLE_MISMATCH" if stomped else "NO_MISMATCH_DETECTED",
                    "coverage_status": "PERFORMED", "tool": "oletools source/p-code heuristic",
                    "note": "Possible source/p-code mismatch is a lead for review, not proof of malicious intent."}
            except Exception as exc:
                result["stomping_check"] = {"status": "FAILED", "coverage_status": "FAILED",
                    "reason": f"{type(exc).__name__}: {exc}"}
                result["extraction_status"] = "PARTIAL"
    except ImportError as exc:
        result["extraction_status"] = "UNAVAILABLE"
        result["extraction_error"] = str(exc)
        result["stomping_check"] = {"status": "UNAVAILABLE", "coverage_status": "UNAVAILABLE", "reason": str(exc)}
    except Exception as exc:
        result["extraction_status"] = "FAILED"
        result["extraction_error"] = f"{type(exc).__name__}: {exc}"
        result["stomping_check"] = {"status": "FAILED", "coverage_status": "FAILED", "reason": result["extraction_error"]}
    finally:
        if parser is not None:
            try:
                parser.close()
            except Exception:
                pass

    custom = None
    try:
        active = None
        project_bytes = None
        project_limit = 100 * 1024 * 1024
        if zipfile.is_zipfile(path):
            with zipfile.ZipFile(path) as z:
                project_info = next((item for item in z.infolist() if item.filename.lower().endswith("vbaproject.bin")), None)
                if project_info:
                    if project_info.file_size > project_limit:
                        raise ValueError(f"VBA project part exceeds the {project_limit // (1024 * 1024)} MiB parser limit")
                    project_bytes = z.read(project_info)
                    try:
                        active = vba_inspector.extract_active_codenames_from_workbook(z)
                    except Exception as exc:
                        result["parser_disagreement"].append({"field": "active_codenames", "status": "FAILED", "reason": str(exc)})
        else:
            with open(path, "rb") as handle:
                magic = handle.read(8)
            if magic == b"\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1":
                if path.stat().st_size > project_limit:
                    raise ValueError(f"OLE VBA container exceeds the {project_limit // (1024 * 1024)} MiB parser limit")
                project_bytes = path.read_bytes()
        if project_bytes:
            custom = vba_inspector.parse_vba_project(project_bytes, active_codenames=active,
                extract_code=False, scan_risks=True)
        else:
            custom = {"status": "NO_PROJECT_BINARY_FOUND", "decompression_warnings": [
                "The container did not expose a VBA project to the retained parser."]}
    except Exception as exc:
        custom = {"status": "FAILED", "error": f"{type(exc).__name__}: {exc}"}
    result["custom_project"] = custom
    result["custom_parser_status"] = (custom or {}).get("status", "FAILED")
    result["risk_scan"] = (custom or {}).get("risk_scan")

    declared = (custom or {}).get("declared_modules") or []
    declared_by_name = Counter(str(m.get("stream_name") or m.get("module_name") or "").casefold() for m in declared)
    for module in result["modules"]:
        key = str(module.get("vba_filename") or "").casefold()
        candidates = [m for m in declared if str(m.get("stream_name") or m.get("module_name") or "").casefold() == key]
        if candidates:
            module["module_type"] = candidates[0].get("module_type", "unknown")
            module["declared_name"] = candidates[0].get("module_name")
        else:
            module["module_type"] = "not matched to declared directory entry"
    declared_count = (custom or {}).get("dir_declared_modules_count")
    extracted_count = len(result["modules"])
    if has_vba is True and declared_count is not None and declared_count != extracted_count:
        result["parser_disagreement"].append({"field": "module_count", "custom_declared": declared_count,
            "oletools_extracted": extracted_count, "meaning": "Different measures; inspect stream-level results."})
    custom_ok = result["custom_parser_status"] in ("OK", "DEGRADED_WITH_WARNINGS", "NO_PROJECT_BINARY_FOUND")
    extraction_ok = result["extraction_status"] in ("COMPLETED", "NOT_PRESENT")
    if has_vba is False and result["custom_parser_status"] == "NO_PROJECT_BINARY_FOUND":
        result["status"] = "NOT_PRESENT"
        result["stomping_check"] = {"status": "NOT_REQUESTED", "coverage_status": "NOT_APPLICABLE", "reason": "No VBA project was detected."}
    elif result["modules"] or declared_count:
        result["status"] = "COMPLETED" if extraction_ok and custom_ok and not result["parser_disagreement"] else "PARTIAL"
    elif result["extraction_status"] == "UNAVAILABLE" and result["custom_parser_status"] == "FAILED":
        result["status"] = "NOT_AVAILABLE"
    else:
        result["status"] = "PARTIAL" if result["extraction_status"] not in ("NOT_PRESENT",) or not custom_ok else "NOT_PRESENT"
    if custom and result["custom_parser_status"] not in ("OK", "DEGRADED_WITH_WARNINGS", "NO_PROJECT_BINARY_FOUND"):
        result["parser_disagreement"].append({"field": "custom_parser_status", "status": result["custom_parser_status"]})
    result["module_summary"] = {
        "declared_modules": declared_count,
        "extracted_modules": extracted_count,
        "modules_with_meaningful_code": sum(1 for m in result["modules"] if m["has_meaningful_code"]),
        "declared_streams_with_duplicate_names": sorted(k for k, n in declared_by_name.items() if k and n > 1),
    }
    return result


def binary_preview(path, offset=0, length=256, min_length=4, scan_bytes=16*1024*1024):
    import office_autopsy as oa
    if offset<0 or not 1<=length<=65536 or min_length<2: raise ValueError("Invalid binary preview bounds")
    with open(path, "rb") as f:
        head=f.read(32); f.seek(offset); data=f.read(length); f.seek(0); sample=f.read(scan_bytes+1)
    truncated=len(sample)>scan_bytes; sample=sample[:scan_bytes]
    strings=[]
    for encoding, pattern in [("ascii", rb"[\x20-\x7e]{%d,}"%min_length),
                             ("utf-16le", rb"(?:[\x20-\x7e]\x00){%d,}"%min_length)]:
        for m in re.finditer(pattern, sample):
            strings.append(dict(offset=m.start(), encoding=encoding, text=m.group().decode(encoding)))
            if len(strings)>=200: break
        if len(strings)>=200: break
    match=next(((name, ext) for sig,name,ext in oa.MAGIC_MAP if head.startswith(sig)), ("Unknown",None))
    return dict(signature=match[0], suggested_extension=match[1], offset=offset,
                hex_lines=[f"{offset+i:08x}  {data[i:i+16].hex(' '):47}  "+"".join(chr(c) if 32<=c<=126 else "." for c in data[i:i+16]) for i in range(0,len(data),16)],
                strings=strings, string_samples_capped=len(strings)>=200, scan_bytes=len(sample),
                scan_truncated=truncated, file_bytes=Path(path).stat().st_size)


def audit_raw(path):
    r=empty_report(path, detect_kind(path)); r["binary"]=binary_preview(path)
    with open(path,"rb") as f: head=f.read(1024)
    r["magic"]=head[:20].hex(" ") if Path(path).stat().st_size<1024 else r["binary"]["hex_lines"][0] if r["binary"]["hex_lines"] else ""
    # Keep old dashboard-compatible keys without silently making signature copies.
    r["raw_preview"]=dict(hex_head=head[:256], strings=[s["text"] for s in r["binary"]["strings"]],
                          size=r["size"], zeros=head.count(0), ffs=head.count(255))
    r["findings"].append("Magic bytes: "+r["binary"]["signature"])
    return r


def audit_xlsb(path, member_cap=5000):
    """Scoped XLSB container inventory; binary workbook formulas are not decoded."""
    r=empty_report(path,"xlsb")
    with zipfile.ZipFile(path) as z:
        entries=z.infolist()
        if len(entries)>member_cap:
            r["issues"].append(f"Archive member listing capped at {member_cap} of {len(entries)} entries")
        r["archive_parts"]=[{"name":e.filename,"compressed_bytes":e.compress_size,"expanded_bytes":e.file_size}
                            for e in entries[:member_cap]]
        names={e.filename.lower() for e in entries}
        r["container"]={"kind":"XLSB binary workbook","workbook_bin_present":"xl/workbook.bin" in names,
                        "vba_project_present":any(n.endswith("vbaproject.bin") for n in names),
                        "connections_present":"xl/connections.bin" in names}
        r["binary"]=binary_preview(path)
        r["findings"].append("XLSB container examined. Binary worksheet/formula semantics are outside this audit scope.")
    r["limitations"].append("XLSB container, package parts and embedded VBA may be inventoried; formula graph and correctness audit are unsupported.")
    return r


def audit_vbaproject(path,do_vba=True):
    r=empty_report(path,detect_kind(path))
    try:
        import olefile
        with olefile.OleFileIO(path) as ole:r['ole_streams']=['/'.join(p) for p in ole.listdir()]
    except Exception as exc:r['issues'].append(str(exc))
    if do_vba:
        r['vba']=extract_vba(path)
        if r['vba']['error']:r['issues'].append(r['vba']['error'])
    return r


def find_element(xml, tag):
    root=ET.fromstring(xml)
    return next((dict(e.attrib) for e in root.iter() if e.tag.split('}')[-1]==tag), None)


def audit_ooxml(path, do_crack=False, max_len=3, do_vba=True):
    import office_autopsy as oa
    import workbook_forensics as wf
    r=empty_report(path,detect_kind(path))
    with zipfile.ZipFile(path) as z:
        names=set(z.namelist()); lower={n.lower():n for n in names}
        book=ET.fromstring(z.read("xl/workbook.xml"))
        rels=wf.read_rels_map(z,"xl/workbook.xml",names,lower)
        for tag,key in [("workbookProtection","workbook_protection"),("fileSharing","file_sharing")]:
            e=book.find(NS+tag); r[key]=dict(e.attrib) if e is not None else None
        for sh in book.findall(".//"+NS+"sheet"):
            rid=sh.get("{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id")
            rel=rels.get(rid,{})
            part=rel.get("resolved_target")
            e=dict(name=sh.get('name'),state=sh.get('state','visible'),xml=part,protection=None,blocking=[],
                   password_hash_hex=None,password_hash_int=None,password=None,password_method=None,
                   password_variant=None,hidden_rows=0,hidden_cols=0)
            if e['state']!='visible': e['blocking'].append(e['state'])
            if rel.get('target_mode')=='External' or part not in names:
                r['issues'].append(f"Missing/noninternal worksheet part for {e['name']}")
            else:
                with z.open(part) as f:
                    for _,el in ET.iterparse(f,events=('end',)):
                        tag=el.tag.split('}')[-1]
                        if tag=='sheetProtection':
                            e['protection']=dict(el.attrib);e['blocking']+=oa.describe_sheet_protection(e['protection'])
                            if el.get('password'):
                                e['password_hash_hex']=el.get('password')
                                try:e['password_hash_int']=int(el.get('password'),16)
                                except ValueError:r['issues'].append(f"Invalid legacy hash on {e['name']}")
                        if el.get('hidden','').lower() in ('1','true'):
                            if tag=='row':e['hidden_rows']+=1
                            elif tag=='col':e['hidden_cols']+=1
                        el.clear()
            if do_crack and e['password_hash_int'] is not None:
                pw,var,method=oa.crack_legacy(e['password_hash_int'],max_len=max_len)
                e.update(password=pw,password_variant=var,password_method=method)
            r['sheets'].append(e)
        if 'xl/vbaProject.bin' in names:r['embed_vba']='xl/vbaProject.bin'
    if do_vba:r['vba']=extract_vba(path)
    r['findings'] += [f"{e['name']}: {', '.join(e['blocking'])}" for e in r['sheets'] if e['blocking']]
    r['limitations'].append('Protection is editing control, not file encryption. Recovered legacy strings are compatible collisions, not proof of the original password.')
    return r


def biff_records(data):
    pos=0
    while pos+4<=len(data):
        kind,size=struct.unpack_from('<HH',data,pos)
        if pos+4+size>len(data):raise ValueError(f'Truncated BIFF record at {pos}')
        yield pos,kind,data[pos+4:pos+4+size]
        pos+=4+size


def parse_biff(data):
    r=dict(sheets=[],workbook_protection=None,issues=[])
    bounds=[]
    for off,kind,rd in biff_records(data):
        if kind==0x002f:
            r['issues'].append('Encrypted BIFF FILEPASS: sheet parsing stopped');return r
        if kind==0x000a:break
        if kind==0x0085 and len(rd)>=8:
            lb=struct.unpack_from('<I',rd)[0];vis=rd[4]&3;cch=rd[6];wide=rd[7]&1
            name=rd[8:8+cch*(2 if wide else 1)].decode('utf-16le' if wide else 'latin1','replace')
            bounds.append((name,vis,lb))
        elif kind==0x0012 and rd[:2]==b'\x01\x00':r['workbook_protection']={'lockStructure':'1'}
    for name,vis,offset in bounds:
        e=dict(name=name,state={0:'visible',1:'hidden',2:'veryHidden'}.get(vis,'unknown'),xml=None,
               protection=None,blocking=[],password_hash_hex=None,password_hash_int=None,
               password=None,password_method=None,password_variant=None,hidden_rows=0,hidden_cols=0)
        if offset>=len(data):r['issues'].append(f'Invalid BOUNDSHEET offset: {name}');continue
        for _,kind,rd in biff_records(data[offset:]):
            if kind==0x000a:break
            if kind==0x0012 and rd[:2]==b'\x01\x00':e['protection']={'sheet':'1'};e['blocking'].append('BIFF PROTECT')
            if kind==0x0013 and len(rd)>=2:e['password_hash_int']=struct.unpack_from('<H',rd)[0];e['password_hash_hex']=f"{e['password_hash_int']:04X}"
            if kind==0x0208 and len(rd)>=14 and struct.unpack_from('<H',rd,12)[0]&0x20:e['hidden_rows']+=1
            if kind==0x007d and len(rd)>=10 and struct.unpack_from('<H',rd,8)[0]&1:e['hidden_cols']+=1
        r['sheets'].append(e)
    return r


def audit_xls(path,do_crack=False,max_len=3,do_vba=True):
    import olefile
    import office_autopsy as oa
    r=empty_report(path,'xls')
    with olefile.OleFileIO(path) as ole:
        r['ole_streams']=['/'.join(p) for p in ole.listdir()]
        data=ole.openstream('Workbook' if ole.exists('Workbook') else 'Book').read()
    r.update(parse_biff(data))
    if do_crack:
        for e in r['sheets']:
            if e['password_hash_int'] is not None:
                pw,var,method=oa.crack_legacy(e['password_hash_int'],max_len=max_len)
                e.update(password=pw,password_variant=var,password_method=method)
    if do_vba:r['vba']=extract_vba(path)
    r['limitations']=['BIFF8 protection/visibility inspection only; no formula-equivalence or full legacy model audit.']
    return r


def export_macros(path,out):
    import tempfile
    out=Path(out).resolve()
    if out.exists():raise ValueError('Macro output directory already exists')
    result=extract_vba(path)
    if result['error']:raise ValueError(result['error'])
    if not result['modules']:raise ValueError('No VBA source modules were available to export')
    metadata={}
    try:
        inspected=inspect_vba(path)
        for module in (inspected.get('custom_project') or {}).get('declared_modules',[]):
            key=str(module.get('stream_name') or module.get('module_name') or '').casefold()
            if key:metadata[key]=module
    except Exception:
        # Raw extracted source remains exportable when metadata parsing fails.
        metadata={}
    out.parent.mkdir(parents=True,exist_ok=True)
    staging=Path(tempfile.mkdtemp(prefix=f'.{out.name}.',dir=out.parent))
    manifest=[]
    try:
        for i,m in enumerate(result['modules'],1):
            module_name=m.get('vba_filename') or 'module'
            safe_name=re.sub(r'[^\w.-]','_',module_name).strip('._') or 'module'
            meta=(metadata.get(str(module_name).casefold()) or
                  metadata.get(str(m.get('stream') or '').casefold()) or {})
            module_type=meta.get('module_type') or 'unknown'
            suffix=Path(module_name).suffix.lower()
            if suffix not in ('.bas','.cls','.frm'):
                suffix='.bas' if module_type=='procedural' else '.cls'
            filename=f'{i:03d}_{Path(safe_name).stem}{suffix}'
            target=staging/filename
            code=m.get('code') or ''
            with open(target,'w',encoding='utf-8',newline='') as handle:
                handle.write(code)
                handle.flush()
                os.fsync(handle.fileno())
            manifest.append({"file":filename,"stream":m.get('stream'),"module_name":module_name,
                "module_type":module_type,"code_sha256":hashlib.sha256(code.encode('utf-8','replace')).hexdigest(),
                "file_sha256":sha(target),"encoding":"UTF-8"})
        manifest_path=staging/'manifest.json'
        with open(manifest_path,'w',encoding='utf-8',newline='\n') as handle:
            json.dump(manifest,handle,ensure_ascii=False,indent=2)
            handle.write('\n')
            handle.flush()
            os.fsync(handle.fileno())
        os.rename(staging,out)
        return manifest
    except Exception:
        shutil.rmtree(staging,ignore_errors=True)
        raise


def _extract_ns_decls(raw_xml: bytes):
    """Extract all (prefix, uri) namespace declarations from raw XML bytes."""
    import io
    decls = []
    for ev, item in ET.iterparse(io.BytesIO(raw_xml), events=("start-ns",)):
        if item not in decls:
            decls.append(item)
    return decls


def _serialize_preserving_namespaces(tree, raw_xml: bytes) -> bytes:
    """Serialize ElementTree while preserving all root namespace declarations (including mc:Ignorable prefixes)."""
    ns_decls = _extract_ns_decls(raw_xml)
    for prefix, uri in ns_decls:
        ET.register_namespace(prefix, uri)
    serialized = ET.tostring(tree, encoding="utf-8", xml_declaration=True).decode("utf-8")
    m = re.search(r"<([A-Za-z0-9_:]+)(\s[^>]*)?>", serialized)
    if m:
        root_open = m.group(0)
        missing = []
        for prefix, uri in ns_decls:
            attr_name = f"xmlns:{prefix}" if prefix else "xmlns"
            if not re.search(rf"\b{re.escape(attr_name)}\s*=", root_open):
                missing.append(f'{attr_name}="{uri}"')
        if missing:
            close_suffix = "/>" if root_open.endswith("/>") else ">"
            stem = root_open[:-len(close_suffix)]
            patched = stem + " " + " ".join(missing) + close_suffix
            serialized = serialized[:m.start()] + patched + serialized[m.end():]
    return serialized.encode("utf-8")


def _verify_xml_namespaces(raw_before: bytes, raw_after: bytes) -> bool:
    """Confirm all original namespace declarations and mc:Ignorable prefixes remain bound after serialization."""
    before_decls = dict(_extract_ns_decls(raw_before))
    after_decls = dict(_extract_ns_decls(raw_after))
    for prefix, uri in before_decls.items():
        if after_decls.get(prefix) != uri:
            return False
    root_after = ET.fromstring(raw_after)
    for el in root_after.iter():
        for attr_key, attr_val in el.attrib.items():
            if attr_key.endswith("}Ignorable") or attr_key == "mc:Ignorable" or attr_key.endswith(":Ignorable"):
                for pfx in attr_val.split():
                    if pfx not in after_decls:
                        return False
    return True


def _guard_output_file(source_path, output_path, label="--output"):
    if not output_path:
        return
    src_abs = os.path.abspath(str(source_path))
    out_abs = os.path.abspath(str(output_path))
    if os.path.normcase(src_abs) == os.path.normcase(out_abs) or os.path.normcase(os.path.realpath(src_abs)) == os.path.normcase(os.path.realpath(out_abs)):
        raise ValueError(f"{label} cannot point to the input file: {output_path}")
    if os.path.exists(out_abs) and os.path.exists(src_abs):
        try:
            if os.path.samefile(src_abs, out_abs):
                raise ValueError(f"{label} resolves to the same underlying file/inode as the input: {output_path}")
        except OSError:
            pass


def repair_copy(source,target):
    import copy
    _guard_output_file(source, target, "--output")
    source,target=Path(source).resolve(),Path(target).resolve()
    if source==target or target.exists():raise ValueError('Repair requires a new output file, distinct from source')
    before=sha(source);changes=[];modified=set();source_parts=set();original_xml_raw={}
    if detect_kind(source) not in ('xlsx','xlsm'):raise ValueError('OOXML repair-copy requires xlsx/xlsm content')
    target.parent.mkdir(parents=True,exist_ok=True)
    try:
        with zipfile.ZipFile(source) as z:
            entries=z.infolist();source_parts={entry.filename for entry in entries}
            if len(entries)>50000 or sum(entry.file_size for entry in entries)>2*1024**3:
                raise ValueError('Repair input exceeds the 50,000-part or 2 GiB expanded safety limit')
            staged={}
            for entry in entries:
                n=entry.filename
                if n!='xl/workbook.xml' and not (n.startswith('xl/worksheets/') and n.endswith('.xml')):continue
                if entry.file_size>128*1024**2:
                    raise ValueError(f'Repair XML part exceeds the 128 MiB parser limit: {n}')
                raw=z.read(entry)
                original_xml_raw[n]=raw
                for pfx, uri in _extract_ns_decls(raw):
                    ET.register_namespace(pfx, uri)
                tree=ET.fromstring(raw);changed=False
                for parent in tree.iter():
                    for child in list(parent):
                        child_name=child.tag.split('}')[-1]
                        if child_name in ('sheetProtection','workbookProtection','fileSharing'):
                            parent.remove(child);changed=True
                            changes.append({'part':n,'action':'removed '+child_name})
                    if parent.tag.split('}')[-1]=='sheet' and parent.get('state') in ('hidden','veryHidden'):
                        changes.append({'part':n,'action':'unhide','sheet':parent.get('name')})
                        parent.set('state','visible');changed=True
                if changed:
                    staged[n]=_serialize_preserving_namespaces(tree, raw)
                    modified.add(n)
            with open(target,'xb') as handle,zipfile.ZipFile(handle,'w') as dest:
                dest.comment=z.comment
                for entry in entries:
                    replacement=staged.get(entry.filename)
                    with dest.open(copy.copy(entry),'w') as output_part:
                        if replacement is not None:
                            output_part.write(replacement)
                        else:
                            with z.open(entry) as input_part:
                                shutil.copyfileobj(input_part,output_part,1024*1024)
        with zipfile.ZipFile(target) as repaired:
            bad=repaired.testzip()
            if bad:raise ValueError(f'Repaired copy failed CRC verification at {bad}')
            if {entry.filename for entry in repaired.infolist()}!=source_parts:
                raise ValueError('Repair changed the package-part inventory')
            postconditions={"workbook_protection_removed":True,"sheet_protection_removed":True,
                            "all_sheets_visible":True,"namespaces_and_ignorable_preserved":True}
            for name in repaired.namelist():
                if name!='xl/workbook.xml' and not (name.startswith('xl/worksheets/') and name.endswith('.xml')):continue
                rep_bytes = repaired.read(name)
                if name in original_xml_raw and not _verify_xml_namespaces(original_xml_raw[name], rep_bytes):
                    postconditions["namespaces_and_ignorable_preserved"]=False
                root=ET.fromstring(rep_bytes)
                for node in root.iter():
                    local=node.tag.split('}')[-1]
                    if local=='workbookProtection':postconditions['workbook_protection_removed']=False
                    if local=='fileSharing':postconditions['workbook_protection_removed']=False
                    if local=='sheetProtection':postconditions['sheet_protection_removed']=False
                    if local=='sheet' and node.get('state') in ('hidden','veryHidden'):
                        postconditions['all_sheets_visible']=False
            if not all(postconditions.values()):
                raise ValueError('Repair output did not meet its protection/visibility postconditions: '+str(postconditions))
            unchanged_parts_preserved=True
            with zipfile.ZipFile(source) as original:
                for name in source_parts-modified:
                    with original.open(name) as left,repaired.open(name) as right:
                        while True:
                            a,b=left.read(1024*1024),right.read(1024*1024)
                            if a!=b:
                                unchanged_parts_preserved=False
                                raise ValueError(f'Unchanged package part differs after repair: {name}')
                            if not a:break
        after_source=sha(source)
        if after_source!=before:raise ValueError('Source changed during repair-copy')
        signature_parts=[n for n in source_parts if n.lower().startswith('_xmlsignatures/')]
        return dict(path=str(target),changes=changes,postconditions=postconditions,
                output_archive_integrity='VERIFIED',source_sha256_before=before,
                source_sha256_after=after_source,source_preserved=True,
                unchanged_parts_preserved=unchanged_parts_preserved,modified_parts=sorted(modified),
                sha256=sha(target),signature_warning=('Package signatures are present and are invalidated by XML edits.' if signature_parts else
                    'Any original package signature is invalidated by XML edits.' if modified else 'No package parts required an edit.'))
    except Exception:
        target.unlink(missing_ok=True)
        raise


def main():
    import argparse, sys
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    ap = argparse.ArgumentParser(description="Office Autopsy 3.2 Support CLI (OOXML/BIFF8/XLSB/OLE/Repair/Macro Export)")
    sub = ap.add_subparsers(dest="cmd", required=True)

    p_insp = sub.add_parser("inspect", help="Content-sniff and inspect OOXML, XLS, XLSB, OLE, or raw binary")
    p_insp.add_argument("filepath")
    p_insp.add_argument("--recover-passwords", action="store_true", help="Attempt legacy 16-bit XOR protection hash collision recovery")
    p_insp.add_argument("--maxlen", type=int, default=3, help="Max brute-force length for legacy 16-bit hashes (default 3)")
    p_insp.add_argument("--export-json", help="Save JSON report to path")

    p_rep = sub.add_parser("repair", help="Create a verified unhidden/unprotected OOXML copy (never modifies source)")
    p_rep.add_argument("source")
    p_rep.add_argument("--output", required=True, help="New destination path for repaired copy")

    p_mac = sub.add_parser("macros", help="Export VBA macros with SHA-256 manifest to a new directory")
    p_mac.add_argument("source")
    p_mac.add_argument("--output", required=True, help="New destination directory for exported .bas/.cls files")

    args = ap.parse_args()
    if args.cmd == "inspect":
        kind = detect_kind(args.filepath)
        if kind in ("xlsx", "xlsm"):
            res = audit_ooxml(args.filepath, do_crack=args.recover_passwords, max_len=args.maxlen, do_vba=False)
        elif kind == "xlsb":
            res = audit_xlsb(args.filepath)
        elif kind == "xls":
            res = audit_xls(args.filepath, do_crack=args.recover_passwords, max_len=args.maxlen, do_vba=False)
        elif kind in ("doc", "ppt", "msg", "vbaProject.bin", "ole_unknown", "encrypted_office"):
            res = audit_vbaproject(args.filepath, do_vba=False)
        else:
            res = audit_raw(args.filepath)
        res.pop("raw_preview", None)
        res["binary"] = binary_preview(args.filepath)
        if args.export_json:
            try:
                _guard_output_file(args.filepath, args.export_json, "--export-json")
            except ValueError as exc:
                ap.error(str(exc))
            Path(args.export_json).write_text(json.dumps(res, indent=2), encoding="utf-8")
        print(json.dumps(res, indent=2))
    elif args.cmd == "repair":
        res = repair_copy(args.source, args.output)
        print(json.dumps(res, indent=2))
    elif args.cmd == "macros":
        res = export_macros(args.source, args.output)
        print(json.dumps(res, indent=2))


if __name__ == "__main__":
    main()
