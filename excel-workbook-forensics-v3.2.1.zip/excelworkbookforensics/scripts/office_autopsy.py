#!/usr/bin/env python3
"""
OFFICE AUTOPSY 3.2 - retained utility; maintained implementations in autopsy_support.py
One-file tool combining:
  * bin_magic      - magic-byte detection, hex dump, string extraction, rename suggestions
  * sheet_audit    - sheet/workbook protection audit, veryHidden detection, legacy pw recovery
  * vba_extractor2 - VBA macro extraction with olevba (deobfuscated)

Dispatches automatically based on what the file actually is:
  .xlsx/.xlsm  -> read-only sheet audit; explicit macros and repair commands
  .xls         -> BIFF audit + VBA extraction + fix (via Excel COM)
  .doc/.ppt    -> OLE stream listing + VBA extraction
  vbaProject.bin -> VBA extraction + office-extension copies
  raw .bin     -> magic bytes, hex dump, strings, rename suggestions

Usage:
    python office_autopsy.py file
    python office_autopsy.py workbook.xlsm
    python office_autopsy.py vbaProject.bin
    python office_autopsy.py workbook.xls --maxlen=4
    python office_autopsy.py workbook.xlsx --no-crack --no-vba
"""

import os, sys, re, html, time, string, zipfile, struct
from pathlib import Path
sys.path[:0] = [str(Path(__file__).resolve().parent), str(Path(__file__).resolve().parent / "vendor"), str(Path(__file__).resolve().parent / "engine")]
import hashlib, subprocess, tempfile, itertools, datetime, shutil

try:
    import olefile
    HAS_OLE = True
except ImportError:
    HAS_OLE = False

try:
    from oletools import olevba
    HAS_OVBA = True
except ImportError:
    HAS_OVBA = False

OLE_MAGIC = b"\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1"

MAGIC_MAP = [
    (b"PK\x03\x04",           "ZIP / OOXML",      ".zip"),
    (OLE_MAGIC,               "OLE CFB",          ".doc"),
    (b"\x89PNG\r\n\x1a\n",    "PNG Image",        ".png"),
    (b"\xff\xd8\xff",         "JPEG Image",       ".jpg"),
    (b"GIF87a",               "GIF Image",        ".gif"),
    (b"GIF89a",               "GIF Image",        ".gif"),
    (b"%PDF",                 "PDF Document",     ".pdf"),
    (b"MZ",                   "Windows Exe",      ".exe"),
    (b"\x1f\x8b",             "GZIP",             ".gz"),
    (b"BZh",                  "BZIP2",            ".bz2"),
    (b"7z\xbc\xaf\x27\x1c",   "7-Zip",            ".7z"),
    (b"RIFF",                 "AVI/WAV",          ""),
    (b"\x7fELF",              "Linux ELF",        ""),
]

COMMON_PASSWORDS = [
    "password","123456","12345","1234","123","admin","test","letmein","qwerty",
    "abc123","111111","iloveyou","welcome","monkey","dragon","pass","excel",
    "office","secret","root","toor","changeme","temp","sheet","protect","locked",
    "hidden","none","null","0000","00000","a","aa","aaa","1","11","111","x","xx","xxx",
]

CHARSET = string.ascii_lowercase + string.ascii_uppercase + string.digits \
        + "!@#$%^&*()-_=+[]{};:,.<>?/\\|~`'\" "

# ---------------------------------------------------------------------------
# Legacy 16-bit Excel protection hash
# ---------------------------------------------------------------------------
def _rot15(h):
    return ((h >> 14) & 0x01) | ((h << 1) & 0x7FFF)

def _finalize(h, n):
    return (_rot15(h) ^ n ^ 0xCE4B) & 0xFFFF

def _hash_forward(ords):
    h = 0
    for o in ords:
        h = _rot15(h) ^ o
    return _finalize(h, len(ords))

def _hash_reverse(ords):
    h = 0
    for o in reversed(ords):
        h = _rot15(h) ^ o
    return _finalize(h, len(ords))

HASH_VARIANTS = (("reverse", _hash_reverse),)  # canonical legacy verifier; collisions are compatible strings

def crack_legacy(target, max_len=3, budget=25.0):
    t0 = time.time()
    for pw in COMMON_PASSWORDS:
        ords = [ord(c) for c in pw]
        for vname, fn in HASH_VARIANTS:
            if fn(ords) == target:
                return pw, vname, "dictionary"
    ords = [ord(c) for c in CHARSET]
    for L in range(1, max_len + 1):
        for combo in itertools.product(ords, repeat=L):
            for vname, fn in HASH_VARIANTS:
                if fn(combo) == target:
                    return "".join(chr(o) for o in combo), vname, f"brute-force len {L}"
            if time.time() - t0 > budget:
                return None, None, "timeout"
    return None, None, None

# ---------------------------------------------------------------------------
# XML helpers
# ---------------------------------------------------------------------------
ATTR_RE = re.compile(r'([\w:]+)\s*=\s*"([^"]*)"')
def _attrs(tag_body):
    return dict(ATTR_RE.findall(tag_body))

def find_element(xml, tag):
    from autopsy_support import find_element as implementation
    return implementation(xml, tag)

def element_span(xml, tag):
    m = re.search(r'<%s\b[^>]*?/>' % re.escape(tag), xml)
    if m:
        return m.start(), m.end()
    m = re.search(r'<%s\b[^>]*?>.*?</%s>' % (re.escape(tag), re.escape(tag)), xml, re.DOTALL)
    return (m.start(), m.end()) if m else None

BLOCK_MEANINGS = {
    "formatCells":"format cells","formatColumns":"format columns",
    "formatRows":"format rows","insertColumns":"insert columns",
    "insertRows":"insert rows","insertHyperlinks":"insert hyperlinks",
    "deleteColumns":"delete columns","deleteRows":"delete rows",
    "sort":"sort","autoFilter":"use AutoFilter","pivotTables":"use PivotTables",
    "objects":"edit objects","scenarios":"edit scenarios",
    "selectLockedCells":"SELECT locked cells",
    "selectUnlockedCells":"select unlocked cells",
}

def describe_sheet_protection(sp):
    out = []
    if not sp:
        return out
    if sp.get("sheet") == "1":
        out.append('Worksheet protection ON (`sheet="1"`)')
    for k, phrase in BLOCK_MEANINGS.items():
        if sp.get(k) == "1":
            out.append(f'Blocked: {phrase} (`{k}="1"`)')
    if "password" in sp:
        out.append(f'Legacy hash present (`password="{sp["password"]}"`)')
    if "algorithmName" in sp:
        out.append(f'Modern {sp.get("algorithmName")} (spinCount={sp.get("spinCount","?")}) — recovery not attempted')
    return out

# ---------------------------------------------------------------------------
# File kind detection
# ---------------------------------------------------------------------------
def detect_kind(path):
    from autopsy_support import detect_kind as implementation
    return implementation(path)

# ---------------------------------------------------------------------------
# VBA extraction
# ---------------------------------------------------------------------------
def extract_vba(filepath):
    from autopsy_support import extract_vba as implementation
    return implementation(filepath)

# ---------------------------------------------------------------------------
# OOXML (.xlsx/.xlsm) audit
# ---------------------------------------------------------------------------
def _norm_target(t):
    return t.lstrip("/") if t.startswith("/") else "xl/" + t

def audit_ooxml(path, do_crack=False, max_len=3, do_vba=True):
    from autopsy_support import audit_ooxml as implementation
    return implementation(path, do_crack, max_len, do_vba)

# ---------------------------------------------------------------------------
# .xls audit (BIFF8)
# ---------------------------------------------------------------------------
def _iter_biff(data):
    i = 0
    while i + 4 <= len(data):
        rtype = int.from_bytes(data[i:i+2], "little")
        rlen  = int.from_bytes(data[i+2:i+4], "little")
        yield i, rtype, data[i+4:i+4+rlen]
        i += 4 + rlen

def audit_xls(path, do_crack=False, max_len=3, do_vba=True):
    from autopsy_support import audit_xls as implementation
    return implementation(path, do_crack, max_len, do_vba)

# ---------------------------------------------------------------------------
# vbaProject.bin / raw / other OLE
# ---------------------------------------------------------------------------
def audit_vbaproject(path, do_vba=True):
    from autopsy_support import audit_vbaproject as implementation
    return implementation(path, do_vba)

def audit_raw(path):
    from autopsy_support import audit_raw as implementation
    return implementation(path)

# ---------------------------------------------------------------------------
# Fix (write unblocked copy)
# ---------------------------------------------------------------------------
def fix_ooxml(src):
    from autopsy_support import repair_copy
    base, ext = os.path.splitext(src)
    out = base + "_unhidden" + ext
    return repair_copy(src, out)["path"]

def fix_xls(src, output=None, detailed=False):
    try:
        import win32com.client as win32
    except ImportError:
        return None, "pywin32 not installed (pip install pywin32) and Excel required"
    from autopsy_support import sha
    src = os.path.abspath(src)
    target = os.path.abspath(output or (os.path.splitext(src)[0] + "_unhidden.xls"))
    if os.path.normcase(src) == os.path.normcase(target) or os.path.exists(target):
        return None, "Excel COM repair requires a new output path distinct from the source"
    if os.path.splitext(target)[1].lower() != ".xls":
        return None, "Excel COM repair output must use the .xls extension"
    source_before = sha(src)
    excel = None
    wb = None
    verify_wb = None
    try:
        excel = win32.DispatchEx("Excel.Application")
        excel.Visible = False
        excel.DisplayAlerts = False
        excel.AutomationSecurity = 3
        excel.EnableEvents = False
        excel.AskToUpdateLinks = False
        try: excel.ScreenUpdating = False
        except Exception: pass
        try: excel.Calculation = -4135  # xlCalculationManual
        except Exception: pass
        try: excel.CalculateBeforeSave = False
        except Exception: pass
        wb = excel.Workbooks.Open(src, UpdateLinks=0, ReadOnly=True,
                                  IgnoreReadOnlyRecommended=True, AddToMru=False)
        attempted = []
        try: wb.Unprotect()
        except Exception as exc: attempted.append({"target":"workbook","result":"unprotect failed","reason":str(exc)})
        for ws in wb.Worksheets:
            name = str(ws.Name)
            try: ws.Unprotect()
            except Exception as exc: attempted.append({"target":name,"result":"unprotect failed","reason":str(exc)})
            try: ws.Visible = -1
            except Exception as exc: attempted.append({"target":name,"result":"unhide failed","reason":str(exc)})
        wb.SaveAs(target, FileFormat=56, AddToMru=False)
        wb.Close(False)
        wb = None
        verify_wb = excel.Workbooks.Open(target, UpdateLinks=0, ReadOnly=True,
                                         IgnoreReadOnlyRecommended=True, AddToMru=False)
        hidden_sheets = [str(ws.Name) for ws in verify_wb.Worksheets if int(ws.Visible) != -1]
        protected_sheets = [str(ws.Name) for ws in verify_wb.Worksheets if bool(ws.ProtectContents)]
        workbook_protected = bool(verify_wb.ProtectStructure)
        verify_wb.Close(False)
        verify_wb = None
        source_after = sha(src)
        postconditions = {"all_sheets_visible": not hidden_sheets,
                          "sheet_content_unprotected": not protected_sheets,
                          "workbook_structure_unprotected": not workbook_protected,
                          "source_preserved": source_after == source_before}
        result = {"path":target,"source_sha256_before":source_before,
                  "source_sha256_after":source_after,"sha256":sha(target),
                  "postconditions":postconditions,"hidden_sheets_remaining":hidden_sheets,
                  "protected_sheets_remaining":protected_sheets,
                  "workbook_structure_protected":workbook_protected,
                  "attempts_with_errors":attempted,
                  "limitations":["Excel COM requires installed Excel and pywin32; not portable or qualified on this build host.",
                                 "The output is an Excel-resaved legacy workbook; binary package-part identity is not preserved."]}
        if not all(postconditions.values()):
            raise RuntimeError("Excel COM repair postconditions failed: " + repr(postconditions))
        return (result if detailed else target), None
    except Exception as exc:
        for workbook in (verify_wb, wb):
            if workbook is not None:
                try: workbook.Close(False)
                except Exception: pass
        try:
            if os.path.exists(target): os.remove(target)
        except OSError: pass
        return None, f"{type(exc).__name__}: {exc}"
    finally:
        if excel is not None:
            try: excel.Quit()
            except Exception: pass

# ---------------------------------------------------------------------------
# HTML dashboard
# ---------------------------------------------------------------------------
CSS = """
body{font-family:-apple-system,Segoe UI,Roboto,sans-serif;background:#f6f7f9;color:#1b1f24;margin:0;padding:24px;line-height:1.5}
h1{font-size:20px;margin:0 0 4px}
.sub{color:#666;font-size:12px;margin-bottom:20px}
.card{background:#fff;border:1px solid #e3e6ea;border-radius:10px;padding:16px 18px;margin-bottom:18px}
.card h2{font-size:13px;text-transform:uppercase;letter-spacing:.04em;color:#556;margin:0 0 12px;border-bottom:1px solid #eef0f2;padding-bottom:8px}
table{width:100%;border-collapse:collapse;font-size:13px}
th{text-align:left;font-weight:600;color:#445;border-bottom:2px solid #e3e6ea;padding:8px 10px;font-size:11px;text-transform:uppercase;letter-spacing:.03em}
td{border-bottom:1px solid #eef0f2;padding:9px 10px;vertical-align:top}
tr:last-child td{border-bottom:none}
.badge{display:inline-block;padding:2px 8px;border-radius:20px;font-size:11px;font-weight:600}
.b-ok{background:#e6f6ec;color:#1a7f45}
.b-hidden{background:#fff4e0;color:#96620a}
.b-very{background:#fdeaea;color:#b3261e}
.b-prot{background:#e8effd;color:#1a4f9c}
.b-vba{background:#f3e8fd;color:#6a1b9a}
code{font-family:ui-monospace,Consolas,monospace;font-size:12px;background:#f1f3f5;padding:1px 5px;border-radius:4px}
pre{font-family:ui-monospace,Consolas,monospace;font-size:11px;background:#1b1f24;color:#e6edf3;padding:12px;border-radius:6px;overflow-x:auto;line-height:1.4}
pre.hex{background:#0d1117;color:#7ee787}
ul{margin:6px 0 0 18px;padding:0}
li{margin:3px 0;font-size:13px}
.muted{color:#888}
.pw-ok{color:#1a7f45;font-weight:600}
.pw-no{color:#b3261e}
details summary{cursor:pointer;color:#1a4f9c;font-size:12px;margin-top:8px}
"""

def _esc(x): return html.escape(str(x)) if x is not None else ""

def _badge_state(s):
    if s == "visible": return '<span class="badge b-ok">visible</span>'
    if s == "hidden":  return '<span class="badge b-hidden">hidden</span>'
    return '<span class="badge b-very">veryHidden</span>'

def write_html(report, path, fixed_path=None):
    parts = [
        '<!doctype html><html><head><meta charset="utf-8">',
        f'<title>Autopsy — {_esc(os.path.basename(report["file"]))}</title>',
        f'<style>{CSS}</style></head><body>',
        f'<h1>Office Autopsy</h1>',
        f'<div class="sub">{_esc(report["file"])} · {report["size"]:,} bytes · {_esc(report["analyzed_at"])}</div>',
    ]

    # Summary
    findings = "".join(f"<li>{_esc(f)}</li>" for f in report["findings"]) or "<li class='muted'>none</li>"
    fixed_line = f"<p>Fixed copy: <code>{_esc(fixed_path)}</code></p>" if fixed_path else ""
    parts.append(f'<div class="card"><h2>Summary</h2><ul>{findings}</ul>{fixed_line}</div>')

    # File info
    parts.append('<div class="card"><h2>File info</h2><table>')
    parts.append(f'<tr><td>Kind</td><td><span class="badge b-vba">{_esc(report["kind"])}</span></td></tr>')
    parts.append(f'<tr><td>SHA-256</td><td><code>{report["sha256"]}</code></td></tr>')
    if report.get("magic"):
        parts.append(f'<tr><td>Magic bytes</td><td><code>{_esc(report["magic"])}</code></td></tr>')
    if report.get("ole_streams"):
        parts.append(f'<tr><td>OLE streams</td><td>{len(report["ole_streams"])} streams</td></tr>')
    parts.append('</table></div>')

    # Workbook protection
    if report.get("workbook_protection") or report.get("file_sharing"):
        parts.append('<div class="card"><h2>Workbook-level locks</h2>')
        if report.get("workbook_protection"):
            parts.append("<b>workbookProtection</b><ul>")
            for k, v in report["workbook_protection"].items():
                parts.append(f"<li><code>{_esc(k)}</code> = <code>{_esc(v)}</code></li>")
            parts.append("</ul>")
        if report.get("file_sharing"):
            parts.append("<b>fileSharing</b><ul>")
            for k, v in report["file_sharing"].items():
                parts.append(f"<li><code>{_esc(k)}</code> = <code>{_esc(v)}</code></li>")
            parts.append("</ul>")
        parts.append('</div>')

    # Sheets
    if report["sheets"]:
        rows = []
        for s in report["sheets"]:
            prot = '<span class="muted">none</span>' if not s["protection"] else '<span class="badge b-prot">protected</span>'
            hh = f"<code>{s['password_hash_hex']}</code>" if s["password_hash_hex"] else '<span class="muted">-</span>'
            if s["password"]:
                pw = (f"<span class='pw-ok'>{_esc(s['password'])}</span>"
                      f"<br><span class='muted' style='font-size:11px'>{_esc(s['password_method'])}, variant={_esc(s['password_variant'])}</span>")
            elif s["password_method"]:
                pw = f"<span class='pw-no'>{_esc(s['password_method'])}</span>"
            elif s["password_hash_hex"]:
                pw = "<span class='pw-no'>not recovered</span>"
            else:
                pw = "<span class='muted'>no password</span>"
            if s["blocking"]:
                blocks = "<ul>" + "".join(f"<li>{_esc(b)}</li>" for b in s["blocking"]) + "</ul>"
            else:
                blocks = "<span class='muted'>nothing blocking</span>"
            rows.append(
                f"<tr><td><b>{_esc(s['name'])}</b>"
                f"<br><span class='muted' style='font-size:11px'>{_esc(s['xml'] or '')}</span></td>"
                f"<td>{_badge_state(s['state'])}</td>"
                f"<td>{prot}</td><td>{blocks}</td>"
                f"<td><code>{hh}</code></td><td>{pw}</td></tr>"
            )
        parts.append('<div class="card"><h2>Sheets ({})</h2><table>'
                     '<thead><tr><th>Sheet</th><th>Original state</th><th>Protection</th>'
                     '<th>What was blocking</th><th>Password hash</th><th>Recovered password</th>'
                     '</tr></thead><tbody>{}</tbody></table></div>'.format(len(report["sheets"]), "".join(rows)))

    # VBA
    vba = report.get("vba") or {}
    if vba.get("modules") or vba.get("analysis") or vba.get("error"):
        parts.append('<div class="card"><h2>VBA macros</h2>')
        if vba.get("error"):
            parts.append(f'<p class="pw-no">Error: {_esc(vba["error"])}</p>')
        if vba.get("modules"):
            parts.append(f'<p><b>{len(vba["modules"])} module(s) extracted</b></p><table>'
                         '<thead><tr><th>Module</th><th>Stream</th><th>Code length</th></tr></thead><tbody>')
            for m in vba["modules"]:
                parts.append(f'<tr><td><b>{_esc(m["vba_filename"])}</b></td>'
                             f'<td><code>{_esc(m["stream"])}</code></td>'
                             f'<td>{len(m["code"]):,} chars</td></tr>')
            parts.append('</tbody></table>')
            for i, m in enumerate(vba["modules"][:3]):
                parts.append(f'<details><summary>Code preview — {_esc(m["vba_filename"])}</summary>'
                             f'<pre>{_esc(m["code"][:2000])}</pre></details>')
            if len(vba["modules"]) > 3:
                parts.append(f'<p class="muted">… and {len(vba["modules"])-3} more modules (full code saved to disk)</p>')
        if vba.get("analysis"):
            sus = [a for a in vba["analysis"] if a and a[0] in ("Suspicious", "AutoExec", "IOC", "Description")]
            if sus:
                parts.append(f'<p><b>Suspicious indicators ({len(sus)}):</b></p><ul>')
                for a in sus[:30]:
                    parts.append(f'<li><span class="badge b-very">{_esc(a[0])}</span> '
                                 f'<code>{_esc(a[1])}</code> — {_esc(a[2][:100] if len(a)>2 else "")}</li>')
                parts.append('</ul>')
        parts.append('</div>')

    # Raw preview
    if report.get("raw_preview"):
        rp = report["raw_preview"]
        parts.append('<div class="card"><h2>Raw bytes</h2>')
        parts.append(f'<p>First 1KB: {rp["zeros"]} zero-bytes, {rp["ffs"]} 0xFF bytes</p>')
        hexdump = []
        for i in range(0, min(256, len(rp["hex_head"])), 16):
            chunk = rp["hex_head"][i:i+16]
            hex_part = " ".join(f"{b:02x}" for b in chunk)
            asc = "".join(chr(b) if 32 <= b < 127 else "." for b in chunk)
            hexdump.append(f"{i:04x}  {hex_part:<48}  {asc}")
        parts.append(f'<details open><summary>Hex dump (first 256 bytes)</summary><pre class="hex">{_esc(chr(10).join(hexdump))}</pre></details>')
        if rp["strings"]:
            parts.append('<details><summary>Extracted strings</summary><pre>{}</pre></details>'
                         .format(_esc("\n".join(rp["strings"][:40]))))
        parts.append('</div>')

    # Notes
    parts.append('<div class="card"><h2>Notes</h2><ul>'
                 '<li>Protection ≠ encryption. <code>&lt;sheetProtection&gt;</code>, '
                 '<code>&lt;workbookProtection&gt;</code>, and <code>state="veryHidden"</code> '
                 'are UI flags — deleting them requires no password. Only '
                 '“Encrypt with Password” (AES) actually protects a file.</li>'
                 '<li>Modern SHA-512 protection hashes are not brute-forced here; '
                 'the element is simply removed instead.</li>'
                 '<li>Fixed copy preserves <code>vbaProject.bin</code> untouched.</li>'
                 '<li>Recovered passwords via 16-bit legacy hash may be a collision '
                 '(works to unlock, not necessarily the original password).</li>'
                 '</ul></div>')

    parts.append("</body></html>")
    with open(path, "w", encoding="utf-8") as f:
        f.write("".join(parts))

# ---------------------------------------------------------------------------
# Console report
# ---------------------------------------------------------------------------
def print_console(report, fixed_path=None, macro_dir=None):
    print("\n" + "=" * 74)
    print(f"  {os.path.basename(report['file'])}  ·  {report['kind']}  ·  {report['size']:,} bytes")
    print("=" * 74)
    for f in report["findings"]:
        print(f"  • {f}")

    if report["sheets"]:
        print(f"\n  SHEETS ({len(report['sheets'])}):")
        print(f"   {'name':<22}{'state':<12}{'prot':<6}{'hash':<8}{'password'}")
        print("   " + "-" * 60)
        for s in report["sheets"]:
            pw = s["password"] or ("-" if not s["password_hash_hex"] else "?")
            print(f"   {s['name'][:21]:<22}{s['state']:<12}"
                  f"{'yes' if s['protection'] else 'no':<6}"
                  f"{(s['password_hash_hex'] or '-'):<8}{pw}")

    vba = report.get("vba") or {}
    if vba.get("modules"):
        print(f"\n  VBA: {len(vba['modules'])} module(s)")
        for m in vba["modules"][:10]:
            print(f"   • {m['vba_filename']}  ({len(m['code'])} chars)")
        if vba.get("analysis"):
            sus = [a for a in vba["analysis"] if a and a[0] in ("Suspicious","AutoExec","IOC")]
            if sus:
                print(f"   ⚠ {len(sus)} suspicious/auto-exec hits")
    elif vba.get("error"):
        print(f"\n  VBA: {vba['error']}")

    if fixed_path:
        print(f"\n  Fixed copy : {fixed_path}")
    if macro_dir:
        print(f"  Macros dir : {macro_dir}")
    print()

# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
def parse_args():
    filepath = None
    opts = {"maxlen": 3, "crack": False, "vba": True, "fix": False}
    for a in sys.argv[1:]:
        if a.startswith("--"):
            if   a == "--no-crack":  opts["crack"] = False
            elif a == "--no-vba":    opts["vba"] = False
            elif a == "--no-fix":    opts["fix"] = False
            elif a.startswith("--maxlen="): opts["maxlen"] = int(a.split("=",1)[1])
        elif filepath is None:
            filepath = a
    return filepath, opts

def main(argv=None):
    import argparse, json
    from autopsy_support import (
        _guard_output_file, binary_preview, export_macros, repair_copy,
        audit_xlsb, main as support_main
    )
    args_list = list(sys.argv[1:] if argv is None else argv)
    if args_list and args_list[0] in ("inspect", "repair", "macros"):
        sys.argv = [sys.argv[0]] + args_list
        return support_main()

    ap = argparse.ArgumentParser(
        prog="office_autopsy.py",
        description="Office Autopsy 3.2 — Container, protection, visibility, BIFF8/XLSB/OLE & VBA inspector",
    )
    ap.add_argument("filepath", help="Path to workbook (.xlsx, .xlsm, .xlsb, .xls), OLE file, or raw binary")
    ap.add_argument("--crack", "--recover-passwords", dest="crack", action="store_true", default=False,
                    help="Attempt legacy 16-bit XOR password collision recovery")
    ap.add_argument("--no-crack", dest="crack", action="store_false", help="Disable password hash recovery (default)")
    ap.add_argument("--no-vba", dest="vba", action="store_false", default=True, help="Skip VBA macro extraction")
    ap.add_argument("--no-fix", action="store_true", help="Read-only inspection (default)")
    ap.add_argument("--fix", action="store_true", help="Deprecated: use --repair-output NEW_COPY instead")
    ap.add_argument("--repair-output", metavar="NEW_COPY", help="Write a verified unhidden/unprotected OOXML copy to NEW_COPY")
    ap.add_argument("--export-macros", metavar="DIR", help="Export VBA modules with SHA-256 manifest to DIR")
    ap.add_argument("--maxlen", type=int, default=3, help="Max brute-force length for legacy 16-bit hashes (default 3)")
    ap.add_argument("--export-json", metavar="JSON_PATH", help="Save full JSON inspection report")
    ap.add_argument("--html", metavar="HTML_PATH", help="Save standalone HTML inspection report")
    ap.add_argument("--quiet", action="store_true", help="Suppress console table output")
    parsed = ap.parse_args(args_list)

    if parsed.fix and not parsed.repair_output:
        ap.error("Automatic in-place --fix is disabled for source safety. Pass --repair-output NEW_COPY.xlsx or run: python3 autopsy_support.py repair INPUT --output NEW_COPY.xlsx")

    for flag, out_p in (("--export-json", parsed.export_json), ("--html", parsed.html), ("--repair-output", parsed.repair_output)):
        if out_p:
            try:
                _guard_output_file(parsed.filepath, out_p, flag)
            except ValueError as exc:
                ap.error(str(exc))

    kind = detect_kind(parsed.filepath)
    if kind in ("xlsx", "xlsm"):
        rep = audit_ooxml(parsed.filepath, do_crack=parsed.crack, max_len=parsed.maxlen, do_vba=parsed.vba)
    elif kind == "xlsb":
        rep = audit_xlsb(parsed.filepath)
    elif kind == "xls":
        rep = audit_xls(parsed.filepath, do_crack=parsed.crack, max_len=parsed.maxlen, do_vba=parsed.vba)
    elif kind in ("doc", "ppt", "msg", "vbaProject.bin", "ole_unknown", "encrypted_office"):
        rep = audit_vbaproject(parsed.filepath, do_vba=parsed.vba)
    else:
        rep = audit_raw(parsed.filepath)

    rep["analyzed_at"] = datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
    rep["binary"] = binary_preview(parsed.filepath)

    fixed_path = None
    if parsed.repair_output:
        rep["repair_result"] = repair_copy(parsed.filepath, parsed.repair_output)
        fixed_path = rep["repair_result"]["path"]

    macro_dir = None
    if parsed.export_macros:
        rep["macro_export"] = export_macros(parsed.filepath, parsed.export_macros)
        macro_dir = parsed.export_macros

    if parsed.html:
        write_html(rep, parsed.html, fixed_path=fixed_path)

    json_rep = dict(rep)
    json_rep.pop("raw_preview", None)
    if parsed.export_json:
        with open(parsed.export_json, "w", encoding="utf-8") as f:
            json.dump(json_rep, f, indent=2)

    if not parsed.quiet:
        print_console(rep, fixed_path=fixed_path, macro_dir=macro_dir)
    return 0

if __name__ == "__main__":
    main()
