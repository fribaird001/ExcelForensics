# Excel Workbook Forensics & Office Autopsy (`excel-workbook-forensics` v3.2.1)

Read-only structural reconnaissance, formula dependency mapping, `#REF!` blast-radius attribution, RTD/connection auditing, protection/visibility inspection, surgical OOXML unhide/unprotect repair, and MS-OVBA/BIFF8 reverse engineering for Microsoft Excel workbooks (`.xlsx`, `.xlsm`, `.xlsb`, `.xls`).

Designed to operate both as a **standalone CLI toolkit** and as a **portable Agent Skill** (`SKILL.md` + `scripts/` + `references/`).

---

## Key Capabilities

* **Incremental OOXML Streaming (`scripts/workbook_forensics.py`)**: Streams `<c>` and `<row>` nodes via `iterparse` (detaching processed rows under `lxml`) so million-row sparse grids (`1048576` row trap) never hang or exhaust memory.
* **2D Shared-Formula Coordinate Translation**: Resolves `<f t="shared" si="K"/>` slave formulas (including out-of-order slaves) and translates relative A1 coordinates while keeping `$col`/`$row` anchors, string literals, and sheet prefixes intact.
* **Complete Cross-Sheet & Non-Formula Bridges**: Resolves both quoted (`'Start:End'!A1`) and unquoted (`Start:End!A1`) 3D spans, direct cross-sheet references, Excel Table structured references (`Table[Col]`), defined names, Charts (`<c:f>` and Office 2016+ `<cx:f>` `chartEx`), and PivotCache worksheet sources.
* **`#REF!` Blast-Radius Attribution**: Separates root-cause `#REF!` formula seeds (`=#REF!+1`) from downstream cascade victims across static A1 ranges and ranks every seed by downstream cell impact.
* **Volatile RTD & Connection Auditing**: Summarizes `xl/volatileDependencies.xml` per RTD server/topic (`NUMERIC`/`BOOLEAN` vs. `REQUESTING_DATA`/`NO_DATA`) at Level 2+ and inspects `xl/connections.xml`, `xl/queryTables/`, and `customXml/` (`DataMashup` Power Query) with automatic credential/token redaction.
* **Spec-Driven MS-OVBA & Ribbon Forensics (`scripts/vba_inspector.py`)**: Parses `VBA/dir` TLV records (`PROJECTCODEPAGE`, `MODULEOFFSET`, `MODULETYPE`), slices module streams at exact `MODULEOFFSET`, cross-checks OOXML worksheet `codeName` bindings to flag orphaned ghost modules, resolves `customUI` Ribbon callbacks, and performs a VBE line-numbered static capability & credential risk scan.
* **Protection Auditing, Legacy `.xls` BIFF8 & Surgical OOXML Repair (`scripts/office_autopsy.py` & `scripts/autopsy_support.py`)**: Content-sniffs magic bytes, audits `workbookProtection`/`sheetProtection` and hidden rows/columns across OOXML and legacy BIFF8 `.xls`, recovers compatible legacy 16-bit XOR password collisions (`--recover-passwords`), exports VBA macros with SHA-256 manifests, and creates byte-preserving unhidden/unprotected OOXML copies while preserving `mc:Ignorable` XML namespace declarations.

---

## Requirements & Dependencies

* **Python**: `>= 3.9` (tested on Python 3.10, 3.11, and 3.12).
* **Required Packages**: **None (Python standard library only)**. All core OOXML (`zipfile`, `xml.etree.ElementTree`), MS-OVBA (`struct`), BIFF8 record parsing, and collision/namespace guards run out of the box with zero third-party packages.
* **Optional Accelerators & Binary Helpers** (`pip install -r requirements.txt`):
  * `lxml>=4.9.0`: Fast C-backed `iterparse` XML streaming and parent row detachment on million-row worksheets.
  * `openpyxl>=3.1.0`: Formula tokenizer (`openpyxl.formula.Tokenizer`) and synthetic test workbook generation.
  * `olefile>=0.46`: OLE2 Compound Document stream directory listing for legacy `.xls`, `.doc`, `.ppt`, and encrypted Office containers (`detect_kind` and `.xlsx`/`.xlsm` preflight work without `olefile`).
  * `oletools>=0.60.1`: Deobfuscated VBA extraction (`olevba`) and compiled p-code vs. source mismatch detection (`detect_vba_stomping`).

---

## Quick Start

### 1. Environment Capability Probe
```bash
python3 scripts/workbook_forensics.py --check-env
```

### 2. Container, Protection & Visibility Preflight (`.xlsx`, `.xlsm`, `.xls`, `.xlsb`, `.bin`)
```bash
# Read-only console & JSON inspection (works without olefile on OOXML files)
python3 scripts/office_autopsy.py path/to/workbook.xlsx --export-json autopsy_report.json

# Subcommand interface via autopsy_support.py (with optional legacy 16-bit hash recovery)
python3 scripts/autopsy_support.py inspect path/to/workbook.xlsx --recover-passwords --export-json preflight.json
```

### 3. Structural, Formula Lineage, `#REF!` Blast Radius & RTD Audit (Levels 1–4)
```bash
# Level 2: Standard formula, bridge, #REF! blast radius & RTD audit + Graphviz DAG
python3 scripts/workbook_forensics.py path/to/workbook.xlsx --level 2 \
    --export-json level2_audit.json --export-dot dependency_dag.dot

# Level 3: Adds R1C1 pattern normalization and sheet + intra-sheet cell Tarjan SCC cycles
python3 scripts/workbook_forensics.py path/to/workbook.xlsx --level 3 \
    --export-json level3_audit.json --export-dot dependency_dag.dot

# Level 4: Full forensic audit including MS-OVBA module bindings, Ribbon callbacks & VBA risk scan
python3 scripts/workbook_forensics.py path/to/workbook.xlsm --level 4 \
    --export-json level4_audit.json
```

### 4. Standalone MS-OVBA Macro Inspection & Export
```bash
# Inspect xl/vbaProject.bin and run static capability + redacted-credential risk scan
python3 scripts/vba_inspector.py path/to/workbook.xlsm --extract-code --export-json vba_audit.json

# Export VBA modules (.bas/.cls) with SHA-256 manifest to a new directory
python3 scripts/autopsy_support.py macros path/to/workbook.xlsm --output path/to/vba_export
```

### 5. Verified Surgical OOXML Unhide / Unprotect Copy
```bash
# Writes a new copy with workbookProtection/sheetProtection removed and hidden/veryHidden tabs made visible.
# Verifies output ZIP CRCs, unchanged part byte-identity, mc:Ignorable namespace preservation, and source SHA-256.
python3 scripts/autopsy_support.py repair path/to/locked.xlsx --output path/to/unlocked_copy.xlsx
```

---

## Running the Regression Test Suite

The repository includes an automated regression test suite (`tests/test_regressions.py`) covering output path collision guards (direct, symlink, hardlink), `mc:Ignorable` XML namespace preservation during repair, credential/token redaction in VBA and connection strings, `office_autopsy.py` CLI execution without `olefile`, quoted and unquoted 3D span lineage, Level 2–3 RTD extraction, shared-formula coordinate translation, `#REF!` blast-radius ranking, and BIFF8 record offsets:

```bash
python3 -m unittest discover -s tests -v
```

---

## Supported Formats & Explicit Scope Boundaries

| Format | Support Scope | Known Boundaries |
| :--- | :--- | :--- |
| **`.xlsx` / `.xlsm` / `.xltx` / `.xltm`** | Full Level 1–4 static OOXML forensics, DAG lineage, `#REF!` blast radius, RTD/connections, protection audit, and surgical unhide/unprotect copy. | Static inspection does not recalculate formulas in Excel, refresh live RTD/Bloomberg feeds, or resolve runtime strings inside `INDIRECT()`/`OFFSET()`. |
| **`xl/vbaProject.bin`** | OLE2 stream inventory, `VBA/dir` TLV decoding, exact `MODULEOFFSET` decompression, worksheet `codeName` binding checks, and static capability/credential risk scan. | Does not execute macros or certify absence of malware. P-code stomping check requires optional `oletools`. |
| **`.xls` (BIFF8)** | Native BIFF8 record scan for sheet visibility (`BOUNDSHEET`), protection/hashes (`PROTECT`/`PASSWORD`), hidden rows/columns (`ROW`/`COLINFO`), and VBA extraction. | Binary BIFF8 formula tokens (`rgce`) are not decoded into a DAG natively; convert a scratch copy to `.xlsx` via headless LibreOffice for formula lineage. |
| **`.xlsb` (BIFF12)** | Scoped ZIP/OPC container inventory (`xl/workbook.bin`, `xl/vbaProject.bin`, `xl/connections.bin`) and VBA inspection. | Binary BIFF12 worksheet and formula records are not decoded. |
| **Encrypted Office** | Detects `EncryptedPackage` / `EncryptionInfo` streams and modern agile/SHA-512 protection spin counts. | Password-encrypted containers cannot be inspected or repaired without decryption. |
