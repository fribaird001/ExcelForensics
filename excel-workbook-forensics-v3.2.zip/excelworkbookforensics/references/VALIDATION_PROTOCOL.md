# Validation Protocol, Quality Gates & Epistemic Rules (`references/VALIDATION_PROTOCOL.md`)

Every forensic audit produced with `excel-workbook-forensics` must adhere to the 9 mandatory Quality Gates (`G1`–`G9`), the 4-tier Epistemic Classification system, and strict non-fabrication boundaries.

## 1. The 9 Mandatory Quality Gates (`G1`–`G9`)

`scripts/workbook_forensics.py` automatically evaluates and emits the `quality_gates` block in every JSON report. Note that static parsers **cannot self-certify** semantic oracle accuracy (`G3`, `G4`, `G5`, `G7`); those gates emit `REVIEW_REQUIRED` or `PARTIAL` so the analyst verifies edge cases rather than relying on a manufactured `PASS`.

| Gate | JSON Key | Verification Criteria & Status Semantics |
| :--- | :--- | :--- |
| **`G1`** | `G1_preflight_integrity` | **`PASS` / `FAIL`**: Confirms `xl/workbook.xml` exists and every `<sheet>` declared in `xl/workbook.xml` resolves via `xl/_rels/workbook.xml.rels` (using canonical OPC path normalization) to an existing worksheet XML part inside the ZIP container (`missing_worksheet_xml_count == 0`). |
| **`G2`** | `G2_shared_formula_accounting` | **`PASS` / `FAIL`**: Confirms every slave shared formula `<f t="shared" si="K"/>` resolved to a valid master formula `si="K"` on the same worksheet (`unresolved_slaves == 0`) and had its relative A1 coordinates translated. |
| **`G3`** | `G3_string_and_external_disambiguation` | **`REVIEW_REQUIRED`**: Requires confirming that string literals (`"..."`) and 1-based external workbook references (`[1]..[N]`) were stripped prior to internal sheet matching, and that external links referenced inside `<definedNames>` (`external_links_used_only_by_defined_names`) are distinguished from truly orphaned links (`orphaned_external_links_ids`). |
| **`G4`** | `G4_quote_safe_function_tokenization` | **`REVIEW_REQUIRED`**: Requires confirming that single-quoted worksheet names (`'Summary (T-1)'!A1`) and string literals were stripped before counting function calls (`top_functions` / `global_top_functions`). |
| **`G5`** | `G5_cycle_and_bridge_accounting` | **`SKIPPED` (Level < 3) / `PARTIAL` / `REVIEW_REQUIRED`**: Tracks sheet-level SCC cycles (`sheet_cycles`), intra-sheet cell-level SCC cycles (`intra_sheet_cycles`), 3D sheet spans, structured tables, defined names, charts (`chart` + `chartEx`), and PivotCaches. Emits `PARTIAL` if any worksheet exceeded `max_graph_nodes` (50,000) or `max_pairs` (4,000,000) or contains dynamic indirection. Note: `sheet_cycles` indicates mutual cross-sheet dependency (`SheetA <-> SheetB`), which is **not** proof of a cell-level circularity unless a cell cycle spans those references. |
| **`G6`** | `G6_cached_values_and_calc_mode` | **`DISCLOSED_NOT_RECALCULATED`**: Enforces explicit disclosure of `calc_mode` (`auto`, `manual`, `autoNoTable`), `iterate`, `uncalculated_formula_cells`, and RTD topic states (`volatile_rtd`). Static XML inspection reads cached `<v>` values saved at last workbook write and does **not** recalculate formulas in Excel. |
| **`G7`** | `G7_dynamic_and_unresolved` | **`PARTIAL` / `REVIEW_REQUIRED`**: Flags worksheets containing runtime indirection (`INDIRECT`, `OFFSET`, `ADDRESS`) via `dynamic_indirection_cells_total` and `dependency_completeness: "PARTIAL_DYNAMIC_INDIRECTION"`. Static DAGs cannot resolve runtime string-concatenated targets without evaluation. |
| **`G8`** | `G8_evidence_traceability` | **`PARTIAL_SAMPLED`**: Indicates that formula samples (`sample_formulas`, `formula_ref_error_samples`, `dynamic_indirection_cells`, `per_seed` blast radius) are capped to keep report payloads bounded; full cell-level verification can be run on specific sheets/ranges as needed. |
| **`G9`** | `G9_source_preserved` | **`true` / `false`**: Cryptographic SHA-256 verification (`sha256_before == compute_sha256(filepath)`) proving that the target workbook was not modified during inspection. |

---

## 2. Four-Tier Epistemic Classification Contract

Every forensic report must separate claims into four explicit epistemic tiers:

1. **Verified Facts (Direct Static Evidence)**
   - Directly observed container and XML facts backed by SHA-256 hashes, exact part paths, and cell coordinates:
     - File magic signature, byte size, SHA-256 hash, `date1904`, `calcMode`, `iterate`.
     - Sheet names, visibility states (`visible`, `hidden`, `veryHidden`), worksheet `codeName` attributes, protection flags (`sheetProtection`, `workbookProtection`, legacy 16-bit hash hex), and hidden row/column counts.
     - Exact counts of XML `<c>` nodes, populated cells, styled blanks, explicit/master formulas, expanded shared slave formulas, uncalculated formulas, and cached error literals (`#REF!`, `#NAME?`, `#VALUE!`, `#N/A`, `#DIV/0!`).
     - Static cross-sheet edges (`direct_cell_ref`, `3d_span`, `structured_table`, `defined_name`), chart series (`<c:f>`, `<cx:f>`), PivotCache worksheet sources, external link targets (`[1]..[N]`), and decompressed VBA module streams.

2. **Strongly Supported Interpretations (Static Graph & Capability Inferences)**
   - Logical consequences derived deterministically from static structure:
     - Topological DAG tiers (`Tier 0` primary inputs through `Tier N` terminal outputs) and sheet role classifications.
     - Static `#REF!` BFS blast-radius attribution (`ref_blast_radius`: identifying which root-cause `#REF!` formula seeds corrupt which downstream formula cells across static A1 ranges).
     - Ghost VBA module identification (comparing `VBA/dir` document modules against active `<sheetPr codeName="..."/>` bindings).
     - Static VBA capability and risk findings (`scan_vba_risks`: auto-exec triggers, `Shell`/`CreateObject`, `Declare` Win32 APIs, connection strings, and redacted credential assignments).

3. **Tentative Hypotheses (Leads Requiring Runtime or Domain Confirmation)**
   - Patterns that suggest a root cause or anomaly but cannot be proven from static XML alone:
     - Sheet-level SCC cycles (`sheet_cycles`) where `SheetA` references `SheetB` and `SheetB` references `SheetA` on disjoint cells (mutual sheet dependency vs. true cell-level circularity).
     - Static Ribbon callback name matches (`customUI/*.xml` -> `Module.Proc`), which do not prove runtime invocation success.
     - `oletools` VBA stomping heuristic (`POSSIBLE_MISMATCH`), which can be triggered either by malicious p-code tampering or by benign saves across different Excel/VBA versions.
     - Legacy 16-bit XOR protection hash collisions (`crack_legacy`): a recovered string that produces the same 16-bit verifier hash unlocks the sheet in Excel, but is a mathematical collision rather than proof of the author's original password string.

4. **Unknown / Inaccessible Information (Explicit Scope Boundaries)**
   - Anything that static, offline, non-executing inspection cannot observe:
     - Runtime target resolution of `INDIRECT()`, `OFFSET()`, or VBA `Application.Run` / `Range(...)` macros.
     - Live terminal connectivity or current market values for Bloomberg/Reuters/Capital IQ RTD feeds (`xl/volatileDependencies.xml` records only the state cached at the last save).
     - Binary formula graphs inside `.xlsb` (`xl/workbook.bin`), binary Power Query `DataMashup` blobs inside `customXml/`, or password-encrypted Office containers (`EncryptedPackage`).
     - Business/domain correctness of model assumptions or full Excel calculation engine parity.

---

## 3. Redaction & Safety Rules

- **Source Immutability**: Never modify the inspected file in place. Any unhide/unprotect repair (`autopsy_support.py repair`) or macro export (`autopsy_support.py macros`) must write to a new destination path and verify `source_preserved == true`.
- **Credential Redaction**: Never emit raw passwords, API keys, or tokens found in `xl/connections.xml` or VBA module source code. Always use `<redacted>` or `<redacted:N chars>` as implemented in `workbook_forensics.py` and `vba_inspector.py`.
- **No Silent Truncation**: Whenever sample lists (`sample_formulas`, `problem_samples`, `per_seed`) or large intra-sheet graphs are capped, report the exact total count alongside the truncation flag (`SKIPPED_FORMULA_NODE_LIMIT`, `per_seed_truncated`, `dynamic_indirection_samples_truncated`).
