#!/usr/bin/env python3
"""Regression test suite for excel-workbook-forensics (v3.2.1 / Engine v2.4.1).

Covers all 6 author-reported P1/P2 findings plus core OOXML, BIFF8, MS-OVBA,
and zero-dependency fallback guarantees. Run with `pytest` or `python3 -m unittest`.
"""
import hashlib
import io
import json
import os
import subprocess
import sys
import tempfile
import unittest
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = ROOT / "scripts"
sys.path.insert(0, str(SCRIPTS))

import workbook_forensics as wf
import vba_inspector as vba
import autopsy_support as support
import office_autopsy as oa


def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def _build_minimal_ooxml(
    path: Path,
    sheets=None,
    defined_names=None,
    volatile_xml: str = "",
    connections_xml: str = "",
    extra_parts=None,
) -> None:
    """Create a deterministic, spec-valid minimal .xlsx archive without requiring openpyxl."""
    if sheets is None:
        sheets = [("Sheet1", "visible", '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData><row r="1"><c r="A1"><v>42</v></c></row></sheetData></worksheet>')]
    defined_names = defined_names or []
    extra_parts = extra_parts or {}

    with zipfile.ZipFile(path, "w", compression=zipfile.ZIP_DEFLATED) as z:
        ct_overrides = [
            '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
        ]
        sheet_els = []
        rel_els = []
        for idx, (name, state, xml_body) in enumerate(sheets, start=1):
            rid = f"rId{idx}"
            part_name = f"worksheets/sheet{idx}.xml"
            ct_overrides.append(
                f'<Override PartName="/xl/{part_name}" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'
            )
            state_attr = f' state="{state}"' if state != "visible" else ""
            sheet_els.append(f'<sheet name="{name}" sheetId="{idx}"{state_attr} r:id="{rid}"/>')
            rel_els.append(
                f'<Relationship Id="{rid}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="{part_name}"/>'
            )
            z.writestr(f"xl/{part_name}", xml_body.encode("utf-8") if isinstance(xml_body, str) else xml_body)

        dn_block = ""
        if defined_names:
            dn_items = [f'<definedName name="{k}">{v}</definedName>' for k, v in defined_names]
            dn_block = "<definedNames>" + "".join(dn_items) + "</definedNames>"

        wb_xml = (
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" '
            'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
            '<workbookPr date1904="0"/>'
            f'<sheets>{"".join(sheet_els)}</sheets>'
            f"{dn_block}"
            '<calcPr calcMode="auto"/>'
            "</workbook>"
        )
        z.writestr("xl/workbook.xml", wb_xml.encode("utf-8"))
        z.writestr(
            "xl/_rels/workbook.xml.rels",
            (
                '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
                f'{"".join(rel_els)}'
                "</Relationships>"
            ).encode("utf-8"),
        )
        z.writestr(
            "[Content_Types].xml",
            (
                '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
                '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
                '<Default Extension="xml" ContentType="application/xml"/>'
                f'{"".join(ct_overrides)}'
                "</Types>"
            ).encode("utf-8"),
        )
        if volatile_xml:
            z.writestr("xl/volatileDependencies.xml", volatile_xml.encode("utf-8"))
        if connections_xml:
            z.writestr("xl/connections.xml", connections_xml.encode("utf-8"))
        for k, v in extra_parts.items():
            z.writestr(k, v.encode("utf-8") if isinstance(v, str) else v)


class TestReleaseBlockersAndGaps(unittest.TestCase):
    """Verifies fixes for all 4 P1 blockers and 2 P2 gaps identified in peer review."""

    def test_p1_source_destruction_guard_blocks_same_path_symlink_and_hardlink(self):
        """P1: --export-json and --export-dot must never overwrite the input workbook (direct, symlink, or hardlink)."""
        with tempfile.TemporaryDirectory() as td:
            td_path = Path(td)
            wb = td_path / "model.xlsx"
            _build_minimal_ooxml(wb)
            before_hash = _sha256(wb)

            sym = td_path / "alias_sym.xlsx"
            os.symlink(wb, sym)
            hlink = td_path / "alias_hard.xlsx"
            os.link(wb, hlink)

            # 1. workbook_forensics.py direct, symlink, hardlink collision checks
            for bad_target in (wb, sym, hlink):
                for flag in ("--export-json", "--export-dot"):
                    proc = subprocess.run(
                        [sys.executable, str(SCRIPTS / "workbook_forensics.py"), str(wb), flag, str(bad_target)],
                        capture_output=True,
                        text=True,
                    )
                    self.assertNotEqual(proc.returncode, 0, f"Expected failure for {flag}={bad_target}")
                    self.assertEqual(_sha256(wb), before_hash, "Source workbook was modified or destroyed!")

            # 2. vba_inspector.py collision check
            for bad_target in (wb, sym, hlink):
                proc = subprocess.run(
                    [sys.executable, str(SCRIPTS / "vba_inspector.py"), str(wb), "--export-json", str(bad_target)],
                    capture_output=True,
                    text=True,
                )
                self.assertNotEqual(proc.returncode, 0)
                self.assertEqual(_sha256(wb), before_hash)

            # 3. autopsy_support.py inspect --export-json and repair --output collision checks
            for bad_target in (wb, sym, hlink):
                proc1 = subprocess.run(
                    [sys.executable, str(SCRIPTS / "autopsy_support.py"), "inspect", str(wb), "--export-json", str(bad_target)],
                    capture_output=True,
                    text=True,
                )
                self.assertNotEqual(proc1.returncode, 0)
                proc2 = subprocess.run(
                    [sys.executable, str(SCRIPTS / "autopsy_support.py"), "repair", str(wb), "--output", str(bad_target)],
                    capture_output=True,
                    text=True,
                )
                self.assertNotEqual(proc2.returncode, 0)
                self.assertEqual(_sha256(wb), before_hash)

            # 4. office_autopsy.py --export-json and --html collision checks
            for flag in ("--export-json", "--html", "--repair-output"):
                proc3 = subprocess.run(
                    [sys.executable, str(SCRIPTS / "office_autopsy.py"), str(wb), flag, str(sym)],
                    capture_output=True,
                    text=True,
                )
                self.assertNotEqual(proc3.returncode, 0)
                self.assertEqual(_sha256(wb), before_hash)

    def test_p1_repair_preserves_mc_ignorable_and_unused_namespace_declarations(self):
        """P1: repair_copy must preserve xmlns:x15, xmlns:x14ac, xmlns:xr referenced by mc:Ignorable."""
        with tempfile.TemporaryDirectory() as td:
            td_path = Path(td)
            src = td_path / "protected_ns.xlsx"
            out = td_path / "repaired_ns.xlsx"
            sheet_xml = (
                '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" '
                'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" '
                'xmlns:mc="http://schemas.openxmlformats.org/markup-compatibility/2006" '
                'xmlns:x14ac="http://schemas.microsoft.com/office/spreadsheetml/2009/9/ac" '
                'xmlns:xr="http://schemas.microsoft.com/office/spreadsheetml/2014/revision" '
                'xmlns:x15="http://schemas.microsoft.com/office/spreadsheetml/2010/11/main" '
                'mc:Ignorable="x14ac xr x15" '
                'xr:uid="{00000000-0001-0000-0000-000000000000}">'
                '<sheetData><row r="1"><c r="A1"><v>10</v></c></row></sheetData>'
                '<sheetProtection sheet="1" objects="1" scenarios="1" password="83AF"/>'
                "</worksheet>"
            )
            _build_minimal_ooxml(src, sheets=[("LockedTab", "veryHidden", sheet_xml)])
            res = support.repair_copy(src, out)
            self.assertEqual(res["output_archive_integrity"], "VERIFIED")
            self.assertTrue(res["postconditions"]["namespaces_and_ignorable_preserved"])
            self.assertTrue(res["postconditions"]["sheet_protection_removed"])
            self.assertTrue(res["postconditions"]["all_sheets_visible"])

            with zipfile.ZipFile(out, "r") as z:
                repaired_sheet = z.read("xl/worksheets/sheet1.xml")
                decls = dict(support._extract_ns_decls(repaired_sheet))
                self.assertIn("x15", decls, "xmlns:x15 was dropped during repair serialization!")
                self.assertIn("x14ac", decls, "xmlns:x14ac was dropped during repair serialization!")
                self.assertIn("xr", decls, "xmlns:xr was dropped during repair serialization!")
                self.assertNotIn(b"sheetProtection", repaired_sheet)

    def test_p1_credential_redaction_covers_doubled_quotes_url_tokens_and_basic_auth(self):
        """P1: Risk-report snippets must redact doubled-quote VBA passwords, URL ?token= params, and basic-auth URLs."""
        vba_code = "\n".join([
            'Sub ConnectFeed()',
            '    Const API_SECRET As String = "super_secret_token_999"',
            '    Dim conn As Object',
            '    Set conn = CreateObject("ADODB.Connection")',
            '    conn.Open "Provider=SQLOLEDB;Data Source=prod;Password=""MyDoubledQuoteSecret!"";User ID=trader"',
            '    Dim http As Object',
            '    Set http = CreateObject("MSXML2.XMLHTTP")',
            '    http.Open "GET", "https://feed.desk.internal/v2/prices?token=eyJhbGciOiJIUzI1NiJ9.secret_payload&symbol=BRN", False',
            '    http.Open "GET", "https://desk_user:InlineUrlPass456@feed.desk.internal/v2/auth", False',
            'End Sub',
        ])
        scan = vba.scan_vba_risks({"ModRisk": vba_code})
        serialized = json.dumps(scan)
        for leaked_secret in (
            "super_secret_token_999",
            "MyDoubledQuoteSecret!",
            "eyJhbGciOiJIUzI1NiJ9.secret_payload",
            "InlineUrlPass456",
        ):
            self.assertNotIn(leaked_secret, serialized, f"Leaked synthetic secret in risk scan output: {leaked_secret}")
        self.assertGreaterEqual(scan["summary"]["HIGH"], 3)

    def test_p1_office_autopsy_cli_entry_point_and_zero_olefile_xlsx_preflight(self):
        """P1: office_autopsy.py --help and XLSX inspection work without desk_excel or olefile."""
        with tempfile.TemporaryDirectory() as td:
            wb = Path(td) / "sample.xlsx"
            _build_minimal_ooxml(wb)
            out_json = Path(td) / "oa_report.json"

            # 1. --help succeeds
            p_help = subprocess.run(
                [sys.executable, str(SCRIPTS / "office_autopsy.py"), "--help"],
                capture_output=True,
                text=True,
            )
            self.assertEqual(p_help.returncode, 0, p_help.stderr)
            self.assertIn("Office Autopsy 3.2", p_help.stdout)

            # 2. Direct invocation on .xlsx succeeds even if olefile is blocked from import
            env = dict(os.environ)
            code_block_olefile = (
                "import builtins, sys; orig_imp = builtins.__import__; "
                "builtins.__import__ = lambda n, *a, **k: (_ for _ in ()).throw(ImportError('no olefile')) if n == 'olefile' else orig_imp(n, *a, **k); "
                f"sys.path.insert(0, {str(SCRIPTS)!r}); "
                "import office_autopsy as oa; "
                f"sys.exit(oa.main([{str(wb)!r}, '--no-vba', '--quiet', '--export-json', {str(out_json)!r}]))"
            )
            p_run = subprocess.run([sys.executable, "-c", code_block_olefile], capture_output=True, text=True, env=env)
            self.assertEqual(p_run.returncode, 0, p_run.stderr)
            self.assertTrue(out_json.exists())
            rep = json.loads(out_json.read_text(encoding="utf-8"))
            self.assertEqual(rep["kind"], "xlsx")
            self.assertEqual(len(rep["sheets"]), 1)

    def test_p2_unquoted_and_quoted_3d_spans_produce_identical_lineage_edges(self):
        """P2: SUM(Start:End!A1) and SUM('Start:End'!A1) must both expand across Start, Mid, End."""
        with tempfile.TemporaryDirectory() as td:
            wb_unquoted = Path(td) / "3d_unquoted.xlsx"
            wb_quoted = Path(td) / "3d_quoted.xlsx"

            def _sheet_val(v):
                return f'<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData><row r="1"><c r="A1"><v>{v}</v></c></row></sheetData></worksheet>'

            def _sheet_fml(f_txt):
                return f'<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData><row r="1"><c r="A1"><f>{f_txt}</f><v>60</v></c></row></sheetData></worksheet>'

            _build_minimal_ooxml(
                wb_unquoted,
                sheets=[
                    ("Start", "visible", _sheet_val(10)),
                    ("Mid", "visible", _sheet_val(20)),
                    ("End", "visible", _sheet_val(30)),
                    ("Rollup", "visible", _sheet_fml("SUM(Start:End!A1)")),
                ],
                defined_names=[("SpanName", "SUM(Start:End!A1)")],
            )
            _build_minimal_ooxml(
                wb_quoted,
                sheets=[
                    ("Start", "visible", _sheet_val(10)),
                    ("Mid", "visible", _sheet_val(20)),
                    ("End", "visible", _sheet_val(30)),
                    ("Rollup", "visible", _sheet_fml("SUM('Start:End'!A1)")),
                ],
                defined_names=[("SpanName", "SUM('Start:End'!A1)")],
            )

            rep_u = wf.analyze_workbook(str(wb_unquoted), level=3)
            rep_q = wf.analyze_workbook(str(wb_quoted), level=3)

            edges_u = {(e["formula_sheet"], e["depends_on_sheet"]): e["mechanisms"] for e in rep_u["internal_edges"]}
            edges_q = {(e["formula_sheet"], e["depends_on_sheet"]): e["mechanisms"] for e in rep_q["internal_edges"]}

            expected_pairs = {("Rollup", "Start"), ("Rollup", "Mid"), ("Rollup", "End")}
            self.assertEqual(set(edges_u.keys()), expected_pairs)
            self.assertEqual(set(edges_q.keys()), expected_pairs)
            for pair in expected_pairs:
                self.assertEqual(edges_u[pair].get("3d_span"), 1)
                self.assertEqual(edges_q[pair].get("3d_span"), 1)

    def test_p2_rtd_volatile_dependencies_extracted_at_level_2_and_3(self):
        """P2: CLI Levels 2 and 3 must populate volatile_rtd and summary RTD counts."""
        with tempfile.TemporaryDirectory() as td:
            wb = Path(td) / "rtd_model.xlsx"
            volatile_xml = (
                '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                '<volTypes xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
                '<volType type="realTimeData">'
                '<main first="tos.rtd">'
                '<tp t="n"><v>102.5</v><stp>LAST|BRN</stp><tr s="1" r="A1"/></tp>'
                '<tp t="s"><v>#N/A Requesting Data...</v><stp>BID|BRN</stp><tr s="1" r="A2"/></tp>'
                "</main>"
                "</volType>"
                "</volTypes>"
            )
            _build_minimal_ooxml(wb, volatile_xml=volatile_xml)

            for lvl in (2, 3):
                rep = wf.analyze_workbook(str(wb), level=lvl)
                self.assertIsNotNone(rep["volatile_rtd"], f"volatile_rtd is None at Level {lvl}!")
                self.assertEqual(rep["summary"]["rtd_topics"], 2)
                self.assertEqual(rep["summary"]["rtd_problem_topics"], 1)


if __name__ == "__main__":
    unittest.main()


class TestCoreForensicsAndBinaryEngines(unittest.TestCase):
    """Tests shared-formula translation, #REF! blast radius, BIFF8 offsets, MS-OVBA TLV decompression, and connection redaction."""

    def test_shared_formula_coordinate_translation_and_out_of_order_slaves(self):
        """Verifies 2D relative coordinate translation and out-of-order slave resolution."""
        with tempfile.TemporaryDirectory() as td:
            wb = Path(td) / "shared.xlsx"
            sheet_xml = (
                '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
                '<sheetData>'
                '<row r="1"><c r="A1"><v>10</v></c><c r="B1"><v>5</v></c></row>'
                '<row r="2"><c r="C2"><f t="shared" si="0"/> <v>15</v></c></row>'
                '<row r="3"><c r="C3"><f t="shared" ref="C2:C3" si="0">Inputs!A2+$B$1</f><v>25</v></c></row>'
                '</sheetData></worksheet>'
            )
            inp_xml = (
                '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
                '<sheetData><row r="1"><c r="A1"><v>10</v></c></row><row r="2"><c r="A2"><v>20</v></c></row></sheetData></worksheet>'
            )
            _build_minimal_ooxml(wb, sheets=[("Inputs", "visible", inp_xml), ("Calc", "visible", sheet_xml)])
            rep = wf.analyze_workbook(str(wb), level=3)
            self.assertEqual(rep["quality_gates"]["G2_shared_formula_accounting"], "PASS")
            self.assertEqual(rep["summary"]["formula_cells_total"], 2)
            self.assertEqual(rep["summary"]["formula_cells_shared_slaves"], 1)
            self.assertEqual(rep["summary"]["total_internal_cross_sheet_refs"], 2)

    def test_ref_error_blast_radius_ranking(self):
        """Verifies BFS #REF! blast-radius propagation and per-seed ranking."""
        with tempfile.TemporaryDirectory() as td:
            wb = Path(td) / "blast.xlsx"
            s1 = (
                '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>'
                '<row r="1"><c r="A1" t="e"><f>#REF!+1</f><v>#REF!</v></c></row>'
                '<row r="2"><c r="A2" t="e"><f>A1*2</f><v>#REF!</v></c></row>'
                '</sheetData></worksheet>'
            )
            s2 = (
                '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>'
                '<row r="1"><c r="B1" t="e"><f>Sheet1!A2+10</f><v>#REF!</v></c></row>'
                '</sheetData></worksheet>'
            )
            _build_minimal_ooxml(wb, sheets=[("Sheet1", "visible", s1), ("Sheet2", "visible", s2)])
            rep = wf.analyze_workbook(str(wb), level=3)
            blast = rep["ref_blast_radius"]
            self.assertIsNotNone(blast)
            self.assertEqual(blast["seed_cells"], 1)
            self.assertEqual(blast["downstream_formula_cells"], 2)
            self.assertEqual(blast["per_seed"][0]["seed"], "Sheet1!A1")
            self.assertEqual(blast["per_seed"][0]["downstream_cells"], 2)

    def test_connection_string_and_url_redaction_in_package_inventory(self):
        """Verifies xl/connections.xml redacts doubled quotes, passwords, and URL tokens."""
        with tempfile.TemporaryDirectory() as td:
            wb = Path(td) / "conn.xlsx"
            conn_xml = (
                '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                '<connections xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
                '<connection id="1" name="ProdDB" type="1" refreshOnLoad="1" savePassword="1">'
                '<dbPr connection="Provider=SQLOLEDB;Password=&quot;&quot;TopSecretDBPass&quot;&quot;;User ID=admin" command="SELECT * FROM trades"/>'
                '<webPr url="https://api.internal/stream?api_key=SecretApiKey789"/>'
                '</connection></connections>'
            )
            _build_minimal_ooxml(wb, connections_xml=conn_xml)
            rep = wf.analyze_workbook(str(wb), level=2)
            serialized = json.dumps(rep["package_inventory"])
            self.assertNotIn("TopSecretDBPass", serialized)
            self.assertNotIn("SecretApiKey789", serialized)
            self.assertTrue(rep["package_inventory"]["connections"][0]["embedded_password"])

    def test_biff8_bounds_and_hidden_row_col_flags(self):
        """Verifies parse_biff decodes BIFF8 BOUNDSHEET (0x0085), ROW (0x0208), and COLINFO (0x007D) flags."""
        import struct
        sheet_name = b"Secret"
        boundsheet_payload = struct.pack("<IBBBB", 22, 2, 0, len(sheet_name), 0) + sheet_name
        rec_boundsheet = struct.pack("<HH", 0x0085, len(boundsheet_payload)) + boundsheet_payload
        rec_wb_eof = struct.pack("<HH", 0x000A, 0)
        rec_protect = struct.pack("<HHH", 0x0012, 2, 1)
        rec_pw = struct.pack("<HHH", 0x0013, 2, 0x83AF)
        row_payload = b"\x00" * 12 + struct.pack("<H", 0x0020) + b"\x00\x00"
        rec_row = struct.pack("<HH", 0x0208, len(row_payload)) + row_payload
        col_payload = b"\x00" * 8 + struct.pack("<H", 0x0001) + b"\x00\x00"
        rec_col = struct.pack("<HH", 0x007D, len(col_payload)) + col_payload
        rec_ws_eof = struct.pack("<HH", 0x000A, 0)

        stream = rec_boundsheet + rec_wb_eof + rec_protect + rec_pw + rec_row + rec_col + rec_ws_eof
        parsed = support.parse_biff(stream)
        self.assertEqual(len(parsed["sheets"]), 1)
        sh = parsed["sheets"][0]
        self.assertEqual(sh["name"], "Secret")
        self.assertEqual(sh["state"], "veryHidden")
        self.assertEqual(sh["password_hash_hex"], "83AF")
        self.assertEqual(sh["hidden_rows"], 1)
        self.assertEqual(sh["hidden_cols"], 1)
