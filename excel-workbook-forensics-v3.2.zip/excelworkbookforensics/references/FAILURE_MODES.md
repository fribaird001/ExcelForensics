# Catalog of Failure Modes & Mitigations (`references/FAILURE_MODES.md`)

This catalog documents 16 observed and prospective failure modes across OOXML, BIFF8/XLSB, dependency graphs, and MS-OVBA macro forensics, along with how the v3.2 / v2.4.0 toolset prevents or surfaces them.

## 1. OOXML & Grid Iteration Failure Modes

### FM-01: Million-Row Sparse Grid Hangs (`1048576` Row Trap)
- **Symptom**: `openpyxl` `iter_rows()` or full-DOM cell grid construction hangs or exhausts RAM on a small (e.g., 200 KB) workbook because `<dimension ref="A1:XFD1048576"/>` is declared due to a single formatted blank cell at the bottom of the sheet.
- **Mitigation**: `workbook_forensics.py` sets `sparse_million_row_flag: true` when `1048576` appears in `<dimension>`, streams only existing `<c>` elements via incremental `ET.iterparse`, clears elements immediately, and detaches `<row>` nodes in `lxml`. Separate `populated_cells` from `styled_blank_cells`.

### FM-02: Unexpanded or Unshifted Shared Formula Slaves (`t="shared"`)
- **Symptom**: Counting only `<f>` tags with non-empty text misses 80–95% of formulas in large financial models because Excel writes `<f t="shared" si="0"/>` with empty text for slave cells. Worse, copying the master formula text verbatim without shifting relative A1 coordinates links every slave cell to row 1/column A inputs.
- **Mitigation**: `workbook_forensics.py` records master coordinates `(master_coord, formula_text)` by `si` index, handles out-of-order slave cells via `deferred_slaves`, and translates relative references (`translate_formula_references`) by `(d_row, d_col)` while keeping `$col`/`$row` anchors fixed.

### FM-03: External `[N]` Index Collisions & False Internal Edges
- **Symptom**: An external workbook `[1]Summary!A1` has the same tab name (`Summary`) as an internal worksheet, causing naive regexes to create a false internal dependency edge `Sheet -> Summary`. Or `[N]` is mapped by sorting `xl/externalLinks/externalLink*.xml` alphabetically (`externalLink1.xml`, `externalLink10.xml`, `externalLink2.xml`) instead of `<externalReferences>` XML document order.
- **Mitigation**: Map `[1]..[N]` strictly in 1-based `<externalReference>` document order from `xl/workbook.xml`. Extract and strip `EXT_REF_RE` matches (and string literals `STRING_LITERAL_RE`) **before** matching internal sheet names. Also scan `<definedNames>` for `[N]` references so external links used only via named ranges are classified under `external_links_used_only_by_defined_names` rather than falsely flagged as orphaned.

### FM-04: Parenthesized Sheet Names Misclassified as Functions
- **Symptom**: A formula referencing `'Summary (T-1)'!A1` or `'Book FX (B)'!C4` is parsed by a naive `([A-Z0-9_]+)\(` regex as calling functions `T-1(` or `B(`.
- **Mitigation**: Strip double-quoted string literals (`"..."`) and single-quoted sheet names (`'...'`) before running `FUNC_CALL_RE`.

### FM-05: Qualified Cross-Sheet Coordinate Bleed into Intra-Sheet Graph
- **Symptom**: Stripping only the sheet prefix `'OtherSheet'!` from `'OtherSheet'!A1:B10` leaves `A1:B10` behind in the formula string, causing the intra-sheet dependency scanner to think `Sheet1!A1` references itself (`Sheet1!A1 -> Sheet1!A1` false self-loop).
- **Mitigation**: `QUALIFIED_A1_REF_RE` strips the entire qualified token (`'OtherSheet'!A1:B10` or `OtherSheet!A1`) together with its coordinate range before extracting same-sheet `INTRA_SHEET_RANGE_RE` ranges.

---

## 2. Graph, Error Cascade & Semantic Failure Modes

### FM-06: Exponential Range Enumeration on Full-Column References (`A1:A1048576`)
- **Symptom**: Expanding `SUM(A1:A1048576)` into a Python list of 1,048,576 coordinate strings per formula crashes or times out during cell-level cycle detection.
- **Mitigation**: `build_intra_formula_graph` represents range references as rectangular integer bounds `(r1, r2, c1, c2)` and uses binary search (`bisect`) over the sparse set of **actual formula coordinates** on that sheet, capped by `max_graph_nodes = 50,000` and `max_pairs = 4,000,000`. If exceeded, it reports `SKIPPED_FORMULA_NODE_LIMIT` or `SKIPPED_GRAPH_PAIR_LIMIT` rather than silently claiming zero cycles.

### FM-07: Confusing Propagated `#REF!` Cells with Root-Cause `#REF!` Seeds
- **Symptom**: A workbook has 400 cells displaying `#REF!`, leading the analyst to waste time inspecting downstream summary tabs when all 400 errors originate from 2 broken formula cells on an upstream input tab.
- **Mitigation**: `workbook_forensics.py` separates cells with literal `#REF!` inside `<f>` (`formula_ref_error_cells` / `ref_seeds`) from cells with cached `<v>#REF!</v>`, computes the static BFS blast radius (`compute_ref_blast_radius`), and ranks each seed by `downstream_cells` (`rank_ref_seeds`). It also isolates `cached_ref_static_values` (hardcoded `#REF!` values with no formula) and `cached_ref_unexplained_formulas` (`#REF!` caused by `INDIRECT`, defined names, or whole-column deletions).

### FM-08: Invisible Non-Formula Bridges (Charts, `chartEx`, PivotCaches, Tables, 3D Spans)
- **Symptom**: A worksheet appears "Isolated / Unused" because no formula references `SheetB!A1`, even though executive dashboard charts (`<c:f>` or Office 2016+ `<cx:f>`), PivotTables (`pivotCacheDefinition*.xml`), structured table references (`Table1[Col]`), or 3D spans (`'Jan:Dec'!B5`) depend on it.
- **Mitigation**: `workbook_forensics.py` resolves 3D spans across intermediate tabs in `workbook.xml` order, maps `xl/tables/table*.xml` display names, links `pivotTable*.xml` -> `cacheId` -> `pivotCacheDefinition*.xml` (`worksheetSource`), and traverses `drawing*.xml.rels` for both standard `chart*.xml` (`NS_CHART`) and modern `chartEx*.xml` (`NS_CHARTEX`).

### FM-09: Stale or Uncalculated Cached Values & RTD Terminal Illusion
- **Symptom**: Trusting `<v>` cached numbers when `calcMode="manual"`, when formulas were written by a script without `<v>` (`uncalculated_formula_cells > 0`), or when Bloomberg/Reuters RTD cells cached `#N/A Requesting Data...` at last save.
- **Mitigation**: Always check `calc_mode`, `uncalculated_formula_cells`, and `volatile_rtd.servers` (`problem_topics` vs `NUMERIC`/`BOOLEAN` cached topics). Gate `G6` enforces explicit disclosure that cached values are not recalculated in Excel.

---

## 3. MS-OVBA, Ribbon & Legacy Binary Failure Modes

### FM-10: Heuristic MS-OVBA Offset Scanning & Codepage Corruption
- **Symptom**: Scanning `vbaProject.bin` streams byte-by-byte for `0x01` + `Attribute VB_Name` hits false positives inside compiled p-code (`PerformanceCache`) or corrupts non-ASCII module names and string literals under East Asian/Cyrillic codepages.
- **Mitigation**: `vba_inspector.py` (v2.1.0) decompresses `VBA/dir` first, parses TLV records (`PROJECTCODEPAGE` `0x0003`, `MODULENAME` `0x0019`, `MODULENAMEUNICODE` `0x0047`, `MODULESTREAMNAME` `0x001A`/`0x0032`, `MODULEOFFSET` `0x0031`, `MODULETYPE` `0x0021`/`0x0022`), decodes text using the project's declared codepage (`CODEPAGE_MAP`), and slices each module stream at its exact `MODULEOFFSET` (falling back to signature scan only when `VBA/dir` is missing or corrupt).

### FM-11: Ghost VBA Document Modules vs. Active `codeName` Bindings
- **Symptom**: Workbooks that have undergone repeated sheet copies/deletions accumulate orphaned `Sheet101`, `Sheet102`, `ThisWorkbook1` streams in `vbaProject.bin` containing only 4 `Attribute VB_*` lines, inflating module counts or hiding orphaned code.
- **Mitigation**: `vba_inspector.py` extracts active `<workbookPr codeName="..."/>` and `<sheetPr codeName="..."/>` bindings from the OOXML worksheets (`extract_active_codenames_from_workbook`) and cross-checks every `VBA/dir` module (`WORKBOOK_DOCUMENT`, `WORKSHEET_DOCUMENT`, `PROCEDURAL`, `POSSIBLE_GHOST_DOCUMENT_OR_CLASS`).

### FM-12: Broken Ribbon (`customUI`) Callbacks & Macro-Container Mismatches
- **Symptom**: Custom Ribbon buttons in `customUI/customUI14.xml` silently fail in Excel because the macro was renamed, duplicated across modules, or stripped when saving as `.xlsx`.
- **Mitigation**: `build_package_inventory` cross-checks `customUI/*.xml` callback attributes against parsed VBA procedures (`RESOLVED`, `AMBIGUOUS`, `UNRESOLVED_CANDIDATE`, `UNSUPPORTED`) and flags container mismatches (`MACRO_ENABLED_WITHOUT_VBA`, `VBA_IN_NON_MACRO_CONTAINER`).

### FM-13: VBA Stomping (Compiled P-Code vs. Source Mismatch)
- **Symptom**: Decompressed VBA source code looks benign because the compressed source stream was modified while Excel executes the cached compiled p-code (`PerformanceCache`) matching its exact Excel version.
- **Mitigation**: When `oletools` is available, `workbook_forensics.py` and `autopsy_support.py` run `detect_vba_stomping()` and report `POSSIBLE_MISMATCH` vs `NO_MISMATCH_DETECTED` (noting that benign version mismatches can also trigger p-code divergence).

### FM-14: Legacy BIFF8 `.xls` Offset Bugs (`BOUNDSHEET` & Hidden Rows)
- **Symptom**: Legacy `.xls` parsers that read `BOUNDSHEET` (0x0085) name metadata at byte offsets 5/6/7 mislabel sheets, or check record `0x0020` instead of `ROW` (`0x0208` bit `0x20` at offset 12) for hidden rows.
- **Mitigation**: `autopsy_support.py` (`parse_biff`) reads BIFF8 `BOUNDSHEET` visibility at byte 4 (`rd[4] & 3`), character count at byte 6 (`rd[6]`), encoding flag at byte 7 (`rd[7] & 1`), and string bytes at offset 8; checks `ROW` `0x0208` options word at offset 12 (`& 0x20`) and `COLINFO` `0x007D` options word at offset 8 (`& 1`); and halts cleanly on encrypted `FILEPASS` (`0x002F`) or truncated records.

### FM-15: Destructive Save / Unsolicited File Writes During Inspection
- **Symptom**: Opening a workbook in `openpyxl` and calling `wb.save()` strips unsupported extensions, ActiveX controls, VML drawings, and external link caches; or legacy `audit_raw` tools automatically copy `.bin` files to `.zip`/`.doc` on disk.
- **Mitigation**: All inspection commands (`workbook_forensics.py`, `vba_inspector.py`, `autopsy_support.py inspect`) are strictly read-only and verify `G9_source_preserved` (`sha256_before == sha256_after`). `repair_copy` requires an explicit `--output` path, refuses to overwrite existing files, streams untouched ZIP parts byte-for-byte, and verifies postconditions.

### FM-16: XML Entity Expansion (XXE / Billion Laughs) in Untrusted Workbooks
- **Symptom**: Maliciously crafted `.xlsx` archives containing `<!DOCTYPE` or `<!ENTITY` declarations in `.xml`/`.rels` parts cause memory exhaustion or local entity disclosure in naive XML parsers.
- **Mitigation**: Reject or flag any archive member containing `<!DOCTYPE` or `<!ENTITY` declarations during preflight before XML parsing.
