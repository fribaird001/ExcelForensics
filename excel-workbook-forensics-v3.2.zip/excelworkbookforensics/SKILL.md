---
name: excel-workbook-forensics
description: Conduct structural forensics, formula dependency mapping, #REF! blast-radius tracing, RTD/connection auditing, protection/visibility inspection, and VBA/OOXML/BIFF8 reverse engineering on unfamiliar Microsoft Excel workbooks (.xlsx, .xlsm, .xlsb, .xls). Use whenever asked to inspect, audit, reverse-engineer, map cross-sheet links, trace formula lineage, diagnose #REF!/#VALUE! cascades, unhide/unprotect copies, or understand the architecture of a complex spreadsheet before modifying or porting it.
---
# Excel Workbook Forensics (v3.2 / Engine v2.4.0)

Perform systematic, read-only structural reconnaissance, formula dependency mapping, `#REF!` blast-radius attribution, protection/visibility auditing, and low-level OOXML/BIFF8/VBA forensics on unfamiliar Excel workbooks without relying on slow cell-by-cell grid iteration or brittle assumptions.

## Companion Package Files

This skill uses progressive disclosure across the following packaged files:

- **`SKILL.md`**: Operational entry point, adaptive inspection workflow, script invocation rules, and output contract.
- **`references/TOOLING_GUIDE.md`**: Engine selection matrix (`workbook_forensics.py`, `vba_inspector.py`, `autopsy_support.py`, `office_autopsy.py`), incremental `iterparse` rules, two-pass shared-formula coordinate translation, reference disambiguation order, and surgical ZIP-to-ZIP repair guardrails.
- **`references/FAILURE_MODES.md`**: Catalog of 16 failure modes and mitigations (million-row grid hangs, unshifted shared formulas, external `[N]` index collisions, parenthesized sheet-name function false positives, qualified coordinate bleed, `#REF!` root-cause vs. cascade confusion, MS-OVBA `VBA/dir` TLV slicing, ghost modules, Ribbon callback mismatches, and BIFF8 offset traps).
- **`references/VALIDATION_PROTOCOL.md`**: The 9 mandatory Quality Gates (`G1`–`G9`), the 4-tier Epistemic Classification contract, and redaction/safety rules.
- **`scripts/workbook_forensics.py`**: Workbook-agnostic OOXML & dependency forensics CLI (v2.4.0) for Level 1–4 inventory, incremental `iterparse` XML streaming, shared-formula 2D coordinate translation, 3D/Table/DefinedName/Chart/`chartEx`/PivotCache bridge extraction, `#REF!` BFS blast-radius ranking, RTD topic health classification, package/connection/Ribbon auditing, sheet- and cell-level Tarjan SCC cycle detection, and JSON / Graphviz `.dot` export.
- **`scripts/vba_inspector.py`**: Pure-Python OLE2 Compound Document reader and MS-OVBA (v2.1.0) inspector for `xl/vbaProject.bin`. Parses `VBA/dir` TLV records (`PROJECTCODEPAGE`, `MODULEOFFSET`, `MODULETYPE`), slices module streams at exact `MODULEOFFSET`, cross-checks OOXML worksheet `codeName` bindings to isolate ghost modules, and runs a static capability & redacted-credential risk scan (`--scan-risks`).
- **`scripts/autopsy_support.py` & `scripts/office_autopsy.py`**: Office Autopsy 3.2 container, protection, and legacy binary inspector. Content-sniffs magic bytes (`.xlsx`, `.xlsm`, `.xlsb`, `.xls` BIFF8, encrypted Office, raw `.bin`), audits `workbookProtection`/`sheetProtection`/hidden rows & columns, recovers compatible legacy 16-bit XOR protection hash collisions (`--recover-passwords`), exports VBA macros with SHA-256 manifests (`macros`), and creates verified unhidden/unprotected OOXML copies (`repair`).

## When to Use

- Auditing an unfamiliar `.xlsx`, `.xlsm`, `.xlsb`, or `.xls` workbook to understand how worksheets, Excel Tables, named ranges, charts, PivotTables, and external workbooks connect
- Mapping sheet-level or cell-level calculation lineage (Directed Acyclic Graphs, topological tiers, Tarjan SCC circular reference loops)
- Diagnosing formula error cascades (`#REF!`, `#VALUE!`, `#NAME?`, `#N/A`, `#DIV/0!`), ranking root-cause `#REF!` seeds by downstream blast radius, or isolating broken defined names and orphaned external links
- Inspecting `hidden` or `veryHidden` sheets, worksheet/workbook protection flags, hidden rows/columns, legacy `.xls` BIFF8 structures, or `.xlsb` containers
- Auditing `.xlsm` VBA modules (`vbaProject.bin`), Ribbon (`customUI`) callbacks, Power Query (`DataMashup`), database/web connections (`xl/connections.xml`), or volatile RTD terminal feeds (`xl/volatileDependencies.xml`)
- Creating a verified, byte-preserving unhidden/unprotected inspection copy of a locked OOXML workbook or preparing a Python port

## Inputs and Prerequisites

- **Required input**: Path to target workbook (`.xlsx`, `.xlsm`, `.xltx`, `.xltm`, `.xlsb`, `.xls`, or `vbaProject.bin`).
- **Source preservation rule**: Treat the target workbook as strictly read-only during inspection (`G9_source_preserved`). Never call `openpyxl` `wb.save()` on a workbook during reconnaissance, and never overwrite the source file when creating an unhidden/unprotected copy.

## Environment Capability Check

Before choosing an extraction path, run the built-in capability probe:

```bash
python3 scripts/workbook_forensics.py --check-env
```

- **Default OOXML engine (`.xlsx` / `.xlsm`)**: `zipfile` + `lxml.etree.iterparse` (or stdlib `xml.etree.ElementTree.iterparse` fallback) in `scripts/workbook_forensics.py`.
- **Container, protection & legacy binary engine (`.xls`, `.xlsb`, encrypted Office, OOXML protection)**: `scripts/autopsy_support.py inspect <filepath>`.

## Adaptive Inspection Depth

Select the lowest inspection level that satisfies the user's objective, and escalate when concrete triggers are met:

| Level | Scope | Escalation Trigger |
| :--- | :--- | :--- |
| **Level 1: Lightweight Reconnaissance** | Archive part manifest, file size, SHA-256 hash, `date1904`, `calcMode`, `iterate`, sheet list (`visible`/`hidden`/`veryHidden`, `codeName`), declared dimensions (`sparse_million_row_flag`), defined name counts, external link count, plus `autopsy_support.py inspect` for sheet/workbook protection and hidden row/col counts. | Escalate to Level 2 if the user needs formula lineage, error diagnostics, `#REF!` blast radius, or cross-sheet links, or if >5 sheets or >100 defined names exist. |
| **Level 2: Structural, Formula & Blast-Radius Inspection** | Incremental `iterparse` streaming of `<c>` nodes, two-pass shared-formula coordinate translation, external vs. internal reference disambiguation, 3D spans, structured tables, defined names, chart/`chartEx` & PivotCache bridges, `#REF!` BFS blast-radius ranking, RTD topic health, package/connection/Ribbon inventory, and sheet-level DAG tiers. | Escalate to Level 3 if dynamic indirection (`INDIRECT`, `OFFSET`, `ADDRESS`), circular references, or intra-sheet cell-level cycle checks are needed. |
| **Level 3: Deep Dependency & Intra-Sheet Cycle Analysis** | Collapses repeated formula patterns into R1C1-normalized blocks (`formula_patterns_count`), constructs the bounded intra-sheet formula dependency graph (`build_intra_formula_graph`), and runs Tarjan SCC cycle detection at both the sheet level (`sheet_cycles`) and intra-sheet cell level (`intra_sheet_cycles`). | Escalate to Level 4 if `.xlsm` (`vbaProject.bin`), Ribbon callback resolution against VBA procedures, or macro capability/credential risk scanning are needed. |
| **Level 4: Full Forensic, VBA & Binary Inspection** | Decompresses `xl/vbaProject.bin` via `scripts/vba_inspector.py` (`VBA/dir` TLV records, exact `MODULEOFFSET` slicing, project codepage decoding), cross-checks worksheet `codeName` bindings for ghost modules, resolves `customUI` Ribbon callbacks against VBA procedures, runs static VBA risk & redacted-credential scanning, and checks `oletools` p-code stomping. | Terminal depth. |

## Step-by-Step Execution Workflow

### Stage 1: Preflight, Protection & Container Inventory (Level 1)

- **Objective**: Content-sniff the file, verify container integrity, inspect sheet/workbook protection and visibility, and inventory parts without loading cell grids into memory.
- **Preferred tools**:
  ```bash
  python3 scripts/autopsy_support.py inspect path/to/workbook.xlsx --export-json autopsy_preflight.json
  python3 scripts/workbook_forensics.py path/to/workbook.xlsx --level 1 --export-json level1_preflight.json
  ```
- **Procedure**:
  1. Run `autopsy_support.py inspect` first to content-sniff magic bytes (`detect_kind`) rather than trusting the file extension. If the file is `.xls` (BIFF8), `.xlsb` (BIFF12), `encrypted_office`, or raw `.bin`, `autopsy_support.py` handles it directly without failing on OOXML assumptions.
  2. For `.xlsx`/`.xlsm`, inspect `workbook_protection`, `file_sharing`, per-sheet `protection` flags, `hidden_rows`, `hidden_cols`, `state` (`visible`/`hidden`/`veryHidden`), and `sparse_million_row_flag`.
  3. Confirm Quality Gate `G1_preflight_integrity == "PASS"` and `G9_source_preserved == true`.

### Stage 2: Streaming Formula Extraction, Bridges & `#REF!` Blast Radius (Level 2)

- **Objective**: Stream all populated cells, expand and translate shared formulas, disambiguate external vs. internal references, map non-formula bridges, and compute the `#REF!` blast radius.
- **Preferred tool**:
  ```bash
  python3 scripts/workbook_forensics.py path/to/workbook.xlsx --level 2 --export-json level2_structure.json --export-dot dependency_dag.dot
  ```
- **Procedure**:
  1. **Verify Shared-Formula Accounting (`G2`)**: Check `formula_cells_total`, `formula_cells_explicit_or_master`, and `formula_cells_shared_slaves`, confirming `G2_shared_formula_accounting == "PASS"`.
  2. **Audit External Links & Defined Names (`G3`)**: Review `external_links_catalog`, `active_external_links_count`, `external_links_used_only_by_defined_names`, and `orphaned_external_links_ids`. Inspect `custom_defined_names` for `has_ref_error: true`.
  3. **Trace `#REF!` Blast Radius**: Inspect `ref_blast_radius` (`seed_cells`, `downstream_formula_cells`, `per_seed` ranked descending by `downstream_cells`, `cached_ref_static_values`, and `cached_ref_unexplained_formulas`) to separate root-cause broken formulas from downstream cascade victims.
  4. **Inspect Package Connections & RTD Feeds**: Check `package_inventory.connections` (for database/web/Power Query links and redacted password warnings) and `volatile_rtd.servers` (for `problem_topics` such as `REQUESTING_DATA` or `NO_DATA` cached at save time).

### Stage 3: Topological Lineage & Cell/Sheet Cycle Detection (Level 3)

- **Objective**: Build the sheet-level DAG, assign topological calculation tiers and sheet roles, normalize R1C1 formula patterns, and run sheet- and cell-level Tarjan SCC cycle detection.
- **Preferred tool**:
  ```bash
  python3 scripts/workbook_forensics.py path/to/workbook.xlsx --level 3 --export-json audit_report.json --export-dot dependency_dag.dot
  ```
- **Procedure**:
  1. **Review Sheet Roles & Tiers**: Examine each worksheet's `tier` (`0` through `N` or `None` if cyclic) and `role` (`Tier-0 Primary Source`, `Tier-k Intermediate Calculation Sheet`, `Tier-k Terminal Output / Report Sheet`, `Presentation / Pivot Host`, `Data Source Consumed by Charts / PivotTables`, or `Cyclic Dependency Member (SCC)`).
  2. **Distinguish Sheet Cycles from Cell Cycles (`G5`)**: Check `sheet_cycles` alongside each sheet's `intra_sheet_cycles` and `intra_sheet_graph_status` (`EXAMINED_STATIC_A1` vs. `SKIPPED_FORMULA_NODE_LIMIT`). Remember that `SheetA <-> SheetB` in `sheet_cycles` indicates mutual cross-sheet references, not necessarily a cell-level circular reference loop.
  3. **Audit Non-Formula Bridges**: Check `chart_cross_sheet_edges` (both `chart` and `chartEx`), `pivot_cross_sheet_edges`, and `internal_edges[].mechanisms` (`direct_cell_ref`, `3d_span`, `structured_table`, `defined_name`).

### Stage 4: MS-OVBA, Ribbon Callback & Protection Forensics (Level 4)

- **Objective**: Decompress `xl/vbaProject.bin`, cross-check active worksheet `codeName` bindings, resolve Ribbon callbacks, scan VBA code for risky capabilities/hardcoded credentials, and optionally export macros or create an unhidden/unprotected copy.
- **Preferred tools**:
  ```bash
  python3 scripts/workbook_forensics.py path/to/workbook.xlsm --level 4 --export-json level4_full_audit.json
  python3 scripts/vba_inspector.py path/to/workbook.xlsm --extract-code --export-json vba_audit.json
  ```
- **Optional explicit actions (always write to a new path, never modifying source)**:
  ```bash
  # Export decompressed VBA modules (.bas/.cls) + SHA-256 manifest.json
  python3 scripts/autopsy_support.py macros path/to/workbook.xlsm --output path/to/vba_export_dir

  # Create a verified unhidden & unprotected OOXML copy (verifies CRCs, untouched parts, and source SHA-256)
  python3 scripts/autopsy_support.py repair path/to/workbook.xlsx --output path/to/workbook_unhidden.xlsx
  ```
- **Procedure**:
  1. **Audit `vba_project`**: Review `project_name`, `codepage`, `declared_modules` (`binding_status`: `PROCEDURAL`, `WORKBOOK_DOCUMENT`, `WORKSHEET_DOCUMENT`, `POSSIBLE_GHOST_DOCUMENT_OR_CLASS`), `ghost_sheet_class_modules`, `executable_modules_count`, and `stomping_check`.
  2. **Review Static VBA Risk Scan (`risk_scan`)**: Inspect `summary` (`HIGH`, `MEDIUM`, `LOW`), `by_category` (`auto_execution`, `command_execution`, `hardcoded_credential`, `connection_string`, `windows_api`, `file_io`, `network`), and VBE line-numbered `findings` (all credential values are automatically redacted as `<redacted:N chars>`).
  3. **Verify Ribbon Callbacks**: If `package_inventory.ribbon` is present, check `callbacks_missing` (`UNRESOLVED_CANDIDATE`) and `callbacks_ambiguous` (`AMBIGUOUS`).

## Output Contract

Deliver a structured forensic report proportionate to the selected inspection depth:

1. **Workbook Inventory, Protection & Preflight Summary**: Detected file type (`kind`), size, SHA-256 preservation (`G9`), `date1904`, `calcMode`, `iterate`, sheet counts (`visible`/`hidden`/`veryHidden`), protection status (`workbookProtection`, `sheetProtection`, hidden rows/cols), populated vs. styled-blank cells, and formula counts (explicit/master vs. expanded shared slaves, `uncalculated_formula_cells`).
2. **Topological Architecture & Sheet Lineage Map**: Markdown table organizing worksheets by DAG Tier (`Tier 0` primary sources through terminal outputs), listing each sheet's visibility state, `codeName`, role, formula count, R1C1 pattern count, upstream inputs, and downstream consumers.
3. **Cross-Sheet & Non-Formula Dependency Register**: Breakdown of `internal_edges` by mechanism (`direct_cell_ref`, `3d_span`, `structured_table`, `defined_name`), plus Chart (`<c:f>` / `<cx:f>`) and PivotCache cross-sheet bridges.
4. **External Link, Connection & RTD Feed Register**: Active vs. defined-name-only vs. orphaned external links (`[1]..[N]`), `xl/connections.xml` / Power Query (`DataMashup`) inventory, and `volatile_rtd` server/topic health (`NUMERIC`/`BOOLEAN` vs. `REQUESTING_DATA`/`NO_DATA`).
5. **Error Hotspot, `#REF!` Blast Radius & VBA Audit Register**: Cached error counts by sheet, ranked root-cause `#REF!` seeds (`per_seed` downstream impact), dynamic indirection hotspots (`INDIRECT`/`OFFSET`/`ADDRESS`), Ribbon callback statuses, and `vbaProject.bin` module binding & static risk summary.
6. **Quality Gates & Epistemic Summary**: Explicit summary of Quality Gates `G1`–`G9` and separation of **Verified Facts**, **Strongly Supported Interpretations**, **Tentative Hypotheses**, and **Unknown/Inaccessible Information** per `references/VALIDATION_PROTOCOL.md`.
